import React, { useEffect, useState } from "react";
import { Text } from "ink";
const FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"];
/** Braille spinner shown in front of the prompt while the agent is working (§6). */
export function Spinner({ active }) {
    const [frame, setFrame] = useState(0);
    useEffect(() => {
        if (!active)
            return;
        const id = setInterval(() => setFrame((f) => (f + 1) % FRAMES.length), 80);
        return () => clearInterval(id);
    }, [active]);
    if (!active)
        return React.createElement(Text, null, " ");
    return React.createElement(Text, { color: "cyan" }, FRAMES[frame]);
}
