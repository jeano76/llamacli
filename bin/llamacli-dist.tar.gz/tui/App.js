import React, { useEffect, useRef, useState } from "react";
import { Box, Text, useInput, useStdout } from "ink";
import stringWidth from "string-width";
import { StatusBar } from "./StatusBar.js";
import { Spinner } from "./Spinner.js";
import { SlashMenu, SLASH_MENU_ITEMS } from "./SlashMenu.js";
import { tailToWidth, wrapToWidth, wrapAnsiSafe, wrapPreservingTables } from "./textWidth.js";
import { stripToolCallTemplateLeak } from "../agent/textSanitize.js";
import { renderMarkdown } from "./markdown.js";
import { HARNESS_ART, ART_WIDTH, rightAlign, shineMultilineFrame, shineMultilineFrameCount, bounceFrame, bounceFrameCount } from "./banner.js";
/** Every prompt actually submitted counts, whether it was sent immediately
 *  or queued while busy (see the Return-key handler below) — both are "the
 *  user submitted a prompt" from history's point of view. Caps at
 *  MAX_PROMPT_HISTORY and drops an exact-duplicate of the immediately
 *  preceding entry (retyping/resubmitting the same thing shouldn't spam
 *  history with repeats), same as a normal shell's history behaves. */
export const MAX_PROMPT_HISTORY = 50;
export function appendHistory(history, text) {
    if (history[history.length - 1] === text)
        return history;
    const next = [...history, text];
    return next.length > MAX_PROMPT_HISTORY ? next.slice(next.length - MAX_PROMPT_HISTORY) : next;
}
let logIdCounter = 0;
/** The single-line summary shown for a finished reasoning block once
 *  folded (the default — see App's expandedReasoningIds). Carries its own
 *  icon + a plain-language hint ("클릭해서 펼치기" — click to expand),
 *  requested directly so the fold affordance isn't just an unlabeled
 *  glyph. `foldToggleHint` is the matching label for the EXPANDED state,
 *  used in the render branch below. */
export function foldedReasoningSummary(text) {
    const chars = text.trim().length;
    return `▸ 생각 과정 (${chars}자) — 클릭해서 펼치기`;
}
export const foldToggleHintExpanded = "  ▴ 클릭해서 접기";
/** Folded summary line for a compaction's before/after detail (see
 *  CompactionDetail in compactor.ts) — requested directly ("컴팩션하는
 *  과정을 그래픽컬하게 보여주고... 어떤 내용들이 잊혀지고 어떤 내용들이
 *  강조가 되었는지"): what got dropped vs what the summary kept/emphasized,
 *  folded by default like a reasoning block and expandable the same way. */
export function foldedCompactionSummary(droppedCount, droppedTokens, keptCount) {
    return `▸ 압축 완료 — ${droppedCount}개 메시지 요약됨(~${droppedTokens}토큰), ${keptCount}개 메시지 유지 — 클릭해서 펼치기`;
}
/** The expanded body: dropped-content preview first (what was forgotten),
 *  then the summary text that replaced it (what was kept/emphasized). */
export function compactionDetailBody(detail) {
    return (`🗑 잊혀진 내용:\n${detail.droppedPreview.map((l) => `  - ${l}`).join("\n")}\n\n` +
        `✨ 강조된 내용 (요약):\n${detail.summary}`);
}
/** Extracts the path and +added/-removed line counts from a formatDiff()
 *  string (src/tools/diff.ts) — its header is `\x1b[1m--- ${path}\x1b[0m`
 *  and each changed line is prefixed with the green/red ANSI codes it
 *  defines. Used for the folded summary label; a diff text that doesn't
 *  match the expected shape (defensive — formatDiff's own format could
 *  change) falls back to a generic label rather than throwing. */
export function parseDiffStats(diffText) {
    const pathMatch = diffText.match(/^\x1b\[1m--- (.+?)\x1b\[0m/);
    const added = (diffText.match(/\x1b\[32m\+/g) ?? []).length;
    const removed = (diffText.match(/\x1b\[31m-/g) ?? []).length;
    return { path: pathMatch?.[1] ?? "(unknown file)", added, removed };
}
/** Folded summary line for a run_shell result (e.g. `npm test` output) —
 *  requested directly ("유닛테스트 수행시 테스트 결과도 펼침과 닫힘기능으로
 *  제공한다"): a shell command's output was previously never shown in the
 *  TUI at all, only the "⚡ run_shell(...)" call label. Defaults folded
 *  like reasoning/compaction (raw shell output can be long and isn't the
 *  point of the screen most of the time), expandable the same way. */
export function foldedToolResultSummary(command, output) {
    const lines = output.split("\n").length;
    return `▸ 결과: ${command} (${lines}줄) — 클릭해서 펼치기`;
}
/** Folded summary line for a diff block — requested directly ("기본적으로는
 *  화면에 펼짐으로 나타내고 다음 명령어 진입시 닫힘으로"): diffs start
 *  expanded (the opposite default from reasoning/compaction, which start
 *  folded) and only collapse once the next command is submitted, via
 *  collapsedDiffIds in App — still expandable again afterward by click. */
export function foldedDiffSummary(diffText) {
    const { path, added, removed } = parseDiffStats(diffText);
    return `▸ diff: ${path} (+${added} -${removed}) — 클릭해서 펼치기`;
}
/** Splits `text` into runs for the reveal-wave shimmer: a one-directional
 *  wave (never wraps, never goes backward) advances `speed` characters per
 *  tick, so text already passed stays lit while text ahead of the wave is
 *  still dim. Monotonic in `tick` for a fixed `text`, so a settled band
 *  can never later render as dim again — the earlier design (a spotlight
 *  cycling over otherwise-static text) reverted already-"read" text back
 *  to dim every cycle, reported directly as looking wrong. Pure function:
 *  same (text, tick) always gives the same bands, so it has nothing to do
 *  with the row-wrap cache (keyed on text, not tick). */
export function shimmerBands(text, tick, bandWidth = SHIMMER_BAND_WIDTH, speed = SHIMMER_SPEED_CHARS_PER_TICK) {
    if (!text)
        return [];
    const revealed = Math.min(text.length, tick * speed);
    const peakStart = Math.max(0, revealed - bandWidth);
    const bands = [];
    if (peakStart > 0)
        bands.push({ text: text.slice(0, peakStart), role: "settled" });
    if (revealed > peakStart)
        bands.push({ text: text.slice(peakStart, revealed), role: "peak" });
    if (revealed < text.length)
        bands.push({ text: text.slice(revealed), role: "dim" });
    return bands;
}
const SHIMMER_BAND_WIDTH = 10;
const SHIMMER_SPEED_CHARS_PER_TICK = 2;
export const SHIMMER_TICK_MS = 80;
/** Wraps one log entry into terminal rows (unpadded). */
function wrapLogLine(line, width) {
    if (line.kind === "diff") {
        // Diff text carries its own ANSI color codes (formatDiff()): wrap
        // ANSI-safely so an escape sequence is never torn apart mid-code.
        return wrapAnsiSafe(line.text, width);
    }
    if (line.kind === "assistant") {
        // Markdown with syntax-highlighted code; tables are clipped rather than
        // wrapped, since wrapping a table row destroys its borders.
        return wrapPreservingTables(renderMarkdown(line.text, width), width);
    }
    if (line.kind === "user")
        return wrapToWidth(`❯ ${line.text}`, width);
    if (line.kind === "tool")
        return wrapToWidth(`⚡ ${line.text}`, width);
    // Chain-of-thought, shown only when enableThinking is on (loop.ts's
    // onReasoningDelta). Kept visually distinct (dim, prefixed) from the
    // real answer so it reads as "thinking out loud", not the final reply —
    // this is display-only and never re-enters the conversation.
    if (line.kind === "reasoning")
        return wrapToWidth(`  ${line.text}`, width);
    return wrapToWidth(line.text, width);
}
function renderRow(row, shimmerTick) {
    if (row.kind === "reasoning-folded") {
        // Same cyan the reasoning text itself settles at once fully revealed
        // (not dim) — reported directly that dim gray made the fold line hard
        // to read; it's also the click target, so it should read as "live UI",
        // not muted-away text.
        return (React.createElement(Text, { key: row.key, color: "cyan" }, row.text));
    }
    if (row.kind === "reasoning" && shimmerTick !== undefined) {
        return (React.createElement(Text, { key: row.key }, shimmerBands(row.text, shimmerTick).map((b, i) => {
            if (b.role === "peak") {
                return (React.createElement(Text, { key: i, color: "cyan", bold: true, italic: true }, b.text));
            }
            if (b.role === "settled") {
                return (React.createElement(Text, { key: i, color: "cyan", italic: true }, b.text));
            }
            return (React.createElement(Text, { key: i, color: "gray", dimColor: true, italic: true }, b.text));
        })));
    }
    if (row.kind === "assistant" && shimmerTick !== undefined) {
        // Same shining reveal-wave as reasoning (see streamingAssistantId's
        // doc comment) — requested directly: "로그 문자를 생각의 글씨의
        // 빛나는 효과처럼 나타나게 해줘".
        return (React.createElement(Text, { key: row.key }, shimmerBands(row.text, shimmerTick).map((b, i) => {
            if (b.role === "peak") {
                return (React.createElement(Text, { key: i, bold: true }, b.text));
            }
            if (b.role === "settled")
                return React.createElement(Text, { key: i }, b.text);
            return (React.createElement(Text, { key: i, color: "gray", dimColor: true }, b.text));
        })));
    }
    if (row.kind === "compaction-detail-folded") {
        return (React.createElement(Text, { key: row.key, color: "yellow" }, row.text));
    }
    if (row.kind === "compaction-detail") {
        return (React.createElement(Text, { key: row.key, color: "yellow" }, row.text));
    }
    if (row.kind === "user") {
        return (React.createElement(Text, { key: row.key, color: "cyan", bold: true }, row.text));
    }
    if (row.kind === "tool") {
        return (React.createElement(Text, { key: row.key, color: "magenta" }, row.text));
    }
    if (row.kind === "status") {
        return (React.createElement(Text, { key: row.key, color: "gray" }, row.text));
    }
    if (row.kind === "reasoning") {
        // A finished reasoning block the user has expanded (see
        // expandedReasoningIds) — kept at its settled shimmer color (cyan)
        // rather than dimming back down once done. Reported directly: fading
        // to dim on completion looked like the text itself had lost meaning,
        // when it is exactly the text that was just highlighted revealing it.
        return (React.createElement(Text, { key: row.key, color: "cyan", italic: true }, row.text));
    }
    if (row.kind === "tool-result-folded") {
        return (React.createElement(Text, { key: row.key, color: "blue" }, row.text));
    }
    if (row.kind === "tool-result") {
        return (React.createElement(Text, { key: row.key, color: "blue" }, row.text));
    }
    if (row.kind === "diff-folded") {
        return (React.createElement(Text, { key: row.key, color: "green" }, row.text));
    }
    // diff / assistant carry their own ANSI styling
    return React.createElement(Text, { key: row.key }, row.text);
}
/** `input` is the raw text box content, which starts with "/" while the
 *  menu is open — everything after that is the filter query. Matches
 *  against the command's key (e.g. "improve-apply"), not its "/"-prefixed
 *  label, so typing "imp" also finds "/improve-apply" via a plain
 *  substring check — simple and predictable over fuzzier matching. */
export function filterMenuItems(input) {
    const query = input.slice(1).toLowerCase();
    if (!query)
        return SLASH_MENU_ITEMS;
    return SLASH_MENU_ITEMS.filter((item) => item.key.toLowerCase().includes(query));
}
/** Parses SGR mouse reports ("[<64;10;5M" — Ink strips the leading ESC and
 *  can hand over several reports in one string) into a net scroll in rows:
 *  positive = wheel up (scroll back), negative = wheel down. Returns null
 *  when `input` isn't a mouse report at all, so it can fall through to
 *  normal key handling. Clicks and releases count as 0. */
export const WHEEL_SCROLL_ROWS = 3;
export function parseMouseWheel(input) {
    const reports = [...input.matchAll(/\[<(\d+);\d+;\d+([Mm])/g)];
    if (reports.length === 0)
        return null;
    let rows = 0;
    for (const [, code, kind] of reports) {
        const button = Number(code);
        if (kind !== "M" || (button & 64) === 0)
            continue; // not a wheel event
        rows += (button & 1) === 0 ? WHEEL_SCROLL_ROWS : -WHEEL_SCROLL_ROWS;
    }
    return rows;
}
export function bufferMouseChunk(buffered, chunk) {
    const combined = buffered + chunk;
    if (/\[<\d+;\d+;\d+[Mm]/.test(combined))
        return { action: "process", text: combined };
    if (combined.length < 64)
        return { action: "wait" };
    return { action: "discard" };
}
export function parseMouseClicks(input) {
    const clicks = [];
    for (const [, code, colStr, rowStr, kind] of input.matchAll(/\[<(\d+);(\d+);(\d+)([Mm])/g)) {
        if (kind !== "M")
            continue; // only presses — a release fires right after and would double-toggle
        const button = Number(code);
        if ((button & 64) !== 0 || (button & 32) !== 0)
            continue; // wheel, or drag/motion
        clicks.push({ row: Number(rowStr), col: Number(colStr) });
    }
    return clicks;
}
/** Log entries kept for scrollback. Rendering only ever builds React
 *  elements for the visible window (see visibleRows below), so this bounds
 *  memory, not render cost. */
export const MAX_LOG_ENTRIES = 5000;
/** Whether the terminal cursor should be hidden: it belongs only where the
 *  user can type. Reported directly: while the agent worked with an empty
 *  input box, the cursor sat blinking right next to the spinner. */
export function shouldHideCursor(state) {
    return state.quitting || (state.busy && state.input.length === 0);
}
/** The key-hint line shown under the log while the agent is running (never
 *  inside the input box: it used to sit next to the prompt and take width
 *  from it, which threw off the input's width/cursor math — reported
 *  directly). Picks the long form when it fits the terminal width. */
export function runHintText(columns) {
    // With mouse reporting on (wheel scrollback), plain clicks go to the app;
    // holding Shift hands them back to the terminal, so Shift+drag selects and
    // Shift+right-click opens the terminal's own Copy/Paste menu.
    // Esc and /quit are NOT the same thing — Esc cancels the running turn and
    // exits right away (a checkpoint is written first so it resumes next
    // time), while /quit waits for the turn to finish and runs the normal
    // self-improvement-review gate first. Spelled out directly (강제종료 vs
    // 정상종료) rather than just "Esc: 종료" for both, which didn't say which
    // was which.
    const forms = [
        "  실행 중 · Esc: 강제종료 · /quit: 정상종료 · Shift+드래그: 선택 · Shift+우클릭: 복사/붙여넣기",
        "  Esc: 강제종료 · /quit: 정상종료 · Shift+우클릭: 복사/붙여넣기",
        "  Esc: 강제종료 · /quit: 정상종료",
    ];
    return forms.find((f) => stringWidth(f) <= columns - 1) ?? forms[forms.length - 1];
}
/** Input-box text while progress is being saved before exit. */
export function quittingStatusText(elapsedMs) {
    return `진행 상황 저장 중… ${Math.floor(elapsedMs / 1000)}초 · Esc: 저장하지 않고 바로 종료`;
}
export function App({ cwd, model, onSubmit, onSlashCommand, onQueueMessage, onForceQuit, onQuitWithoutSaving, initialHistory, onHistoryChange, pendingResumeGoal, onResumeDecision, startupBanner, }) {
    const { stdout } = useStdout();
    const [input, setInput] = useState("");
    const [log, setLog] = useState([]);
    const [busy, setBusy] = useState(false);
    // The startup banner: "HARNESS" as block-letter ASCII art that shines
    // itself in, then a version/bounce line and the repo URL underneath —
    // see AppProps.startupBanner's doc comment for why this lives inside the
    // log (a real, persistent line) rather than a raw stdout write before the
    // alt-screen switch, which was invisible in practice.
    useEffect(() => {
        const artLineId = logIdCounter++;
        const cliLineId = logIdCounter++;
        const versionLineId = logIdCounter++;
        setLog((prev) => [
            { id: artLineId, text: HARNESS_ART.join("\n"), kind: "status" },
            { id: cliLineId, text: "", kind: "status" },
            { id: logIdCounter++, text: rightAlign(`\x1b[2m${startupBanner.repoUrl}\x1b[0m`, ART_WIDTH), kind: "status" },
            { id: versionLineId, text: rightAlign(startupBanner.version, ART_WIDTH), kind: "status" },
            ...prev,
        ]);
        const setLineText = (id, text) => setLog((prev) => prev.map((line) => (line.id === id ? { ...line, text } : line)));
        // Two phases, one after another (not simultaneous — several flourishes
        // going at once reads as chaotic): the WHOLE "HARNESS CLI" text shines
        // in with one diagonal sweep (no shake — dropped per direct feedback:
        // "지금처럼 좌우로 흔드는 애니메이션은 필요없고", replaced with "샤이닝
        // 효과는 Think 할 때의 글씨의 반짝이는 효과처럼 같은 색상 계열의
        // 밝은색 블럭으로 좌측에서 우측으로 비스듬하게 이동이 되게 되는거야" —
        // a bright block of the same color family moving diagonally
        // left-to-right, same as reasoning's own shimmer), then the version
        // line's ball bounces. "CLI" stays small plain text, not block art
        // (per "cli는 소문자로 좀 작게 해주고"), and uppercase (per "Harness
        // CLI 처럼 대소문자 반영해줘": the acronym stays uppercase, matching
        // how the app's own name is written everywhere else).
        const CLI_TEXT = "CLI";
        const shineLines = [...HARNESS_ART, CLI_TEXT];
        let shineTick = 0;
        let bounceId = null;
        const shineTicks = shineMultilineFrameCount(shineLines);
        const shineId = setInterval(() => {
            shineTick++;
            const frame = shineMultilineFrame(shineLines, shineTick).split("\n");
            setLineText(artLineId, frame.slice(0, HARNESS_ART.length).join("\n"));
            setLineText(cliLineId, rightAlign(frame[HARNESS_ART.length], ART_WIDTH));
            if (shineTick >= shineTicks) {
                clearInterval(shineId);
                let bounceTick = 0;
                bounceId = setInterval(() => {
                    bounceTick++;
                    setLineText(versionLineId, rightAlign(`${startupBanner.version}  ${bounceFrame(bounceTick)}`, ART_WIDTH));
                    if (bounceTick >= bounceFrameCount())
                        clearInterval(bounceId);
                }, 60);
            }
        }, 90);
        return () => {
            clearInterval(shineId);
            if (bounceId !== null)
                clearInterval(bounceId);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    // Esc opens this Y/N confirmation instead of quitting immediately — a
    // single stray keystroke shouldn't be able to kill the app (mid-turn or
    // not). While this is true, useInput intercepts every key as part of the
    // confirmation (see below) rather than normal typing/menu/etc.
    const [quitConfirmPending, setQuitConfirmPending] = useState(false);
    // Set (to the start time) once a quit has been requested and progress is
    // being saved. Saving can take a minute (it's a full compaction when
    // idle), so this drives a dedicated animation with an elapsed-time count
    // instead of leaving the app looking frozen — and while it's set, Esc or
    // Ctrl-C quits immediately without waiting for the save.
    const [quittingSince, setQuittingSince] = useState(null);
    const [, setQuitTick] = useState(0);
    useEffect(() => {
        if (quittingSince === null)
            return;
        const id = setInterval(() => setQuitTick((t) => t + 1), 1000);
        return () => clearInterval(id);
    }, [quittingSince]);
    // Shown once at startup (initialized from the prop, which index.tsx only
    // sets when a checkpoint was actually found on disk) — intercepts input
    // the same way quitConfirmPending does, and is resolved before either the
    // user can start typing a real message or the auto-resume machinery
    // (AgentLoop.resumeIfCheckpointExists()) runs on its own.
    const [resumeConfirmPending, setResumeConfirmPending] = useState(!!pendingResumeGoal);
    // Prompt history (Up/Down arrow), most recent last — see appendHistory.
    // Loaded once from disk (initialHistory) and kept in sync locally after
    // that; onHistoryChange pushes each update back out for index.tsx to
    // persist, rather than App doing its own file I/O (see AppProps doc).
    const [history, setHistory] = useState(initialHistory);
    // -1 = not currently browsing history (typing fresh). 0 = the most
    // recent entry, counting UP from the end of `history` as Up is pressed
    // repeatedly — matches a normal shell's history navigation direction.
    const [historyIndex, setHistoryIndex] = useState(-1);
    // What was actually typed before Up was first pressed, restored once
    // Down navigates back past the most recent history entry — otherwise
    // browsing history and then returning to "fresh" would silently discard
    // whatever partial text the user had already typed.
    const [historyDraft, setHistoryDraft] = useState("");
    const [contextUsedRatio, setContextUsedRatio] = useState(0);
    const [planProgress, setPlanProgress] = useState(null);
    // Requested directly: the "[compaction complete] ..." log line got
    // pushed out of view by later scrolling activity before it was ever
    // actually noticed. A persistent status-bar indicator instead — same
    // reasoning as planProgress above.
    const [compactionStatus, setCompactionStatus] = useState(null);
    const [menuOpen, setMenuOpen] = useState(false);
    const [menuIndex, setMenuIndex] = useState(0);
    // Rows scrolled up from the live bottom (0 = following the newest output,
    // like a normal terminal). Requested directly: the alt-screen buffer
    // (needed for reliable absolute cursor positioning — see index.tsx) also
    // disables the terminal's own native scrollback as a side effect, so
    // there was no way at all to look back at anything that had scrolled off
    // the fixed-height log box. This restores that ability inside the app
    // itself instead.
    const [scrollOffset, setScrollOffset] = useState(0);
    // Messages typed while the agent is busy wait here instead of being sent
    // immediately; /queue inspects this list (PROMPT.md §6 message queue input).
    // Authoritative copy now lives in AgentLoop (queueMessage/onQueueChange —
    // see AppProps.onQueueMessage), so it's applied at the next turnLoop
    // iteration instead of only after the whole turn finishes; this is a
    // display-only mirror kept in sync via the __llamacli_ui.setQueue below.
    const [queue, setQueue] = useState([]);
    // Tracks which log line the currently-streaming assistant message is
    // appending to, so successive deltas mutate one line instead of spawning
    // a new one per chunk.
    const streamingIdRef = useRef(null);
    // A ref alone (reasoningStreamingIdRef below) doesn't trigger a re-render
    // on change, so the shimmer needs actual state to know THIS render's
    // active line and to drive its own timer.
    const [thinkingLineId, setThinkingLineId] = useState(null);
    // The streaming ASSISTANT line gets the same shining reveal-wave effect
    // reasoning text already has — requested directly: "로그 문자를 생각의
    // 글씨의 빛나는 효과처럼 나타나게 해줘". Shares shimmerTick with
    // reasoning below (reasoning and assistant content don't stream at the
    // same time in practice — reasoning always finishes first — so one
    // counter is enough; each line's OWN reveal wave still starts fresh, via
    // setShimmerTick(0) wherever a new line of either kind begins).
    const [streamingAssistantId, setStreamingAssistantId] = useState(null);
    const [shimmerTick, setShimmerTick] = useState(0);
    useEffect(() => {
        if (thinkingLineId === null && streamingAssistantId === null)
            return;
        const id = setInterval(() => setShimmerTick((t) => t + 1), SHIMMER_TICK_MS);
        return () => clearInterval(id);
    }, [thinkingLineId, streamingAssistantId]);
    const reasoningStreamingIdRef = useRef(null);
    // Finished reasoning blocks the user has clicked open — everything else
    // finished renders as one folded summary line (foldedReasoningSummary).
    // Requested directly: reasoning is useful to check but clutters the log
    // once it's no longer the point of what's on screen.
    const [expandedReasoningIds, setExpandedReasoningIds] = useState(new Set());
    // Diffs are the opposite default: shown expanded (visible right away,
    // since that's the point — the user asked to actually see the change),
    // and only fold down once the next command is submitted (see the Return
    // handler below), rather than needing a click just to see what changed.
    // Still toggleable by click either way afterward.
    const [collapsedDiffIds, setCollapsedDiffIds] = useState(new Set());
    // Rebuilt every render (see the allRows loop) so a click handler — which
    // only runs later, async, in response to a real terminal event — can map
    // the absolute terminal row it landed on back to a log line without
    // recomputing the whole layout itself.
    const clickMapRef = useRef({
        firstRow: 1,
        entries: [],
    });
    // Holds a SGR mouse report that arrived split across two raw stdin
    // chunks — reported directly ("마우스 클릭 또는 휠을 내리면 프롬포트창에
    // 안시코드가 찍혀"): under fast scrolling/clicking, a chunk boundary can
    // land mid-escape-sequence, and the trailing half (e.g. a bare "6M") no
    // longer matches the mouse-report regex on its own, so it was falling
    // through to the plain "insert this character" branch and appearing as
    // literal text in the prompt. Buffered here and reassembled on the next
    // useInput call instead of being typed.
    const mouseBufferRef = useRef("");
    // How far scrollOffset can go before there's nothing further back to see —
    // updated every render (see below) rather than recomputed inside the key
    // handler, which would mean redoing the markdown/wrap rendering work
    // twice per keystroke just to clamp a scroll position.
    const maxScrollRef = useRef(0);
    // Same reasoning as maxScrollRef — needed inside the key handler (for
    // sizing a Page Up/Down jump) before logHeight is computed later in this
    // render, so it's carried over from the previous one instead.
    const logHeightRef = useRef(3);
    const rowCacheRef = useRef(new Map());
    function pushLine(text, kind) {
        setLog((prev) => [...prev, { id: logIdCounter++, text, kind }].slice(-MAX_LOG_ENTRIES));
    }
    function pushAssistantDelta(text) {
        setLog((prev) => {
            if (streamingIdRef.current !== null) {
                return prev.map((line) => line.id === streamingIdRef.current
                    ? // Re-sanitize the whole cumulative text each time, not just
                        // the new chunk — a leaked tool-call template tag (see
                        // src/agent/textSanitize.ts) can arrive split across several
                        // small streaming chunks, so it's only ever complete (and
                        // therefore matchable) once appended to what came before.
                        { ...line, text: stripToolCallTemplateLeak(line.text + text) }
                    : line);
            }
            const id = logIdCounter++;
            streamingIdRef.current = id;
            setStreamingAssistantId(id);
            // A fresh reveal wave for the new line — reusing the running tick
            // count would start it already partway (or fully) revealed.
            setShimmerTick(0);
            return [...prev, { id, text: stripToolCallTemplateLeak(text), kind: "assistant" }].slice(-MAX_LOG_ENTRIES);
        });
    }
    function finalizeAssistant() {
        // The row cache is keyed on (id, text, width) — text doesn't change
        // between the last delta and finalizing, so without this the NEXT
        // render would reuse the streaming render's plain-shimmer rows
        // instead of re-wrapping through markdown now that streaming (and the
        // shimmer) is over.
        if (streamingIdRef.current !== null)
            rowCacheRef.current.delete(streamingIdRef.current);
        streamingIdRef.current = null;
        setStreamingAssistantId(null);
    }
    function pushReasoningDelta(text) {
        setLog((prev) => {
            if (reasoningStreamingIdRef.current !== null) {
                return prev.map((line) => (line.id === reasoningStreamingIdRef.current ? { ...line, text: line.text + text } : line));
            }
            const id = logIdCounter++;
            reasoningStreamingIdRef.current = id;
            setThinkingLineId(id);
            // A fresh reveal wave for the new line — reusing the running tick
            // count would start it already partway (or fully) revealed.
            setShimmerTick(0);
            return [...prev, { id, text, kind: "reasoning" }].slice(-MAX_LOG_ENTRIES);
        });
    }
    function finalizeReasoning() {
        reasoningStreamingIdRef.current = null;
        setThinkingLineId(null);
    }
    function pushCompactionDetail(detail) {
        const foldLabel = foldedCompactionSummary(detail.droppedCount, detail.droppedTokens, detail.keptCount);
        setLog((prev) => [...prev, { id: logIdCounter++, text: compactionDetailBody(detail), kind: "compaction-detail", foldLabel }].slice(-MAX_LOG_ENTRIES));
    }
    function pushToolResult(command, output) {
        const foldLabel = foldedToolResultSummary(command, output);
        setLog((prev) => [...prev, { id: logIdCounter++, text: output, kind: "tool-result", foldLabel }].slice(-MAX_LOG_ENTRIES));
    }
    // Folds every currently-expanded diff to its one-line summary. Diffs
    // default to expanded (the point is to actually see the change), but
    // shouldn't sit taking up the whole log forever — requested directly to
    // fold them once the MODEL starts on the next command ("다음 명령어를
    // 모델이 처리 시작하면 닫힘으로"), not when the human merely presses
    // Enter (an earlier version of this folded on the keypress itself, which
    // was explicitly called out as wrong — a queued/auto-resumed command the
    // model picks up on its own never went through that keypress at all).
    // Wired to loop.ts's onTurnStart (index.tsx). Still re-expandable by click.
    function collapseDiffs() {
        setCollapsedDiffIds((prev) => {
            const next = new Set(prev);
            for (const line of log)
                if (line.kind === "diff")
                    next.add(line.id);
            return next;
        });
    }
    // Echoes the startup resume question into the scrolling log as well as
    // showing it in the input box (see visibleInput below) — reported
    // directly: the input-box-only version wasn't visible on a real
    // terminal ("좌표 문제인듯" / "seems like a coordinate problem"). The
    // input box's text is positioned via delicate absolute-cursor math tied
    // to the terminal's reported size (see the cursor-positioning useEffect
    // further down); if that size is ever misdetected the single-line
    // question can end up genuinely off-screen or overwritten while the rest
    // of the app still looks fine. The log area uses a completely different,
    // independently-wrapped rendering path (wrapPreservingTables/wrapToWidth
    // below), so this guarantees the question is visible regardless of
    // whatever coordinate issue might affect the input box specifically.
    useEffect(() => {
        if (resumeConfirmPending) {
            pushLine(`이전 작업이 있습니다: "${pendingResumeGoal}"\n이어서 진행할까요? Y(예) / N(아니오) 를 입력해주세요.`, "status");
        }
        // Runs once, at mount — resumeConfirmPending only ever starts true and
        // is answered exactly once per session (see useInput below), so there's
        // nothing to re-run this for.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    useInput((rawChar, key) => {
        // Reassemble a mouse report split across chunk boundaries (see
        // mouseBufferRef's doc comment) before anything else looks at it.
        let char = rawChar;
        if (mouseBufferRef.current || /\x1b\[</.test(char)) {
            const outcome = bufferMouseChunk(mouseBufferRef.current, char);
            if (outcome.action === "process") {
                mouseBufferRef.current = "";
                char = outcome.text;
            }
            else {
                // "wait": still incomplete, buffered for the next call. "discard":
                // not actually a mouse report (or corrupted) — dropped. Either way,
                // don't type this fragment or treat it as a real key.
                if (outcome.action === "wait")
                    mouseBufferRef.current = mouseBufferRef.current + char;
                else
                    mouseBufferRef.current = "";
                return;
            }
        }
        // Mouse wheel (reporting enabled in index.tsx). Handled before
        // anything else so a report can never be typed into the input box or
        // answer a Y/N prompt.
        // Every SGR mouse report (wheel, click, release, drag) matches this and
        // must be fully consumed here regardless of which kind it is — parsing
        // it as a wheel event alone first and only checking for a click on a
        // separate early-return path meant a click's own "not a wheel" (0 rows)
        // result from parseMouseWheel already returned before the click parser
        // ever ran, so clicks did nothing. Verified against the real binary
        // (pty + a real terminal emulator) that this was the actual cause.
        if (/\[<\d+;\d+;\d+[Mm]/.test(char)) {
            const wheel = parseMouseWheel(char);
            if (wheel !== null && wheel !== 0 && !menuOpen && quittingSince === null) {
                setScrollOffset((s) => Math.max(0, Math.min(maxScrollRef.current, s + wheel)));
            }
            // A plain click: toggle a folded/expanded reasoning block if it
            // landed on one of its rows. Ignored while the menu is open or
            // saving (the map wasn't built for those layouts).
            if (!menuOpen && quittingSince === null) {
                const { firstRow, entries } = clickMapRef.current;
                for (const { row } of parseMouseClicks(char)) {
                    const idx = row - firstRow;
                    const entry = idx >= 0 && idx < entries.length ? entries[idx] : undefined;
                    if (!entry?.foldable)
                        continue;
                    // Diffs track their FOLDED ids (default expanded); everything
                    // else tracks its EXPANDED ids (default folded) — see
                    // collapsedDiffIds/expandedReasoningIds's own doc comments.
                    const setFn = entry.isDiff ? setCollapsedDiffIds : setExpandedReasoningIds;
                    setFn((prev) => {
                        const next = new Set(prev);
                        if (next.has(entry.lineId))
                            next.delete(entry.lineId);
                        else
                            next.add(entry.lineId);
                        return next;
                    });
                }
            }
            return;
        }
        // Saving before exit: only "quit now without saving" does anything.
        if (quittingSince !== null) {
            if (key.escape || (key.ctrl && char.toLowerCase() === "c")) {
                pushLine("[quitting without waiting for the save]", "status");
                onQuitWithoutSaving();
            }
            return;
        }
        // Ink's default Ctrl-C-exits-the-app behavior is disabled in index.tsx
        // (exitOnCtrlC: false) specifically so this reaches here instead —
        // reported directly: some terminals/users treat Ctrl-C as copy, not an
        // interrupt, and it shouldn't kill llamacli either way. Make it an
        // explicit no-op (not inserted into the input, doesn't touch the
        // menu) rather than falling through to the generic "append this
        // character" branch, which would otherwise insert the raw control
        // byte into whatever you were typing. /quit is still the only way out.
        if (key.ctrl && char.toLowerCase() === "c") {
            return;
        }
        // Startup resume question, answered before anything else can happen —
        // set once from pendingResumeGoal (index.tsx found a checkpoint on
        // disk before this ever rendered) and never re-armed after being
        // answered once, so it can't reappear mid-session.
        if (resumeConfirmPending) {
            const lower = char.toLowerCase();
            if (lower === "y") {
                setResumeConfirmPending(false);
                pushLine("[resuming previous work...]", "status");
                onResumeDecision(true);
            }
            else if (lower === "n" || key.escape) {
                setResumeConfirmPending(false);
                pushLine("[starting fresh — previous checkpoint discarded]", "status");
                onResumeDecision(false);
            }
            // any other key: still waiting for a real y/n answer — ignored.
            return;
        }
        // Esc → Y/N confirmation dialog, entered below. While it's showing,
        // every keystroke is consumed here (y/n/esc) rather than falling
        // through to the menu or normal typing — a stray key must never
        // silently quit the app, and must never silently leak into the input
        // box either.
        if (quitConfirmPending) {
            const lower = char.toLowerCase();
            if (lower === "y") {
                setQuitConfirmPending(false);
                pushLine("[force quitting — saving progress to resume later]", "status");
                onForceQuit();
            }
            else if (lower === "n" || key.escape) {
                setQuitConfirmPending(false);
            }
            // any other key: still waiting for a real y/n answer — ignored.
            return;
        }
        if (menuOpen) {
            // Reported directly: the menu could only be driven with arrow keys —
            // typing the rest of a command's name (the obvious first thing to
            // try after "/") did nothing at all, since this branch previously
            // handled only up/down/return/escape and fell through to `return`
            // for everything else. Filter-as-you-type now works like a normal
            // command palette instead.
            const filtered = filterMenuItems(input);
            if (key.upArrow)
                setMenuIndex((i) => Math.max(0, i - 1));
            else if (key.downArrow)
                setMenuIndex((i) => Math.min(Math.max(0, filtered.length - 1), i + 1));
            else if (key.return) {
                const item = filtered[menuIndex];
                if (!item)
                    return; // no match under the current filter — nothing to select
                setMenuOpen(false);
                setInput("");
                if (item.key === "queue") {
                    pushLine(queue.length
                        ? `Queue (${queue.length}):\n${queue.map((q, i) => `${i + 1}. ${q}`).join("\n")}`
                        : "The queue is empty.", "status");
                }
                else {
                    onSlashCommand(item.key);
                }
            }
            else if (key.escape) {
                setMenuOpen(false);
                setInput("");
            }
            else if (key.backspace || key.delete) {
                // Backspacing the "/" itself closes the menu — matches typing "/"
                // to open it being the exact inverse action, rather than leaving
                // an empty, command-less menu open.
                if (input.length <= 1) {
                    setMenuOpen(false);
                    setInput("");
                }
                else {
                    setInput((s) => s.slice(0, -1));
                    setMenuIndex(0); // narrower/wider filter — re-highlight the top match
                }
            }
            else if (char && !key.ctrl && !key.meta) {
                setInput((s) => s + char);
                setMenuIndex(0);
            }
            return;
        }
        // Esc (menu not open, no confirmation already showing) opens the force-
        // quit confirmation above — works at any time, not just while a turn is
        // running, so it doubles as a quick "get me out of here" independent of
        // /quit's normal self-improvement-review gate. Also echoed into the log
        // (not just the input box) for the same visibility reason as the
        // startup resume question above.
        if (key.escape) {
            setQuitConfirmPending(true);
            pushLine("강제 종료하시겠습니까? 진행 중인 작업은 저장되어 다음 실행 시 이어집니다.\nY(예) / N(아니오) 를 입력해주세요.", "status");
            return;
        }
        // PageUp/PageDown scroll the log a full screen at a time — unaffected
        // by the history repurposing below (Ink gives an empty `char` for
        // these, so the fallback append-to-input further down was already a
        // harmless no-op for them).
        if (key.pageUp || key.pageDown) {
            const amount = Math.max(1, logHeightRef.current - 1);
            const direction = key.pageUp ? 1 : -1;
            setScrollOffset((s) => Math.max(0, Math.min(maxScrollRef.current, s + amount * direction)));
            return;
        }
        // Plain Up/Down: prompt history, matching a normal shell. (Previously
        // these did line-by-line log scrollback — moved to PageUp/PageDown-only
        // above, since history is the far more commonly reached-for behavior
        // for arrow keys specifically, and Page Up/Down already covers
        // scrollback on its own.)
        if (key.upArrow || key.downArrow) {
            if (history.length === 0)
                return;
            if (key.upArrow) {
                if (historyIndex >= history.length - 1)
                    return; // already at the oldest entry
                if (historyIndex === -1)
                    setHistoryDraft(input); // stash what was being typed
                const next = historyIndex + 1;
                setHistoryIndex(next);
                setInput(history[history.length - 1 - next]);
            }
            else {
                if (historyIndex === -1)
                    return; // not currently browsing — nothing to go back to
                const next = historyIndex - 1;
                setHistoryIndex(next);
                setInput(next === -1 ? historyDraft : history[history.length - 1 - next]);
            }
            return;
        }
        if (key.return) {
            if (input.trim().length === 0)
                return;
            if (busy) {
                onQueueMessage(input);
                pushLine(`[queued] ${input}`, "status");
            }
            else {
                pushLine(input, "user");
                onSubmit(input);
            }
            // Every actually-submitted prompt (sent now or queued) joins history —
            // see appendHistory's doc comment on why both count.
            setHistory((h) => {
                const next = appendHistory(h, input);
                onHistoryChange(next);
                return next;
            });
            setHistoryIndex(-1);
            setHistoryDraft("");
            setInput("");
            // A message you just sent should be visible without having to
            // manually scroll back down for it — snap back to the live tail,
            // matching how a normal chat/terminal view behaves.
            setScrollOffset(0);
            return;
        }
        if (key.backspace || key.delete) {
            setInput((s) => s.slice(0, -1));
            return;
        }
        if (char === "/" && input.length === 0) {
            setMenuOpen(true);
            setMenuIndex(0);
            setInput("/");
            return;
        }
        setInput((s) => s + char);
    });
    // TODO: replace with a proper imperative handle / event emitter once the
    // agent loop is wired to real streaming; global is a placeholder only.
    globalThis.__llamacli_ui = {
        pushAssistantDelta,
        finalizeAssistant,
        pushReasoningDelta,
        finalizeReasoning,
        pushCompactionDetail,
        pushToolResult,
        collapseDiffs,
        setQueue,
        pushStatus: (t) => pushLine(t, "status"),
        pushTool: (t) => pushLine(t, "tool"),
        pushDiff: (t) => pushLine(t, "diff"),
        setBusy,
        isBusy: () => busy,
        beginQuitting: () => setQuittingSince((t) => t ?? Date.now()),
        setContextUsedRatio,
        setPlanProgress: (done, total) => setPlanProgress(total > 0 ? { done, total } : null),
        setCompactionStatus: (state, timestamp) => setCompactionStatus({ state, timestamp }),
    };
    const rows = stdout?.rows ?? 24;
    const columns = stdout?.columns ?? 80;
    // The input row must always be exactly one terminal row. Ink wraps a
    // <Text> that's wider than the terminal instead of clipping it, so a long
    // typed line silently grew this row to several — and since the total
    // layout height is fixed (see logHeight below), that overflow scrolled
    // the real terminal, leaving ghosting when it shrank back down. Truncate
    // to what actually fits instead of ever letting the input Text wrap.
    // Reserves 2 extra columns for the input box's own left+right border
    // characters (see the bordered Box below) on top of its padding/spinner/space.
    const maxInputWidth = Math.max(10, columns - 6);
    const quitting = quittingSince !== null;
    const QUIT_CONFIRM_TEXT = "강제 종료하시겠습니까? 진행 중인 작업은 저장되어 다음 실행 시 이어집니다. (Y/N)";
    const RESUME_CONFIRM_TEXT = pendingResumeGoal
        ? `이전 작업을 이어서 하시겠습니까? "${pendingResumeGoal}" (Y/N)`
        : "";
    const quittingText = quitting ? quittingStatusText(Date.now() - quittingSince) : "";
    const visibleInput = quitting
        ? tailToWidth(quittingText, maxInputWidth)
        : resumeConfirmPending
            ? tailToWidth(RESUME_CONFIRM_TEXT, maxInputWidth)
            : quitConfirmPending
                ? tailToWidth(QUIT_CONFIRM_TEXT, maxInputWidth)
                : tailToWidth(input, maxInputWidth);
    // logHeight is a CONSTANT, independent of menu state — this is the outer
    // log-area Box's actual `height`, and it must never change, because
    // changing it is what breaks things: (1) shrinking it only while the
    // menu was open shifted everything below (input box, status bar) by up
    // to ~10 rows in one frame, and Ink's incremental diffing didn't fully
    // clear the old content at the shifted-from position, leaving stale
    // fragments right on the input box's border (confirmed via a screen
    // recording: a leftover "셀" there after closing the menu). (2)
    // Permanently reserving the menu's height as a *separate* fixed box
    // avoided that, but left a permanent empty gap between the log and the
    // input box whenever the menu was closed (reported directly: text
    // "doesn't reach down to the prompt input"). (3) `position="absolute"`
    // to overlay it doesn't work in Ink 4.x — it only sets the Yoga position
    // TYPE, not an actual offset (no top/left/right/bottom style exists),
    // and a `marginTop` substitute pushed the menu's output past the
    // `overflow: hidden` boundary instead of being clipped, scrolling the
    // real terminal (confirmed by direct byte capture).
    //
    // The fix: keep this Box's height fixed at all times, and instead change
    // what's rendered *inside* it — when the menu is open, show fewer log
    // rows and the menu in the space freed up, all within the SAME
    // never-changing box. The outer box's contribution to the layout is
    // therefore always exactly `logHeight`, so nothing below it ever needs
    // to move, and nothing is permanently reserved when the menu is closed.
    const menuBoxHeight = SLASH_MENU_ITEMS.length + 2; // round border top+bottom
    // Fixed chrome below the log area: input box top border(1) + content(1) +
    // bottom border(1) + status bar(1).
    const logHeight = Math.max(3, rows - 4);
    logHeightRef.current = logHeight;
    // Absolute cursor positioning, reliable because index.tsx switches to the
    // terminal's alternate screen buffer before rendering (giving row 1 a
    // fixed, known meaning) and the app's total height is now provably
    // constant every frame regardless of menu state.
    useEffect(() => {
        const inputRow = logHeight + 1 /* input box top border */ + 1; // 1-indexed content row
        const promptColumn = 1 /* input box left border */ + 1 /* paddingX */ + 1 /* spinner */ + 1 /* leading space */ + stringWidth(visibleInput) + 1;
        const hideCursor = shouldHideCursor({ quitting, busy, input });
        process.stdout.write(`\x1b[${inputRow};${promptColumn}H${hideCursor ? "\x1b[?25l" : "\x1b[?25h"}`);
    });
    // Every log entry is wrapped into terminal rows once and cached by id
    // (recomputed only when its text or the width changes — e.g. the
    // streaming assistant line), and React elements are built only for the
    // visible window. Previously only the last max(logHeight*5, 50) entries
    // were flattened at all, to keep each render cheap — which also capped
    // how far PageUp could go: reported directly, older output of a long
    // session couldn't be scrolled back to.
    //
    // Ink/Yoga gives an empty-string <Text> ZERO rendered height — not one
    // row like every other line — which made the flex-end log box fall short
    // of `logHeight` and show a gap at the top. A single space renders as a
    // real one-row blank line instead.
    const asRow = (s) => s || " ";
    const width = Math.max(10, columns);
    const rowCache = rowCacheRef.current;
    const liveIds = new Set();
    const allRows = [];
    for (const line of log) {
        liveIds.add(line.id);
        // A finished (not actively streaming) reasoning block: fold to one
        // summary row unless the user has expanded it. Handled here, outside
        // the wrap cache below, since the cache is keyed on (text, width) —
        // fold state isn't either of those, and re-deriving the fold decision
        // fresh each render is cheap (no re-wrapping needed for the common,
        // folded case).
        if (line.kind === "reasoning" && line.id !== thinkingLineId) {
            if (!expandedReasoningIds.has(line.id)) {
                allRows.push({ key: `${line.id}-fold`, text: foldedReasoningSummary(line.text), kind: "reasoning-folded", lineId: line.id });
                continue;
            }
            let cached = rowCache.get(line.id);
            if (!cached || cached.text !== line.text || cached.width !== width) {
                cached = { text: line.text, width, rows: wrapLogLine(line, width).map(asRow) };
                rowCache.set(line.id, cached);
            }
            cached.rows.forEach((text, i) => allRows.push({ key: `${line.id}-${i}`, text, kind: line.kind, lineId: line.id }));
            allRows.push({ key: `${line.id}-fold-hint`, text: foldToggleHintExpanded, kind: "reasoning-folded", lineId: line.id });
            continue;
        }
        // Compaction before/after detail: same fold-by-default, click-to-expand
        // pattern as reasoning, just always foldable (never "currently
        // streaming") and using its own precomputed label instead of deriving
        // one from the (here, already-expanded-body) text.
        if (line.kind === "compaction-detail") {
            if (!expandedReasoningIds.has(line.id)) {
                allRows.push({
                    key: `${line.id}-fold`,
                    text: line.foldLabel ?? "▸ 압축 완료 — 클릭해서 펼치기",
                    kind: "compaction-detail-folded",
                    lineId: line.id,
                });
                continue;
            }
            let cached = rowCache.get(line.id);
            if (!cached || cached.text !== line.text || cached.width !== width) {
                cached = { text: line.text, width, rows: wrapLogLine(line, width).map(asRow) };
                rowCache.set(line.id, cached);
            }
            cached.rows.forEach((text, i) => allRows.push({ key: `${line.id}-${i}`, text, kind: line.kind, lineId: line.id }));
            allRows.push({ key: `${line.id}-fold-hint`, text: foldToggleHintExpanded, kind: "compaction-detail-folded", lineId: line.id });
            continue;
        }
        if (line.kind === "tool-result") {
            let cached = rowCache.get(line.id);
            if (!cached || cached.text !== line.text || cached.width !== width) {
                cached = { text: line.text, width, rows: wrapLogLine(line, width).map(asRow) };
                rowCache.set(line.id, cached);
            }
            // Only worth folding when it actually spans more than one line —
            // requested directly ("도구 사용도 출력도 한 줄이 넘으면 ... 자동으로
            // 닫힘"): a one-line result folding down to a one-line summary just
            // to be clicked back open is pure friction, not decluttering.
            if (cached.rows.length <= 1) {
                cached.rows.forEach((text, i) => allRows.push({ key: `${line.id}-${i}`, text, kind: line.kind, lineId: line.id }));
                continue;
            }
            if (!expandedReasoningIds.has(line.id)) {
                allRows.push({
                    key: `${line.id}-fold`,
                    text: line.foldLabel ?? "▸ 결과 — 클릭해서 펼치기",
                    kind: "tool-result-folded",
                    lineId: line.id,
                });
                continue;
            }
            cached.rows.forEach((text, i) => allRows.push({ key: `${line.id}-${i}`, text, kind: line.kind, lineId: line.id }));
            allRows.push({ key: `${line.id}-fold-hint`, text: foldToggleHintExpanded, kind: "tool-result-folded", lineId: line.id });
            continue;
        }
        // Diffs: opposite default from the two folds above (see
        // collapsedDiffIds's doc comment) — shown in full unless collapsed,
        // either by clicking or because the next command was submitted.
        if (line.kind === "diff") {
            if (collapsedDiffIds.has(line.id)) {
                allRows.push({ key: `${line.id}-fold`, text: line.foldLabel ?? foldedDiffSummary(line.text), kind: "diff-folded", lineId: line.id });
                continue;
            }
            let cached = rowCache.get(line.id);
            if (!cached || cached.text !== line.text || cached.width !== width) {
                cached = { text: line.text, width, rows: wrapLogLine(line, width).map(asRow) };
                rowCache.set(line.id, cached);
            }
            cached.rows.forEach((text, i) => allRows.push({ key: `${line.id}-${i}`, text, kind: line.kind, lineId: line.id }));
            allRows.push({ key: `${line.id}-fold-hint`, text: foldToggleHintExpanded, kind: "diff-folded", lineId: line.id });
            continue;
        }
        // The currently-streaming assistant line gets the same shining
        // reveal-wave effect reasoning already has (see streamingAssistantId's
        // doc comment) — plain wrapping, not markdown, while it's playing:
        // shimmerBands slices raw characters, which would tear markdown's own
        // embedded ANSI color codes apart. Reverts to real markdown rendering
        // once finalizeAssistant() clears streamingAssistantId (and this same
        // id's stale cache entry, so the next render re-wraps instead of
        // reusing these plain rows).
        if (line.kind === "assistant" && line.id === streamingAssistantId) {
            let cached = rowCache.get(line.id);
            if (!cached || cached.text !== line.text || cached.width !== width) {
                cached = { text: line.text, width, rows: wrapToWidth(line.text, width).map(asRow) };
                rowCache.set(line.id, cached);
            }
            cached.rows.forEach((text, i) => allRows.push({ key: `${line.id}-${i}`, text, kind: line.kind, lineId: line.id }));
            continue;
        }
        let cached = rowCache.get(line.id);
        if (!cached || cached.text !== line.text || cached.width !== width) {
            cached = { text: line.text, width, rows: wrapLogLine(line, width).map(asRow) };
            rowCache.set(line.id, cached);
        }
        cached.rows.forEach((text, i) => allRows.push({ key: `${line.id}-${i}`, text, kind: line.kind, lineId: line.id }));
    }
    if (rowCache.size > liveIds.size) {
        for (const id of rowCache.keys())
            if (!liveIds.has(id))
                rowCache.delete(id);
    }
    // Content rows available to the log itself (as opposed to the menu, or
    // the one-row scroll indicator below) — reserving a row for the
    // indicator ahead of actually being scrolled (rather than only once
    // scrollOffset > 0) keeps maxScrollRef consistent regardless of current
    // scroll position, avoiding a circular "how much can I scroll depends on
    // whether I'm already scrolled" dependency.
    // One row at the bottom of the log area goes to the key hint, only while
    // the agent is running.
    const showRunHint = busy && !quitting && !quitConfirmPending && !resumeConfirmPending && !menuOpen;
    const hintRows = showRunHint ? 1 : 0;
    const scrollableContentRows = menuOpen
        ? Math.max(0, logHeight - menuBoxHeight)
        : Math.max(0, logHeight - 1 - hintRows);
    const maxScroll = Math.max(0, allRows.length - scrollableContentRows);
    maxScrollRef.current = maxScroll;
    const clampedScroll = menuOpen ? 0 : Math.min(scrollOffset, maxScroll);
    const showScrollIndicator = !menuOpen && clampedScroll > 0;
    const contentRows = menuOpen ? scrollableContentRows : logHeight - (showScrollIndicator ? 1 : 0) - hintRows;
    const sliceEnd = allRows.length - clampedScroll;
    const sliceStart = Math.max(0, sliceEnd - contentRows);
    // Absolute terminal row of the first visible content row, for mapping a
    // mouse click's (row, col) back to a log line. The log box is bottom-
    // anchored (flex-end) at fixed height `logHeight` starting at terminal
    // row 1 (the alt screen's origin — see index.tsx): any leftover space
    // when there's less content than the box's height sits ABOVE it, not
    // below, so the first content row isn't always row 1.
    {
        const visibleCount = sliceEnd - sliceStart;
        const childrenHeight = (showScrollIndicator ? 1 : 0) + visibleCount + (menuOpen ? menuBoxHeight : 0) + hintRows;
        const gap = Math.max(0, logHeight - childrenHeight);
        clickMapRef.current = {
            firstRow: 1 + gap + (showScrollIndicator ? 1 : 0),
            entries: allRows
                .slice(sliceStart, sliceEnd)
                .map((r) => ({
                lineId: r.lineId,
                foldable: r.kind === "reasoning" ||
                    r.kind === "reasoning-folded" ||
                    r.kind === "compaction-detail" ||
                    r.kind === "compaction-detail-folded" ||
                    r.kind === "tool-result" ||
                    r.kind === "tool-result-folded" ||
                    r.kind === "diff" ||
                    r.kind === "diff-folded",
                isDiff: r.kind === "diff" || r.kind === "diff-folded",
            })),
        };
    }
    const inputBorderColor = quitting || quitConfirmPending || resumeConfirmPending
        ? "yellow"
        : busy
            ? "magenta"
            : input.length > 0
                ? "cyan"
                : "gray";
    return (React.createElement(Box, { flexDirection: "column", height: rows, overflow: "hidden" },
        React.createElement(Box, { flexDirection: "column", height: logHeight, overflow: "hidden", justifyContent: "flex-end" },
            showScrollIndicator && (React.createElement(Text, { dimColor: true }, `── ↑ scrolled up ${clampedScroll} line${clampedScroll === 1 ? "" : "s"} · ↓/PageDown to return to live ──`.slice(0, Math.max(10, columns)))),
            allRows
                .slice(sliceStart, sliceEnd)
                .map((row) => renderRow(row, row.lineId === thinkingLineId || row.lineId === streamingAssistantId ? shimmerTick : undefined)),
            menuOpen && React.createElement(SlashMenu, { items: filterMenuItems(input), selectedIndex: menuIndex }),
            showRunHint && React.createElement(Text, { dimColor: true }, runHintText(columns))),
        React.createElement(Box, { borderStyle: "round", borderColor: inputBorderColor, paddingX: 1, height: 3, overflow: "hidden" },
            React.createElement(Spinner, { active: busy || quitting }),
            React.createElement(Text, { color: quitting || quitConfirmPending || resumeConfirmPending ? "yellow" : undefined },
                " ",
                visibleInput)),
        React.createElement(StatusBar, { cwd: cwd, model: model, contextUsedRatio: contextUsedRatio, planProgress: planProgress, compactionStatus: compactionStatus, columns: columns })));
}
