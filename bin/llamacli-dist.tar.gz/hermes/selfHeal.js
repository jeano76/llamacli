/**
 * PROMPT.md §3: self-healing retry loop with a mandatory circuit breaker.
 * Modeled after the loop-runaway incident documented in the user's CLINE
 * delegation rules (~/.claude/CLAUDE.md) — a repeating read/edit/read/edit
 * pattern must be detected and killed, not left to run indefinitely.
 */
export const DEFAULT_BREAKER = {
    windowSize: 12,
    maxDistinct: 3,
    hardTimeoutMs: 30 * 60_000,
};
export class CircuitBreaker {
    config;
    history = [];
    // Tracks time since the *last actual progress* (a tool call completing),
    // not since the turn started. A long turn that keeps genuinely completing
    // tool calls — e.g. many rounds against a slow local model — can easily
    // run past hardTimeoutMs in total without ever being stuck; only a gap
    // with zero progress for that long indicates something is actually hung.
    // See the loop-runaway incident in the class doc comment above.
    lastProgressAt = Date.now();
    constructor(config = DEFAULT_BREAKER) {
        this.config = config;
    }
    record(call) {
        this.history.push(call);
        if (this.history.length > this.config.windowSize) {
            this.history.shift();
        }
        this.lastProgressAt = Date.now();
    }
    /** Returns a reason string if the loop/timeout should be killed, else null. */
    shouldStop() {
        if (Date.now() - this.lastProgressAt > this.config.hardTimeoutMs) {
            return `hard timeout exceeded (${this.config.hardTimeoutMs}ms with no progress)`;
        }
        if (this.history.length < this.config.windowSize)
            return null;
        const distinct = new Set(this.history.map((c) => `${c.toolName}:${c.argsSignature}`));
        if (distinct.size <= this.config.maxDistinct) {
            return `repetitive tool-call loop detected (${distinct.size} distinct calls in last ${this.history.length})`;
        }
        return null;
    }
    reset() {
        this.history = [];
        this.lastProgressAt = Date.now();
    }
}
const failureLog = [];
// Module-level, so it lives for the whole process — a long-running session
// with a persistently misbehaving tool/backend would otherwise grow this
// without bound. It's also sent to the model WHOLESALE on every real-time
// improvement check (selfImprove.ts's proposeImprovement(getFailureLog(),
// ...), called via loop.ts's triggerRealtimeImprovementCheck after every
// new failure) — an unbounded log means that request keeps growing too,
// not just this array. Recent failures are what a pattern-detection pass
// actually needs; keep only those.
const MAX_FAILURE_LOG = 100;
export function logFailure(entry) {
    failureLog.push(entry);
    if (failureLog.length > MAX_FAILURE_LOG) {
        failureLog.splice(0, failureLog.length - MAX_FAILURE_LOG);
    }
}
export function getFailureLog() {
    return failureLog;
}
/** Exposed mainly for tests: this log is module-level (shared across every
 *  AgentLoop in the process), so tests that assert on it need a clean
 *  slate rather than accumulating entries left behind by earlier tests. */
export function clearFailureLog() {
    failureLog.length = 0;
}
