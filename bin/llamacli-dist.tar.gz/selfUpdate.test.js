import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, writeFile, mkdir } from "node:fs/promises";
import { createHash } from "node:crypto";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { sha256Hex, parseManifest, updateAvailable, checkAndApplyUpdate, LOCAL_HASH_FILE } from "./selfUpdate.js";
const execFileAsync = promisify(execFile);
async function withTempDir(fn) {
    const dir = await mkdtemp(join(tmpdir(), "llamacli-selfupdate-test-"));
    try {
        await fn(dir);
    }
    finally {
        await rm(dir, { recursive: true, force: true });
    }
}
/** Builds a real tar.gz (using the actual `tar` binary, same as
 *  scripts/update-bin.mjs and checkAndApplyUpdate itself use) from a set
 *  of {path: content} files, and returns its bytes + sha256 — so these
 *  tests exercise real archive creation/extraction rather than mocking it
 *  away, the one part of this module that genuinely needs a real
 *  filesystem + subprocess to mean anything. */
async function buildFixtureArchive(files) {
    return withTempDirReturning(async (srcDir) => {
        for (const [path, content] of Object.entries(files)) {
            await mkdir(join(srcDir, join(path, "..")), { recursive: true });
            await writeFile(join(srcDir, path), content, "utf8");
        }
        const archivePath = join(srcDir, "..", `fixture-${Date.now()}-${Math.random().toString(36).slice(2)}.tar.gz`);
        await execFileAsync("tar", ["-czf", archivePath, "-C", srcDir, "."]);
        const bytes = await readFile(archivePath);
        await rm(archivePath, { force: true });
        return { bytes, sha256: sha256Hex(bytes) };
    });
}
async function withTempDirReturning(fn) {
    const dir = await mkdtemp(join(tmpdir(), "llamacli-fixture-"));
    try {
        return await fn(dir);
    }
    finally {
        await rm(dir, { recursive: true, force: true });
    }
}
test("sha256Hex is a real, deterministic sha256 of its input", () => {
    const a = sha256Hex("hello world");
    assert.match(a, /^[0-9a-f]{64}$/);
    assert.equal(a, sha256Hex("hello world"));
    assert.notEqual(a, sha256Hex("hello world!"));
    assert.equal(a, createHash("sha256").update("hello world").digest("hex"));
});
test("parseManifest accepts a well-formed manifest and rejects a malformed one", () => {
    const good = parseManifest(JSON.stringify({ version: "v20260924", sha256: "a".repeat(64) }));
    assert.equal(good.version, "v20260924");
    assert.equal(good.sha256, "a".repeat(64));
    assert.throws(() => parseManifest(JSON.stringify({ version: "v20260924", sha256: "not-hex" })));
    assert.throws(() => parseManifest(JSON.stringify({ sha256: "a".repeat(64) })));
    assert.throws(() => parseManifest("not json at all"));
});
test("updateAvailable compares hashes (case-insensitively), not version strings", () => {
    const manifest = { version: "v20260924", sha256: "a".repeat(64) };
    assert.equal(updateAvailable("b".repeat(64), manifest), true);
    assert.equal(updateAvailable("a".repeat(64), manifest), false);
    assert.equal(updateAvailable("A".repeat(64), manifest), false, "hash comparison must not be case-sensitive");
});
test("checkAndApplyUpdate extracts a new dist/ archive over the local one, only when its hash matches the manifest both before AND after the write", () => withTempDir(async (distDir) => {
    await writeFile(join(distDir, "index.js"), "old index.js", "utf8");
    await mkdir(join(distDir, "tui"), { recursive: true });
    await writeFile(join(distDir, "tui", "App.js"), "old App.js", "utf8");
    await writeFile(join(distDir, LOCAL_HASH_FILE), "b".repeat(64), "utf8");
    const { bytes: newArchive, sha256: newSha256 } = await buildFixtureArchive({
        "index.js": "new index.js",
        "tui/App.js": "new App.js",
    });
    const manifestBody = JSON.stringify({ version: "v20260925", sha256: newSha256 });
    const fetchImpl = (async (url) => {
        if (url.endsWith("manifest.json"))
            return { ok: true, status: 200, text: async () => manifestBody };
        if (url.endsWith(".tar.gz")) {
            return {
                ok: true,
                status: 200,
                arrayBuffer: async () => newArchive.buffer.slice(newArchive.byteOffset, newArchive.byteOffset + newArchive.byteLength),
            };
        }
        throw new Error(`unexpected url in test: ${url}`);
    });
    const result = await checkAndApplyUpdate(distDir, { fetchImpl });
    assert.equal(result.updated, true);
    assert.match(result.reason, /v20260925/);
    assert.equal(await readFile(join(distDir, "index.js"), "utf8"), "new index.js");
    assert.equal(await readFile(join(distDir, "tui", "App.js"), "utf8"), "new App.js");
    assert.equal(await readFile(join(distDir, LOCAL_HASH_FILE), "utf8"), newSha256, "the local hash marker must be updated too, or the next startup would try to update again forever");
}));
test("checkAndApplyUpdate reports already up to date, and touches nothing, when local and remote hashes match", () => withTempDir(async (distDir) => {
    await writeFile(join(distDir, "index.js"), "same content", "utf8");
    const sameSha256 = "c".repeat(64);
    await writeFile(join(distDir, LOCAL_HASH_FILE), sameSha256, "utf8");
    const fetchImpl = (async (url) => {
        if (url.endsWith("manifest.json")) {
            return { ok: true, status: 200, text: async () => JSON.stringify({ version: "v20260924", sha256: sameSha256 }) };
        }
        throw new Error("the archive should never be fetched when already up to date");
    });
    const result = await checkAndApplyUpdate(distDir, { fetchImpl });
    assert.equal(result.updated, false);
    assert.match(result.reason, /up to date/);
    assert.equal(await readFile(join(distDir, "index.js"), "utf8"), "same content");
}));
test("checkAndApplyUpdate refuses to install when the downloaded archive's hash doesn't match the manifest — the exact scenario the two-hash-check requirement exists for", () => withTempDir(async (distDir) => {
    await writeFile(join(distDir, "index.js"), "old index.js", "utf8");
    await writeFile(join(distDir, LOCAL_HASH_FILE), "b".repeat(64), "utf8");
    // Manifest claims one hash; the actual downloaded bytes are a
    // DIFFERENT (validly-built!) archive — corrupted in transit, or a
    // stale/mismatched manifest. This must never be installed.
    const claimedButWrongSha256 = "f".repeat(64);
    const { bytes: actuallyDownloaded } = await buildFixtureArchive({ "index.js": "tampered index.js" });
    const fetchImpl = (async (url) => {
        if (url.endsWith("manifest.json")) {
            return { ok: true, status: 200, text: async () => JSON.stringify({ version: "v20260925", sha256: claimedButWrongSha256 }) };
        }
        if (url.endsWith(".tar.gz")) {
            return {
                ok: true,
                status: 200,
                arrayBuffer: async () => actuallyDownloaded.buffer.slice(actuallyDownloaded.byteOffset, actuallyDownloaded.byteOffset + actuallyDownloaded.byteLength),
            };
        }
        throw new Error(`unexpected url in test: ${url}`);
    });
    const result = await checkAndApplyUpdate(distDir, { fetchImpl });
    assert.equal(result.updated, false);
    assert.match(result.reason, /hash/i);
    assert.equal(await readFile(join(distDir, "index.js"), "utf8"), "old index.js", "must never overwrite the working dist/ with unverified content");
}));
test("checkAndApplyUpdate never throws and leaves dist/ alone when the network is unreachable", () => withTempDir(async (distDir) => {
    await writeFile(join(distDir, "index.js"), "old index.js", "utf8");
    await writeFile(join(distDir, LOCAL_HASH_FILE), "b".repeat(64), "utf8");
    const fetchImpl = (async () => {
        throw new Error("network unreachable");
    });
    const result = await checkAndApplyUpdate(distDir, { fetchImpl });
    assert.equal(result.updated, false);
    assert.match(result.reason, /network unreachable/);
    assert.equal(await readFile(join(distDir, "index.js"), "utf8"), "old index.js");
}));
test("checkAndApplyUpdate reports failure (not a throw) when the manifest is malformed", () => withTempDir(async (distDir) => {
    await writeFile(join(distDir, "index.js"), "old index.js", "utf8");
    await writeFile(join(distDir, LOCAL_HASH_FILE), "b".repeat(64), "utf8");
    const fetchImpl = (async () => ({ ok: true, status: 200, text: async () => "not valid json" }));
    const result = await checkAndApplyUpdate(distDir, { fetchImpl });
    assert.equal(result.updated, false);
    assert.equal(await readFile(join(distDir, "index.js"), "utf8"), "old index.js");
}));
test("checkAndApplyUpdate fails gracefully (not a throw) when there's no local hash file to compare against yet", () => withTempDir(async (distDir) => {
    await writeFile(join(distDir, "index.js"), "old index.js", "utf8");
    // No LOCAL_HASH_FILE written — simulates a dist/ built before this
    // mechanism existed.
    const fetchImpl = (async () => ({ ok: true, status: 200, text: async () => JSON.stringify({ version: "v1", sha256: "a".repeat(64) }) }));
    const result = await checkAndApplyUpdate(distDir, { fetchImpl });
    assert.equal(result.updated, false);
    assert.match(result.reason, /local build hash/);
}));
test("checkAndApplyUpdate calls onUpdateFound exactly once, before the archive download, only when an update is actually available", () => withTempDir(async (distDir) => {
    // Reported directly: "업데이트 시작과 종료를 명시적으로 알려줘야
    // 하고" — the caller (index.tsx) needs a hook to announce the update
    // BEFORE the download/verify/install work starts, not only after
    // everything already finished, or the process-exit-and-restart
    // transition reads as a crash instead of an update in progress.
    await writeFile(join(distDir, "index.js"), "old index.js", "utf8");
    await writeFile(join(distDir, LOCAL_HASH_FILE), "b".repeat(64), "utf8");
    const { bytes: newArchive, sha256: newSha256 } = await buildFixtureArchive({ "index.js": "new index.js" });
    const manifestBody = JSON.stringify({ version: "v20260925", sha256: newSha256 });
    const calls = [];
    const foundManifests = [];
    const fetchImpl = (async (url) => {
        calls.push(url.endsWith("manifest.json") ? "manifest" : "archive");
        if (url.endsWith("manifest.json"))
            return { ok: true, status: 200, text: async () => manifestBody };
        return {
            ok: true,
            status: 200,
            arrayBuffer: async () => newArchive.buffer.slice(newArchive.byteOffset, newArchive.byteOffset + newArchive.byteLength),
        };
    });
    const result = await checkAndApplyUpdate(distDir, {
        fetchImpl,
        onUpdateFound: (manifest) => foundManifests.push(manifest),
    });
    assert.equal(result.updated, true);
    assert.equal(foundManifests.length, 1, "onUpdateFound must fire exactly once");
    assert.equal(foundManifests[0].version, "v20260925");
    // The callback must fire before the archive is fetched, not after —
    // that's the entire point (announce before the work, not after).
    assert.deepEqual(calls, ["manifest", "archive"]);
}));
test("checkAndApplyUpdate never calls onUpdateFound when already up to date", () => withTempDir(async (distDir) => {
    await writeFile(join(distDir, "index.js"), "old index.js", "utf8");
    await writeFile(join(distDir, LOCAL_HASH_FILE), "a".repeat(64), "utf8");
    const fetchImpl = (async () => ({ ok: true, status: 200, text: async () => JSON.stringify({ version: "v1", sha256: "a".repeat(64) }) }));
    let fired = false;
    const result = await checkAndApplyUpdate(distDir, { fetchImpl, onUpdateFound: () => { fired = true; } });
    assert.equal(result.updated, false);
    assert.equal(fired, false);
}));
test("checkAndApplyUpdate never calls onUpdateFound when the manifest fetch itself fails", () => withTempDir(async (distDir) => {
    await writeFile(join(distDir, "index.js"), "old index.js", "utf8");
    await writeFile(join(distDir, LOCAL_HASH_FILE), "b".repeat(64), "utf8");
    const fetchImpl = (async () => { throw new Error("network unreachable"); });
    let fired = false;
    const result = await checkAndApplyUpdate(distDir, { fetchImpl, onUpdateFound: () => { fired = true; } });
    assert.equal(result.updated, false);
    assert.equal(fired, false);
}));
// ── the opt-out ─────────────────────────────────────────────────────────────
// Added after the updater silently replaced a local `npm run build` during
// terminal-compatibility testing: it downloads the published archive straight
// over dist/, so you end up testing the published binary and believing you
// tested your change, with no way to stop it.
test("LLAMACLI_NO_UPDATE=1 disables the check entirely — no fetch, no write", async () => {
    await withTempDir(async (dir) => {
        // A fetchImpl that throws if called at all: the opt-out has to be
        // absolute, not merely "skip the install step".
        const boom = (async () => {
            throw new Error("network must not be touched when self-update is disabled");
        });
        const result = await checkAndApplyUpdate(dir, {
            fetchImpl: boom,
            env: { LLAMACLI_NO_UPDATE: "1" },
        });
        assert.equal(result.updated, false);
        assert.match(result.reason, /LLAMACLI_NO_UPDATE/);
    });
});
test("the update URLs are overridable from the environment", async () => {
    await withTempDir(async (dir) => {
        // A real tar.gz of a dist tree, so the install path actually runs and
        // the archive fetch is reached. The manifest's sha256 has to be the real
        // one or the install correctly bails on a hash mismatch before fetching.
        const stage = join(dir, "staged");
        await mkdir(join(stage, "tui"), { recursive: true });
        await writeFile(join(stage, "index.js"), "console.log('new')\n");
        await writeFile(join(stage, "tui", "App.js"), "export const x = 1;\n");
        const tgz = join(dir, "arch.tar.gz");
        await execFileAsync("tar", ["-czf", tgz, "-C", stage, "."]);
        const bytes = await readFile(tgz);
        const sha = createHash("sha256").update(bytes).digest("hex");
        // A local build hash is required before the archive is even fetched
        // (that comparison is the whole "is there an update" decision), so the
        // dist dir needs one that differs from the manifest's.
        await writeFile(join(dir, LOCAL_HASH_FILE), "0000");
        const archiveUrl = "https://example.invalid/arch.tar.gz";
        const manifestUrl = "https://example.invalid/manifest.json";
        const seen = [];
        const fetchImpl = (async (u) => {
            seen.push(String(u));
            if (String(u) === manifestUrl) {
                return new Response(JSON.stringify({ version: "v9", sha256: sha }), { status: 200 });
            }
            return new Response(bytes, { status: 200 });
        });
        const result = await checkAndApplyUpdate(dir, {
            fetchImpl,
            env: { LLAMACLI_UPDATE_MANIFEST_URL: manifestUrl, LLAMACLI_UPDATE_ARCHIVE_URL: archiveUrl },
        });
        assert.ok(seen.includes(manifestUrl), "should have fetched the overridden manifest URL");
        assert.ok(seen.includes(archiveUrl), "should have fetched the overridden archive URL");
        assert.equal(result.updated, true, `install did not complete: ${result.reason}`);
    });
});
test("with no opt-out set, the default URLs are still used", async () => {
    await withTempDir(async (dir) => {
        const seen = [];
        const fetchImpl = (async (u) => {
            seen.push(String(u));
            return new Response("nope", { status: 404 });
        });
        await checkAndApplyUpdate(dir, { fetchImpl, env: {} });
        assert.equal(seen.length, 1);
        assert.match(seen[0], /manifest\.json$/);
    });
});
