import { mkdir, readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { parse, stringify } from "yaml";
import { DEFAULT_8GB_PROFILE } from "./backend/llamaServer.js";
import { detectRunningServer, detectModelAt, COMMON_PORTS } from "./backend/detect.js";
export const DEFAULT_CONFIG = {
    backend: "local-llama",
    model: "local-model",
    // Found via real monitoring data: with the previous 0.85, the worst case
    // (a max_tokens-length reply landing right after the threshold check
    // passes) is 0.85 + 0.25 (max_tokens' own fraction of the window, see
    // loop.ts) = 1.10 — i.e. a single turn could overshoot the REAL context
    // window by up to 10%, which is exactly the failure the context-overflow
    // auto-retry (loop.ts) exists to recover from. Observed directly: usage
    // reached 89% of the window in one real turn. Lowering to 0.70 (0.70 +
    // 0.25 = 0.95) keeps a real margin under 100% even in that worst case,
    // so the overflow-retry safety net is rarely needed rather than routinely
    // relied on. Trades slightly more frequent compaction for that.
    compaction: { autoTriggerRatio: 0.7, autoResume: true },
    llama: {
        binPath: "llama-server",
        modelPath: "",
        port: DEFAULT_8GB_PROFILE.port,
        contextSize: DEFAULT_8GB_PROFILE.contextSize,
        threads: DEFAULT_8GB_PROFILE.threads,
        gpuLayers: DEFAULT_8GB_PROFILE.gpuLayers,
    },
    browser: { debugPort: 9222, host: "127.0.0.1" },
};
export async function loadConfig(projectRoot, 
// Overridable for tests, so they don't depend on what's actually running
// on this machine's common ports (on the dev machine this project was
// built on, 8080 is a real, permanently-running server).
detect = () => detectRunningServer(), 
// Overridable for tests, same reason. Only called for an *existing*
// openai-compatible config — see below.
detectModel = detectModelAt) {
    const path = join(projectRoot, ".llamacli", "config.yaml");
    try {
        const raw = await readFile(path, "utf8");
        const parsed = parse(raw);
        // A plain top-level spread would let an existing config.yaml that
        // predates a new compaction field (e.g. old files only have
        // autoTriggerRatio) silently drop that field's default entirely,
        // since `parsed.compaction` — present but incomplete — replaces
        // DEFAULT_CONFIG.compaction wholesale instead of filling the gap.
        // Caught adding autoResume: every project's pre-existing
        // .llamacli/config.yaml would otherwise load with autoResume
        // `undefined` (falsy) instead of the intended default of `true`.
        const config = {
            ...DEFAULT_CONFIG,
            ...parsed,
            compaction: { ...DEFAULT_CONFIG.compaction, ...parsed.compaction },
        };
        // The `model` field in config.yaml is a cache, not the source of
        // truth — it's whatever was detected (or hand-edited) the last time
        // this file was written, and goes stale the moment the server's
        // loaded model changes (a quant swap, a checkpoint switch). For
        // openai-compatible backends the server itself always knows the
        // current model, so re-ask it on every load and prefer that live
        // value; only fall back to the stored one if the server's
        // unreachable (offline use, server not started yet).
        if (config.backend === "openai-compatible" && config.baseUrl) {
            const liveModel = await detectModel(config.baseUrl);
            if (liveModel)
                config.model = liveModel;
        }
        return { config };
    }
    catch {
        // No config yet in this project. Rather than silently falling back to
        // a default backend URL that's usually dead (this exact gap caused an
        // ECONNREFUSED crash on a machine that actually had a real server
        // running on a different port), probe for one and generate a real
        // config from it — same "reuse what's there, else generate our own
        // default" pattern already used for rules/skills (PROMPT.md §5).
        const detected = await detect();
        const config = detected
            ? { ...DEFAULT_CONFIG, backend: "openai-compatible", baseUrl: detected.baseUrl, model: detected.model }
            : DEFAULT_CONFIG;
        await mkdir(join(projectRoot, ".llamacli"), { recursive: true });
        await writeFile(path, stringify(config), "utf8");
        const setupMessage = detected
            ? `[setup] No .llamacli/config.yaml found — detected a running server at ${detected.baseUrl} and created one pointing at it.`
            : `[setup] No .llamacli/config.yaml found and no local server detected on common ports (${COMMON_PORTS.join(", ")}). ` +
                `Created a placeholder — edit .llamacli/config.yaml to point at your backend.`;
        return { config, setupMessage };
    }
}
