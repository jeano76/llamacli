import { mkdir, readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { parse, stringify } from "yaml";
import { DEFAULT_8GB_PROFILE } from "./backend/llamaServer.js";
import { detectRunningServer, detectModelAt, COMMON_PORTS } from "./backend/detect.js";
export const DEFAULT_CONFIG = {
    backend: "local-llama",
    model: "local-model",
    // Found via real monitoring data: with the previous 0.85, the worst case
    // (a max_tokens-length reply landing right after the threshold check
    // passes) is 0.85 + 0.25 (max_tokens' own fraction of the window, see
    // loop.ts) = 1.10 — i.e. a single turn could overshoot the REAL context
    // window by up to 10%, which is exactly the failure the context-overflow
    // auto-retry (loop.ts) exists to recover from. Observed directly: usage
    // reached 89% of the window in one real turn. Lowering to 0.70 (0.70 +
    // 0.25 = 0.95) keeps a real margin under 100% even in that worst case,
    // so the overflow-retry safety net is rarely needed rather than routinely
    // relied on. Trades slightly more frequent compaction for that.
    compaction: { autoTriggerRatio: 0.7, autoResume: true },
    llama: {
        binPath: "llama-server",
        modelPath: "",
        port: DEFAULT_8GB_PROFILE.port,
        contextSize: DEFAULT_8GB_PROFILE.contextSize,
        threads: DEFAULT_8GB_PROFILE.threads,
        gpuLayers: DEFAULT_8GB_PROFILE.gpuLayers,
    },
    browser: { debugPort: 9222, host: "127.0.0.1" },
};
/** Path to this project's config.yaml, so callers can read/write it directly
 *  without re-deriving the join(). Used by `/fastcheck on|off`, which now
 *  persists its choice here (rather than relying on a Python script) — so the
 *  toggle survives a restart the way a human editing the file would expect. */
export function configPath(projectRoot) {
    return join(projectRoot, ".llamacli", "config.yaml");
}
/** Read and persist `laya.enabled` in config.yaml without disturbing any other
 *  field (parse → mutate only the laya block → stringify). Returns true on a
 *  successful write. A missing/partial file is tolerated: we parse what's there,
 *  merge over DEFAULT_CONFIG so we never wipe known keys, then write back — so
 *  toggling laya never clobbers backend/model/llama/etc. (see loadConfig for the
 *  same "fill the gap, don't replace wholesale" reasoning). */
export async function updateLayaEnabled(projectRoot, enabled) {
    try {
        const raw = await readFile(configPath(projectRoot), "utf8");
        const parsed = parse(raw);
        const config = {
            ...DEFAULT_CONFIG,
            ...parsed,
            compaction: { ...DEFAULT_CONFIG.compaction, ...parsed.compaction },
        };
        // Preserve any existing laya block's other knobs; only flip `enabled`.
        config.laya = { ...(config.laya ?? {}), enabled };
        await writeFile(configPath(projectRoot), stringify(config), "utf8");
        return true;
    }
    catch {
        return false;
    }
}
export async function loadConfig(projectRoot, 
// Overridable for tests, so they don't depend on what's actually running
// on this machine's common ports (on the dev machine this project was
// built on, 8080 is a real, permanently-running server).
detect = () => detectRunningServer(), 
// Overridable for tests, same reason. Only called for an *existing*
// openai-compatible config — see below.
detectModel = detectModelAt) {
    const path = join(projectRoot, ".llamacli", "config.yaml");
    try {
        const raw = await readFile(path, "utf8");
        const parsed = parse(raw);
        // A plain top-level spread would let an existing config.yaml that
        // predates a new compaction field (e.g. old files only have
        // autoTriggerRatio) silently drop that field's default entirely,
        // since `parsed.compaction` — present but incomplete — replaces
        // DEFAULT_CONFIG.compaction wholesale instead of filling the gap.
        // Caught adding autoResume: every project's pre-existing
        // .llamacli/config.yaml would otherwise load with autoResume
        // `undefined` (falsy) instead of the intended default of `true`.
        const config = {
            ...DEFAULT_CONFIG,
            ...parsed,
            compaction: { ...DEFAULT_CONFIG.compaction, ...parsed.compaction },
        };
        // The `model` field in config.yaml is a cache, not the source of
        // truth — it's whatever was detected (or hand-edited) the last time
        // this file was written, and goes stale the moment the server's
        // loaded model changes (a quant swap, a checkpoint switch). For
        // openai-compatible backends the server itself always knows the
        // current model, so re-ask it on every load and prefer that live
        // value; only fall back to the stored one if the server's
        // unreachable (offline use, server not started yet).
        if (config.backend === "openai-compatible" && config.baseUrl) {
            const liveModel = await detectModel(config.baseUrl);
            if (liveModel)
                config.model = liveModel;
        }
        return { config };
    }
    catch {
        // No config yet in this project. Rather than silently falling back to
        // a default backend URL that's usually dead (this exact gap caused an
        // ECONNREFUSED crash on a machine that actually had a real server
        // running on a different port), probe for one and generate a real
        // config from it — same "reuse what's there, else generate our own
        // default" pattern already used for rules/skills (PROMPT.md §5).
        const detected = await detect();
        const config = detected
            ? { ...DEFAULT_CONFIG, backend: "openai-compatible", baseUrl: detected.baseUrl, model: detected.model }
            : DEFAULT_CONFIG;
        // Persisting the generated config is best-effort, exactly as the read
        // above is. It used to be an unguarded `mkdir` + `writeFile` inside the
        // catch block, so a project directory that cannot be written to — a
        // read-only mount, a checkout owned by another user, a container running
        // as a non-owner — made EVERY launch reject with EACCES. That is a much
        // worse failure than the one it was handling: the file being missing is
        // handled fine, and the generated config is only a convenience.
        //
        // Found by a project-axis sweep (100 project states). The session must
        // still start; the user is told the setting was not saved rather than
        // being shown a stack trace.
        let saved = true;
        try {
            await mkdir(join(projectRoot, ".llamacli"), { recursive: true });
            await writeFile(path, stringify(config), "utf8");
        }
        catch {
            saved = false;
        }
        const setupMessage = !saved
            ? `[setup] No .llamacli/config.yaml found, and this project directory is not writable, so the generated config could not be saved. ` +
                `llamacli is using in-memory defaults for this session only — they will be re-derived on every launch. ` +
                `Run llamacli in a directory you own, or make this one writable, to persist them.`
            : detected
                ? `[setup] No .llamacli/config.yaml found — detected a running server at ${detected.baseUrl} and created one pointing at it.`
                : `[setup] No .llamacli/config.yaml found and no local server detected on common ports (${COMMON_PORTS.join(", ")}). ` +
                    `Created a placeholder — edit .llamacli/config.yaml to point at your backend.`;
        return { config, setupMessage };
    }
}
