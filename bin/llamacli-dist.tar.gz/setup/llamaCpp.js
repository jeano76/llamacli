/**
 * Finding an existing llama.cpp, and building one when there isn't one.
 *
 * Requested directly: "llamacli 의 초기 구동 시 llama.cpp 가 존재를 하지
 * 않는다면 관련 설치 패키지와 llama.cpp 를 설치하고" — on first launch, if
 * llama.cpp is missing, install the build packages and llama.cpp itself.
 *
 * ── Reuse before build, always ──────────────────────────────────────────────
 * Building llama.cpp with CUDA takes 10-40 minutes. Doing that when a working
 * build is already sitting on the machine is the single worst thing this module
 * could do, so the search order is deliberately "cheapest and most likely
 * first", and a build is only attempted after every candidate has failed:
 *
 *   1. `$LLAMA_SERVER_BIN` — the user already told us.
 *   2. `llama-server` on PATH.
 *   3. A conventional `~/llama.cpp/buildX/bin/llama-server`.
 *   4. A llamacli-owned `~/.llamacli/llama.cpp/buildX/bin/llama-server`.
 *   5. Only then: clone + build.
 *
 * (Written as `buildX` rather than a glob on purpose: a literal glob star-slash
 * inside this block comment closes the comment early, which is a wonderfully
 * quiet way to produce a wall of nonsense parse errors.)
 *
 * A CUDA build is preferred over a CPU one when several are found, because
 * running a 35B MoE on CPU when a GPU build exists is the difference between
 * usable and not. The build directory name is the only signal available, so it
 * is a heuristic and the chosen binary's own reported backend is what actually
 * decides (see `probeLlamaServer`).
 */
import { access, constants } from "node:fs/promises";
import { homedir } from "node:os";
import { delimiter, dirname, join } from "node:path";
import { execFile, spawn as spawnProc } from "node:child_process";
import { promisify } from "node:util";
const execFileAsync = promisify(execFile);
export const LLAMA_CPP_REPO = "https://github.com/ggml-org/llama.cpp";
/** Where llamacli keeps its OWN build, so it never touches a user's checkout. */
export const LLAMA_CPP_HOME = join(homedir(), ".llamacli", "llama.cpp");
export const defaultRun = async (file, args, opts = {}) => (await execFileAsync(file, args, { cwd: opts.cwd, timeout: opts.timeout ?? 20 * 60_000, maxBuffer: 32 * 1024 * 1024 })).stdout;
async function isExecutable(path) {
    try {
        await access(path, constants.X_OK);
        return true;
    }
    catch {
        return false;
    }
}
/** The binary name for this platform. llama.cpp ships `llama-server.exe` on
 *  Windows and nothing anywhere else. */
/**
 * The binary's filename on this platform.
 *
 * A FUNCTION, not a module-level const. As a const it was frozen from
 * `process.platform` at import time, which meant the Windows `.exe` name could
 * not be exercised by any test on a Linux box -- the platform-specific naming
 * was real code that nothing could reach. Same mistake as reading `HOME` once
 * at module load: a value decided before anything could ask the question.
 */
export function binNameFor(platform = process.platform) {
    return platform === "win32" ? "llama-server.exe" : "llama-server";
}
/** The name for the host platform.
 *
 *  Only the PATH lookup consults `binNameFor(opts.platform)`; the build
 *  directory layouts below use this, because llama.cpp's own layout
 *  (`build/bin`, `build/Release/bin`) is the same on every platform it ships
 *  for, and threading a platform parameter through every one of those helpers
 *  would be a large refactor to make an unchanged behaviour injectable. */
const BIN_NAME = binNameFor();
/**
 * Build-directory names, best-first. This is a PREFERENCE ORDER, not an
 * allowlist: `scanBuildDirs` below also tries every other directory it finds,
 * so a build in a name nobody anticipated is still found. It only decides
 * which of several real candidates wins.
 *
 * `build-opt` is the naming convention in wide use for an optimised CUDA
 * build, `build-cuda` is explicit, and a plain `build` is the cmake default.
 * `build-cpu` is what THIS module's own builder produces, so it has to be in
 * here: without it, a CPU-only machine that let llamacli build its own server
 * would fail to find that server on the next launch and rebuild it — 10 to 40
 * minutes — on every single start.
 *
 * `bin` and `Release` are NOT build directories; they are the second path
 * component of the two real layouts (`<root>/bin/llama-server` from a plain
 * `make`, and `build/bin/Release/…` on MSVC). They are enumerated by
 * `candidatePaths` instead, and listing them here produced paths like
 * `~/llama.cpp/bin/bin/llama-server` that exist nowhere.
 */
const BUILD_DIR_PREFERENCE = ["build-opt", "build-cuda", "build-cpu", "build", "build-release"];
/** Score for a build directory name; lower is better, and `undefined` means
 *  "not a recognised build dir at all" (still searched, just last). */
function buildDirRank(name) {
    const i = BUILD_DIR_PREFERENCE.indexOf(name);
    if (i >= 0)
        return i;
    // A `build*` directory with an unrecognised suffix is still a build dir —
    // people name them after the CUDA version, the arch, the date. Ranking it
    // after the known names but before non-build directories is what makes a
    // `build-cuda-12.4` or `build-vulkan-rocm` discoverable.
    if (/^build/i.test(name))
        return BUILD_DIR_PREFERENCE.length;
    return undefined;
}
function backendFromPath(p) {
    const s = p.toLowerCase();
    if (s.includes("cuda") || s.includes("opt") || s.includes("gpu"))
        return "cuda";
    if (s.includes("vulkan"))
        return "vulkan";
    if (s.includes("release") || s.includes("cpu"))
        return "cpu";
    return "unknown";
}
/** Every place a `llama-server` binary lives inside one llama.cpp checkout.
 *
 *  Exported and pure so the layout coverage is testable without a checkout.
 *  Three real layouts, none of which is a special case of the others:
 *
 *    1. `<root>/<buildDir>/bin/llama-server`   — cmake, the usual case
 *    2. `<root>/bin/llama-server`              — plain `make`, which puts the
 *                                                binaries at the repo root and
 *                                                is what a first-time llama.cpp
 *                                                user following the README
 *                                                ends up with
 *    3. `<root>/<buildDir>/bin/Release/…`      — MSVC multi-config generators
 *                                                (Visual Studio), where the
 *                                                configuration is a third path
 *                                                component
 *
 *  Layout 2 in particular was unreachable before: nothing looked at the repo
 *  root, so a `make`-built llama.cpp was invisible to llamacli no matter where
 *  it lived. */
export function candidatePaths(root, buildDirs) {
    // Sorted HERE rather than relying on the caller: the ranking is what decides
    // which of several real builds wins, and a caller that supplies an unsorted
    // list must not be able to make a CPU build beat a CUDA one.
    const ranked = [...buildDirs].sort((a, b) => {
        const ra = buildDirRank(a);
        const rb = buildDirRank(b);
        if (ra !== undefined && rb !== undefined)
            return ra - rb;
        if (ra !== undefined)
            return -1;
        if (rb !== undefined)
            return 1;
        return a.localeCompare(b);
    });
    const out = [];
    for (const dir of ranked) {
        out.push(join(root, dir, "bin", BIN_NAME));
        out.push(join(root, dir, "bin", "Release", BIN_NAME));
    }
    out.push(join(root, "bin", BIN_NAME));
    out.push(join(root, BIN_NAME));
    return out;
}
/**
 * llama-server builds installed NEXT TO the models they serve.
 *
 * This is a second real install shape, and the one that was invisible here.
 * llama.cpp publishes prebuilt release archives (`llama-bNNNN-bin-ubuntu-x64`)
 * that are unpacked, not compiled — which puts a complete runtime with its own
 * `llama-server` and its `.so` files wherever the user keeps their models. That
 * is not a llama.cpp *checkout*, so it appears in neither PATH nor any of the
 * `~/llama.cpp` roots searched above, and the binary that runs the model is
 * simply not among the candidates.
 *
 * Observed directly: the model lives at
 * `<drive>/models/bonsai2/Ternary-Bonsai-2-27B-PTQ1_0.gguf` and the only
 * build that can read it is `<drive>/bonsai2-runtime/llama-server`, which no
 * existing rule reached. The result was a dead end — the one working binary was
 * on the same disk, two directories away.
 *
 * Scanned from the model's own directory upward, because that is the one
 * location already known to be relevant. Depth is bounded: an unbounded walk
 * out of `/media/<user>/<volume>` would eventually reach the whole filesystem.
 *
 * What this does NOT decide is whether a candidate is any good — widening where
 * we look is safe precisely because `probeModelCompatibility` still arbitrates.
 * An unrelated sibling that happens to contain a `llama-server` is probed and
 * rejected, and appears in the rejection list, rather than being launched.
 */
export const MODEL_RUNTIME_SCAN_DEPTH = 3;
/** Directories that hold a llama-server beside the given model.
 *
 *  Returns absolute paths in scan order, nearest first. Empty when there is no
 *  model path — with no model there is nothing for a runtime to be adjacent to,
 *  and guessing at directories is what this function exists to avoid. */
export async function runtimeCandidatesNearModel(modelPath, opts = {}) {
    if (!modelPath)
        return [];
    const exists = opts.exists ?? isExecutable;
    const listDirs = opts.listDirs ?? listBuildDirs;
    const found = new Set();
    let dir = dirname(modelPath);
    for (let depth = 0; depth <= MODEL_RUNTIME_SCAN_DEPTH; depth++) {
        const parent = dirname(dir);
        // Stop at the filesystem root rather than spinning on `dirname("/") === "/"`.
        if (parent === dir)
            break;
        for (const entry of await listDirs(dir)) {
            const candidate = join(dir, entry, BIN_NAME);
            // A file, not a directory: `llama-server` itself must not be treated as
            // its own parent directory.
            if (entry === BIN_NAME)
                continue;
            if (await exists(candidate))
                found.add(candidate);
        }
        dir = parent;
    }
    return [...found];
}
/** Directory names inside a llama.cpp checkout, best candidate first.
 *
 *  Injected in tests; `readdir` for real. A missing or unreadable directory
 *  yields an empty list, which is the same as "no build here" — the caller
 *  then moves to the next root. */
async function listBuildDirs(root) {
    try {
        const { readdir } = await import("node:fs/promises");
        const entries = await readdir(root, { withFileTypes: true });
        // Unsorted: `candidatePaths` does the ranking, so the preference lives in
        // exactly one place.
        return entries.filter((e) => e.isDirectory() || e.isSymbolicLink()).map((e) => e.name);
    }
    catch {
        return [];
    }
}
/**
 * Locates a usable `llama-server` without building anything.
 *
 * Returns null when nothing usable is found, which is the caller's signal to
 * build. Exported with injectable `exists`/`env`/`listDirs` so the search order
 * itself is testable — the order is the entire point of this function, and it
 * is exactly the kind of thing that silently rots when it can only be exercised
 * by having a real build on the machine.
 *
 * Every candidate is EXECUTED before it is accepted (`probeLlamaServer`).
 * Existence is not usability: a binary built against a CUDA version this
 * driver does not have, or one whose `libggml-cuda.so` was never installed, is
 * present and executable and still fails to start — and accepting it means the
 * failure surfaces much later as an opaque spawn error instead of here, where
 * the next candidate could have been tried.
 */
export async function findLlamaServer(opts = {}) {
    const env = opts.env ?? process.env;
    const exists = opts.exists ?? isExecutable;
    const listDirs = opts.listDirs ?? listBuildDirs;
    const home = opts.home ?? homedir();
    const run = opts.run ?? defaultRun;
    const probe = opts.probe ?? (async (p) => (await probeLlamaServer(p, run)).ok);
    // Collected rather than returned on sight, so a candidate that exists but
    // cannot run is skipped in favour of the next one.
    const rejected = [];
    // Candidates that run but cannot read the configured model. Recorded
    // separately because the reason is actionable — "you have two llama.cpp
    // builds and the one picked cannot read this quant" is a completely
    // different instruction from "that binary is broken".
    const rejectedForModel = [];
    // Kept, but never confirmed to be able to read the model. Kept because
    // discarding a working install over a bad download would be worse.
    const unverified = [];
    // Memoised per path, because `candidatePaths` yields the same binary under
    // each of the three real build layouts and the loop below tries all three.
    // Without this, one binary is probed with `--version` up to three times and —
    // far worse — `probeModelCompatibility` is a PROCESS SPAWN that parses a GGUF
    // header, so a stock build rejected for a ternary model was launched and
    // re-read three times over, and reported to the user three times.
    const decided = new Map();
    const accept = (binPath, source) => {
        const cached = decided.get(binPath);
        if (cached)
            return cached;
        const verdict = decide(binPath, source);
        decided.set(binPath, verdict);
        return verdict;
    };
    const decide = async (binPath, source) => {
        if (!(await probe(binPath))) {
            rejected.push(binPath);
            return null;
        }
        // Running is not the same as being able to read the model. Without this the
        // search happily returned a stock build for a ternary-quantised model and
        // the failure surfaced much later, as a server that exited with
        // "invalid ggml type 143" and a message blaming the port.
        if (opts.checkModel !== false && opts.modelPath) {
            const compat = await (opts.probeModel ?? probeModelCompatibility)(binPath, opts.modelPath, {
                run,
                spawn: opts.spawnProbe,
            });
            if (!compat.ok && looksLikeUnsupportedModelFormat(compat.error)) {
                rejectedForModel.push(binPath);
                return null;
            }
            // "Other" load failures (a genuinely corrupt file, a missing dependency)
            // say nothing about this binary, so it is kept rather than skipped —
            // discarding a working install over a bad download would be worse.
            //
            // "Inconclusive" is different in kind: nothing was learned at all, so the
            // binary is still kept — it is the best candidate available — but it is
            // ALSO recorded, because "kept" here means "not disproven", not "verified".
            // Presenting that as a positive result is how a stock build ends up
            // reported as able to read a ternary quant.
            if (compat.verdict === "inconclusive")
                unverified.push(binPath);
        }
        return { binPath, source, backend: backendFromPath(binPath) };
    };
    // 1. Explicit overrides. Cheapest and unambiguous, so they win outright.
    //    Both names are accepted: the header comment of this file documented
    //    LLAMA_SERVER_BIN while the code only ever read LLAMACLI_LLAMA_SERVER, so
    //    a user who followed the documentation set a variable nothing looked at
    //    and were told llama.cpp could not be found.
    for (const key of ["LLAMACLI_LLAMA_SERVER", "LLAMA_SERVER_BIN"]) {
        const value = env[key];
        if (value && (await exists(value))) {
            const hit = await accept(value, "env");
            if (hit)
                return { location: hit, rejected, rejectedForModel, unverified };
        }
    }
    // 2. PATH. Split on the platform's own separator — a hardcoded ":" made every
    //    entry on Windows a single nonsensical path, so PATH search could never
    //    succeed there. Checked by name rather than by running `command -v`, so
    //    the same injectable `exists` seam covers every candidate.
    const pathEntries = (env.PATH ?? "").split(delimiter).filter(Boolean);
    for (const dir of pathEntries) {
        const candidate = join(dir, binNameFor(opts.platform));
        if (await exists(candidate)) {
            const hit = await accept(candidate, "path");
            if (hit)
                return { location: hit, rejected, rejectedForModel, unverified };
        }
    }
    // 3. llama.cpp checkouts. Every directory inside the checkout is a candidate
    //    (see `listBuildDirs`), ranked so a recognised name wins, and each is
    //    tried in all three real layouts. Previously only two hardcoded roots
    //    were searched with a hardcoded list of directory names, so a
    //    `make`-built checkout, a build named after its CUDA version, and a
    //    second checkout anywhere else in the home directory were all invisible —
    //    and on a machine where none matched, the answer was "build it", which
    //    is 10 to 40 minutes of CUDA compilation to arrive at a binary the user
    //    already had.
    const roots = [
        { dir: join(home, "llama.cpp"), source: "existing-build" },
        // Derived from the injected `home`, not from the module-level constant:
        // a search that honours an injected home for one root and the real one for
        // the other cannot be tested, and on a machine where HOME differs from
        // what `homedir()` reports it would look in two different places.
        { dir: join(home, ".llamacli", "llama.cpp"), source: "llamacli-build" },
    ];
    for (const root of roots) {
        const buildDirs = await listDirs(root.dir);
        for (const candidate of candidatePaths(root.dir, buildDirs)) {
            if (await exists(candidate)) {
                const hit = await accept(candidate, root.source);
                if (hit)
                    return { location: hit, rejected, rejectedForModel, unverified };
            }
        }
    }
    // 4. Runtimes installed beside the models. Ranked below every declared
    //    location on purpose: a build the user put in PATH or named in a unit
    //    file is a decision, whereas this is a guess about where an unpacked
    //    release archive ended up. It is tried because being unable to reach the
    //    one working binary is a dead end, not because it should ever win.
    if (opts.modelPath) {
        for (const binPath of await runtimeCandidatesNearModel(opts.modelPath, { exists, listDirs })) {
            const hit = await accept(binPath, "model-adjacent");
            if (hit)
                return { location: hit, rejected, rejectedForModel, unverified };
        }
    }
    // 5. A systemd user unit. On a machine where llama-server is managed as a
    //    service — a common way to run it on a workstation — the binary path is
    //    declared in the unit file or the script it ExecStart's, and is
    //    otherwise nowhere discoverable. This is what made a service-managed
    //    install look like "llama.cpp is not installed" to llamacli.
    for (const binPath of await systemdLlamaServerPaths(env, { exists, run: opts.run ?? defaultRun })) {
        const hit = await accept(binPath, "systemd");
        if (hit)
            return { location: hit, rejected, rejectedForModel, unverified };
    }
    return { location: null, rejected, rejectedForModel, unverified };
}
/** Parses a llama-server binary path out of a systemd user unit.
 *
 *  Two shapes are handled, because that is what exists in the wild:
 *    - `ExecStart=/home/u/bin/run-server.sh`  → the path is inside the SCRIPT
 *    - `ExecStart=/home/u/llama.cpp/build/bin/llama-server -m …`  → it is the
 *      ExecStart itself
 *
 *  Reading the script matters as much as reading the unit: the unit almost
 *  never names the binary, it names a wrapper that does.
 */
export async function systemdLlamaServerPaths(env, deps) {
    const unitDir = join(env.HOME ?? homedir(), ".config", "systemd", "user");
    const out = [];
    let text;
    try {
        const { readFile, readdir } = await import("node:fs/promises");
        const units = (await readdir(unitDir)).filter((f) => /^llama.*\.service$/.test(f));
        for (const unit of units) {
            text = await readFile(join(unitDir, unit), "utf8");
            for (const line of text.split("\n")) {
                const m = /^\s*ExecStart\s*=\s*(\S+)/.exec(line);
                if (!m)
                    continue;
                // systemd specifiers are the norm in a user unit: `%h` is the home
                // directory, and it is what this very repo's unit uses
                // (`ExecStart=%h/bin/run-server.sh`). Passed through unexpanded, the
                // path does not exist and the unit looks like it names no binary at
                // all.
                const target = m[1]
                    .replace(/^"|"$/g, "")
                    .replace(/%h/g, env.HOME ?? homedir())
                    .replace(/%t/g, "/tmp");
                // A wrapper script: look for the binary it launches.
                if (/\.(sh|bash)$/.test(target) || !target.includes(BIN_NAME)) {
                    let body;
                    try {
                        body = await readFile(target, "utf8");
                    }
                    catch {
                        continue; // the wrapper is named but absent — try the next unit
                    }
                    for (const assign of body.matchAll(/^\s*([A-Z_]*BIN[A-Z_]*)=["']?([^"'\s]+)["']?/gm)) {
                        const binPath = assign[2];
                        if (binPath.includes(BIN_NAME) && (await deps.exists(binPath)))
                            out.push(binPath);
                    }
                    continue;
                }
                if (await deps.exists(target))
                    out.push(target);
            }
        }
    }
    catch {
        return out; // no systemd user dir, or unreadable — not an error
    }
    return out;
}
/** Asks a candidate binary what it actually is.
 *
 *  This used to exist and be called by nobody: the search accepted any file
 *  that was executable, so a binary built against a CUDA version this driver
 *  does not have — or one whose `libggml-cuda.so` was never installed — was
 *  recorded in config.yaml and only failed much later, at spawn, with an
 *  opaque error naming nothing useful. `findLlamaServer` now calls it on every
 *  candidate, which is also what makes "exists but will not run" a state the
 *  search can report instead of pass through.
 *
 *  `backendFromPath`'s guess is confirmed here too, when the binary says so.
 */
export async function probeLlamaServer(binPath, run = defaultRun) {
    try {
        const out = await run(binPath, ["--version"], { timeout: 20_000 });
        const m = /version:\s*(\S+)/i.exec(out) ?? /(\d{3,4})/.exec(out);
        return { ok: true, version: m?.[1] };
    }
    catch (err) {
        return { ok: false, error: err instanceof Error ? err.message : String(err) };
    }
}
const realProbeSpawn = (binPath, args, { onOutput, onError, onExit }) => {
    // A top-level import, not a lazy `require`: this module is ESM, where
    // `require` is undefined. A lazy require threw, every probe returned "other",
    // and since "other" is not a format complaint the candidate was KEPT -- which
    // silently reported the stock build as able to read a ternary quant. A probe
    // that cannot start must never look like a probe that passed.
    const proc = spawnProc(binPath, args);
    proc.stdout?.on("data", (d) => onOutput(d.toString()));
    proc.stderr?.on("data", (d) => onOutput(d.toString()));
    // Without this, a binary that cannot be executed emits an `error` event that
    // nothing handles, and Node turns it into an uncaught exception that takes the
    // caller down. A probe that cannot START must resolve to a verdict, not crash
    // the process that asked the question.
    proc.on("error", (err) => onError(err));
    proc.on("exit", (code) => onExit(code));
    return { kill: () => { try {
            proc.kill("SIGKILL");
        }
        catch { /* already gone */ } } };
};
/** Output that can only appear once the model is loaded and the context is
 *  being created -- i.e. the header parsed AND the tensors were accepted.
 *
 *  Deliberately a "post-load" marker rather than a "parsed" one: the type
 *  registry is consulted while tensor infos are read, so anything that survives
 *  to this point has already proved it understands every type in the file. */
const MODEL_LOADED = /load_tensors:\s*done|load_model:\s*initializing|model\s+loaded/i;
/** A load that failed for a reason that is NOT about tensor types -- a corrupt
 *  file, a truncated download, a missing dependency.
 *
 *  Recognised separately so it is not confused with "we learned nothing". These
 *  say something definite about the FILE while saying nothing about the binary,
 *  which is exactly the case that must not be reported as a build mismatch and
 *  must not be left to time out. Ordering matters: the type check runs first, so
 *  an "invalid ggml type" line is never swallowed by this. */
const LOAD_FAILED = /llama_model_loader:[^\n]*failed|failed to load model|error loading model|unexpected end of file|file is corrupted/i;
/**
 * Can this build READ this model?
 *
 * ── Why this streams and kills instead of awaiting exit ─────────────────────
 * The previous version ran the binary with `--no-warmup` and awaited it, on the
 * belief that the flag "stops after loading". Measured on this machine, that is
 * false: `--no-warmup` suppresses the warmup REQUEST, and the process then goes
 * on to serve forever. A build that CAN read the model therefore never exits and
 * always burned the full 60 s timeout -- measured 180 s when the timeout was
 * raised, with the model itself fully loaded by ~3 s. A build that CANNOT read
 * it failed in 178 ms. So the expensive case was the successful one, on every
 * `/models` and every `/reset`.
 *
 * The verdict is therefore taken from the OUTPUT and the process killed the
 * moment it is known: ~3 s instead of 60 s, and the positive answer is now
 * actually established rather than merely never-disproven.
 *
 * ── Why "inconclusive" is its own answer ───────────────────────────────────
 * A timeout used to be caught, turned into a generic error, and then — because
 * a timeout is not a format complaint — the candidate was KEPT. So "this build
 * can read your model" was never verified for a working build; it was inferred
 * from a failure that carried no information. That is the same class of bug as
 * treating silence as consent, and it is reported as `inconclusive` instead so
 * the caller can say so out loud rather than presenting an assumption as a
 * measurement.
 */
export async function probeModelCompatibility(binPath, modelPath, deps = {}) {
    if (!modelPath)
        return { ok: true, verdict: "ok" };
    const spawnProbe = deps.spawn ?? realProbeSpawn;
    const timeoutMs = deps.timeoutMs ?? 60_000;
    const args = [
        "-m", modelPath,
        "-c", "64",
        // Off the GPU, so the probe is cheap and cannot disturb a server that is
        // already holding VRAM we are about to need.
        "-ngl", "0",
        "--no-warmup",
    ];
    return new Promise((resolve) => {
        let text = "";
        let settled = false;
        let proc;
        let timer;
        const finish = (verdict) => {
            if (settled)
                return;
            settled = true;
            if (timer)
                clearTimeout(timer);
            // Kill unconditionally: in every non-timeout path the process is still
            // running and serving, and leaving it alive would put a second
            // llama-server on the machine holding the model's VRAM.
            //
            // The handle may not exist yet if a verdict arrived before the spawn
            // returned. That ordering is easy to lose track of — the kill is the one
            // side effect that must not be skipped, so the verdict is remembered and
            // applied below as soon as there is something to kill. A probe that
            // decides "ok" and then leaves a server running is worse than a slow one.
            try {
                proc?.kill();
            }
            catch { /* not started yet, or already gone */ }
            resolve({ ok: verdict === "ok", verdict, error: verdict === "ok" ? undefined : tailOf(text) });
        };
        try {
            proc = spawnProbe(binPath, args, {
                onExit: (code) => {
                    // A process that ENDS is a definite answer, and this case was
                    // missing: the probe resolved only on a marker or the timeout, so
                    // any binary that exited early -- a wrapper script, a build that
                    // fails before it says anything -- waited the full 60 s for a
                    // verdict that had already happened. The harness's stub server
                    // exits instantly and still cost a minute per probe.
                    //
                    // Exit 0 with no complaint means it did what was asked. Non-zero
                    // means the load did not complete -- "other", which says the file is
                    // at fault rather than the build, and is not "inconclusive".
                    finish(code === 0 ? "ok" : "other");
                },
                onOutput: (chunk) => {
                    if (settled)
                        return;
                    text += chunk;
                    if (looksLikeUnsupportedModelFormat(text))
                        return finish("unsupported");
                    if (MODEL_LOADED.test(text))
                        return finish("ok");
                    if (LOAD_FAILED.test(text))
                        return finish("other");
                },
                // The process could not be started, so nothing was learned about the
                // model -- "other", not "ok". Treating a failed launch as success is
                // how an unreadable model gets reported as loadable.
                onError: () => finish("other"),
            });
        }
        catch (err) {
            return finish("other");
        }
        // A verdict that landed while the handle did not yet exist still has to kill.
        if (settled) {
            try {
                proc.kill();
            }
            catch { /* already gone */ }
        }
        timer = setTimeout(() => finish("inconclusive"), timeoutMs);
    });
}
/** The last few lines of a probe's output -- the diagnosis, when there is one. */
function tailOf(text, lines = 6) {
    return text
        .split("\n")
        .map((l) => l.trim())
        .filter(Boolean)
        .slice(-lines)
        .join("\n");
}
/** True when a load failure looks like "this build cannot read this format".
 *
 *  Deliberately narrow: these specific messages mean the binary's type registry
 *  does not know the file's quantization, which is a build mismatch and not
 *  anything wrong with the model. A generic "failed to load" is not enough to
 *  claim that, so it is excluded. */
export function looksLikeUnsupportedModelFormat(message) {
    if (!message)
        return false;
    return /invalid ggml type|unknown ggml type|unsupported (?:tensor )?type/i.test(message);
}
// ─────────────────────────────────────────────────────────────────────────────
// Building
// ─────────────────────────────────────────────────────────────────────────────
/** Debian/Ubuntu packages llama.cpp needs to compile at all, and CUDA adds two
 *  more. Kept as data so the install step is testable and so the apt line in the
 *  status output can be shown to the user BEFORE it runs. */
export const BASE_BUILD_PACKAGES = [
    "build-essential", "cmake", "git", "curl", "libcurl4-openssl-dev", "pkg-config",
];
export const CUDA_BUILD_PACKAGES = ["cuda-toolkit-12-4"];
/**
 * Installs the build dependencies.
 *
 * Uses `sudo -n` first — non-interactive, so it FAILS FAST instead of hanging
 * on a password prompt the user cannot see. Only if that fails do we retry
 * interactively, and only because a locked-out install is a worse outcome than
 * an interrupted one. The user was asked about this trade-off and chose to
 * allow the prompt; the fast path is still tried first so the common case
 * (passwordless sudo, e.g. a dev box) never prompts at all.
 */
export async function installBuildPackages(opts) {
    const packages = opts.cuda ? [...BASE_BUILD_PACKAGES, ...CUDA_BUILD_PACKAGES] : BASE_BUILD_PACKAGES;
    const attempts = [["sudo", ["-n", "apt-get", "install", "-y", ...packages]]];
    if (opts.interactive !== false) {
        attempts.push(["sudo", ["apt-get", "install", "-y", ...packages]]);
    }
    let last = "";
    for (const [file, args] of attempts) {
        try {
            const output = await opts.run(file, args, { timeout: 10 * 60_000 });
            return { ok: true, output };
        }
        catch (err) {
            last = err instanceof Error ? err.message : String(err);
        }
    }
    return { ok: false, output: last };
}
/** Clones (or updates) and builds llama.cpp, returning the built binary path.
 *
 * The CUDA decision comes from `hw.canBuildCuda` — a machine can have a GPU
 * with no `nvcc`, and asking cmake for `-DGGML_CUDA=ON` in that state produces
 * a configure error rather than a CPU fallback. Threads are capped at the core
 * count because a `-j` larger than the machine only thrashes.
 */
export async function buildLlamaCpp(opts) {
    const { hw, run, log = () => { } } = opts;
    const repo = opts.repo ?? LLAMA_CPP_REPO;
    // One checkout per repository. A fork and stock share nothing, and overwriting
    // one with the other would make `findLlamaServer` return whichever sorted first
    // for a model only one of them can read.
    const dir = opts.home ?? (repo === LLAMA_CPP_REPO ? LLAMA_CPP_HOME : join(LLAMA_CPP_HOME + "-fork"));
    if (opts.installDeps !== false) {
        log(`빌드 패키지를 설치합니다 (CUDA: ${hw.canBuildCuda ? "예" : "아니오"})…`);
        const deps = await installBuildPackages({ cuda: hw.canBuildCuda, run });
        if (!deps.ok) {
            // Not fatal on its own: the machine may already have everything (which is
            // the common case on a dev box, and is why we try the build regardless).
            log(`패키지 자동 설치에 실패했지만 이미 설치되어 있을 수 있어 계속합니다: ${deps.output.split("\n").slice(-1)[0]}`);
        }
    }
    if (!(await dirExists(join(dir, ".git")))) {
        log(`llama.cpp 소스를 받습니다 → ${dir}`);
        await run("git", ["clone", "--depth", "1", repo, dir], { timeout: 20 * 60_000 });
    }
    else {
        // An existing checkout is only usable if it is the repository asked for. A
        // stock tree left over from an earlier run would silently be rebuilt here and
        // then handed a model it cannot read, so the mismatch is stated instead.
        const origin = await run("git", ["config", "--get", "remote.origin.url"], { cwd: dir, timeout: 10_000 })
            .then((s) => s.trim())
            .catch(() => "");
        const sameRepo = origin.replace(/\.git$/, "") === repo.replace(/\.git$/, "");
        if (!sameRepo) {
            throw new Error(`${dir} 에는 다른 저장소(${origin || "알 수 없음"})가 있습니다. ` +
                `${repo} 빌드에는 다른 위치가 필요합니다.`);
        }
    }
    const buildDir = hw.canBuildCuda ? "build-cuda" : "build-cpu";
    const cmakeFlags = [
        "-B", buildDir,
        "-DCMAKE_BUILD_TYPE=Release",
        "-DLLAMA_CURL=OFF",
        // GGML_NATIVE lets the build target this exact CPU, which on a modern
        // desktop CPU is a large prefill/decode win over a generic build.
        "-DGGML_NATIVE=ON",
        ...(hw.canBuildCuda ? ["-DGGML_CUDA=ON"] : []),
    ];
    log(`cmake 설정 중… (${hw.canBuildCuda ? "CUDA" : "CPU"})`);
    await run("cmake", cmakeFlags, { cwd: dir, timeout: 20 * 60_000 });
    const jobs = String(Math.max(1, Math.min(hw.cpuCount, 16)));
    log(`빌드 중… (-j${jobs})`);
    await run("cmake", ["--build", buildDir, "--config", "Release", "-j", jobs], {
        cwd: dir,
        // A CUDA build of llama.cpp is genuinely long; the generic 20 min default
        // is not enough on a slow CPU and would abort a build that was working.
        timeout: 120 * 60_000,
    });
    const bin = join(dir, buildDir, "bin", "llama-server");
    if (!(await isExecutable(bin))) {
        throw new Error(`빌드가 끝났지만 ${bin} 을 찾을 수 없습니다.`);
    }
    return bin;
}
async function dirExists(path) {
    try {
        await access(path);
        return true;
    }
    catch {
        return false;
    }
}
