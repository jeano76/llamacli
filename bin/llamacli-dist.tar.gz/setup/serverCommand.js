import { diffServer, gateServerReplacement } from "./serverPolicy.js";
export async function runServerRestart(input, deps) {
    const { report, tuning, confirmed } = input;
    // Plan problems the report already knows (no model, build cannot read it, …).
    if (/읽지 못|확인 불가|config 에 모델이 없습니다/.test(report.restartPlan) || !report.configuredModel) {
        return { restarted: false, lines: [`재시작하지 않습니다 — ${report.restartPlan}`] };
    }
    const binPath = report.build?.binPath ?? input.configBin;
    if (!binPath) {
        return { restarted: false, lines: ["llama-server 실행 파일을 찾지 못했습니다. /models 로 모델을 다시 선택하세요."] };
    }
    const changes = diffServer(report.serverArgs, report.configuredBin && report.build && report.configuredBin !== report.build.binPath ? report.configuredBin : undefined, { modelPath: report.configuredModel, binPath: report.build?.binPath, tuning: tuning });
    const gate = gateServerReplacement({
        owner: report.owner, port: report.port, servers: report.servers, changes, confirmed,
        confirmCommand: "/server restart confirm",
    });
    if (!gate.proceed)
        return { restarted: false, lines: gate.lines };
    const sw = await deps.switchServer({
        modelPath: report.configuredModel,
        port: report.port,
        binPath,
        tuning,
        retune: async () => ({ lines: await deps.describePlan(tuning) }),
    });
    if (sw.ok && sw.launched) {
        await deps.record({ port: sw.port, binPath: sw.launched.binPath, modelPath: sw.launched.modelPath }).catch(() => false);
    }
    const synced = sw.ok ? await deps.sync(report.configuredModel, { contextSize: tuning.contextSize }) : [];
    return { restarted: sw.ok, lines: [...sw.lines, ...synced] };
}
