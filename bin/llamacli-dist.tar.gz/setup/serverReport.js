/**
 * What the model-serving server currently IS, as a report the user can read.
 *
 * ── Why a report and not an action ──────────────────────────────────────────
 * `/models <n>` already switches the server as a side effect, and it does that
 * well. What it cannot do is answer the question a user has when something is
 * already wrong: "what is running right now, on which port, with which build,
 * and is that build the one that can read my model?"
 *
 * That question comes up on its own — after a crash, after an external process
 * took the port, after editing config.yaml by hand — and until now the only way
 * to answer it was to read the file. So `/server` reports, and `/server restart`
 * re-applies the recorded model on the recorded port.
 *
 * The distinction that matters: `/models <n>` CHANGES which model is served,
 * while `/server restart` re-serves the model that is already configured. They
 * are not two spellings of one action, and collapsing them would make "restart
 * my server" silently switch models.
 */
import { detectPortOwner, resolveLiveServerPort, parseLlamaServerArgs } from "./modelSwitch.js";
import { findLlamaServer } from "./llamaCpp.js";
const DEFAULT_PORT = 8080;
export async function reportServer(opts) {
    const llama = (opts.config?.llama ?? {});
    const configuredPort = typeof llama.port === "number" ? llama.port : undefined;
    let configuredModel = typeof llama.modelPath === "string" ? llama.modelPath : undefined;
    let configuredBin = typeof llama.binPath === "string" ? llama.binPath : undefined;
    // The port to inspect: where a llama-server is ACTUALLY listening, falling back to the
    // record only when nothing is. Reporting the record while a server sits on another port
    // said "포트 8080 · 서버 없음" about a live server on 8084 — confidently wrong, and a
    // user who believed it would conclude the server had died (and start a second one).
    const resolvePort = opts.resolvePort ??
        (opts.detectRunningPort
            ? async (r) => {
                const live = await opts.detectRunningPort();
                return resolveLiveServerPort(r, { servers: live === null ? [] : [{ pid: 0, port: live, cmdline: "llama-server" }] });
            }
            : (r) => resolveLiveServerPort(r));
    const resolved = await resolvePort(configuredPort);
    const port = resolved.port;
    const stalePort = configuredPort !== undefined && resolved.source === "live" && resolved.port !== configuredPort
        ? { recorded: configuredPort, actual: resolved.port }
        : undefined;
    const owner = await (opts.detectOwner ?? ((p) => detectPortOwner(p)))(port);
    // A server the user started by hand has no `llama` block in any config — the adopted
    // config only records a URL — so "config 에 모델이 없습니다" would be the whole answer
    // about a server that is plainly running a model. Its own command line has the model,
    // the binary and the tuning; use them for whatever the config does not say.
    const live = resolved.servers?.find((x) => x.port === port);
    const serverArgs = live ? parseLlamaServerArgs(live.cmdline) : undefined;
    let fromRunningServer = false;
    const base = (p) => p.split("/").pop() ?? p;
    const modelMismatch = live && serverArgs?.modelPath && configuredModel && base(serverArgs.modelPath) !== base(configuredModel)
        ? { serving: serverArgs.modelPath, configured: configuredModel }
        : undefined;
    if (live && !configuredModel && serverArgs?.modelPath) {
        configuredModel = serverArgs.modelPath;
        fromRunningServer = true;
    }
    if (live && !configuredBin && live.exe) {
        configuredBin = live.exe;
        fromRunningServer = true;
    }
    let build;
    try {
        const found = await (opts.findServer ?? findLlamaServer)({ modelPath: configuredModel });
        const rejected = found.rejectedForModel ?? [];
        if (found.location) {
            build = {
                binPath: found.location.binPath,
                // A build is only "can read the model" if it was not rejected FOR the
                // model. `location` non-null already implies that, but the flag is
                // carried explicitly so a caller cannot read it the other way round.
                canReadModel: !rejected.includes(found.location.binPath),
                rejectedForModel: rejected,
            };
        }
        else if (rejected.length > 0) {
            // No usable build, but we know WHICH ones refuse this quantization. That
            // is the most actionable thing this report can say — it is the difference
            // between "the model will not load" and "the build is the wrong one" — and
            // an earlier version dropped it, because the section was only filled in
            // when a build was actually found.
            build = {
                binPath: rejected[0],
                canReadModel: false,
                rejectedForModel: rejected,
            };
        }
    }
    catch {
        // Discovery failing is not a reason to fail the report — the port and the
        // owner are the part the user cannot get any other way.
        build = undefined;
    }
    return {
        configuredPort,
        port,
        portDiscovered: configuredPort === undefined || resolved.source === "live",
        stalePort,
        fromRunningServer,
        serverArgs,
        servers: resolved.servers ?? [],
        modelMismatch,
        configuredModel,
        configuredBin,
        owner,
        build,
        summary: summarize({ port, portDiscovered: configuredPort === undefined || resolved.source === "live", stalePort, configuredModel, owner, build, modelMismatch }),
        restartPlan: restartPlan({ configuredModel, configuredBin, port, owner, build, modelMismatch }),
    };
}
function summarize(r) {
    // The RESOLVED port, and marked as discovered when the config did not record
    // it — so "8084 (실행 중인 서버에서 확인)" is visibly a different kind of
    // claim from a recorded "8084".
    const parts = [
        `포트 ${r.port}${r.portDiscovered ? " (실행 중인 서버에서 확인)" : ""}` +
            (r.stalePort ? ` — config 에는 ${r.stalePort.recorded} 로 기록돼 있어 실제와 다릅니다` : ""),
    ];
    if (r.modelMismatch) {
        // Two different models, and which one is actually answering is the first thing to know.
        parts.push(`실행 중인 서버의 모델 ${r.modelMismatch.serving.split("/").pop()}`);
        parts.push(`config 의 모델 ${r.modelMismatch.configured.split("/").pop()} (서버와 다름)`);
    }
    else if (r.configuredModel)
        parts.push(`모델 ${r.configuredModel.split("/").pop()}`);
    switch (r.owner.kind) {
        case "none":
            parts.push("서버 없음 (포트 비어 있음)");
            break;
        case "ours":
            parts.push(`실행 중 (pid ${r.owner.pid}, 이 설치 소유)`);
            break;
        case "systemd":
            parts.push(`systemd 유닛 ${r.owner.unit} 이 사용 중`);
            break;
        case "foreign":
            parts.push(`알 수 없는 프로세스 pid ${r.owner.pid ?? "?"} 가 사용 중`);
            break;
        case "unknown":
            parts.push(`확인 불가 (${r.owner.reason})`);
            break;
    }
    if (r.build) {
        parts.push(r.build.canReadModel ? `빌드 ${r.build.binPath.split("/").slice(-2).join("/")}` : "빌드가 이 모델의 양자화를 읽지 못함");
    }
    return parts.join(" · ");
}
function restartPlan(r) {
    if (!r.configuredModel) {
        return "config 에 모델이 없습니다. /models 로 먼저 선택하세요.";
    }
    if (r.build && !r.build.canReadModel) {
        return (`설치된 빌드가 이 모델의 양자화를 읽지 못합니다 (거절된 빌드: ${r.build.rejectedForModel.join(", ") || "?"}). ` +
            "호환 빌드가 필요합니다.");
    }
    if (r.owner.kind === "systemd") {
        return (`포트 ${r.port} 를 systemd 유닛 ${r.owner.unit} 이 사용 중입니다. ` +
            "이 유닛은 자체적으로 모델을 지정하므로 재시작만으로 새 모델이 적용되지 않습니다.");
    }
    if (r.owner.kind === "unknown" || r.owner.kind === "foreign") {
        return `포트 ${r.port} 의 사용자를 확인할 수 없어 재시작하지 않습니다 (${r.owner.kind}).`;
    }
    const change = r.modelMismatch
        ? ` 모델이 ${r.modelMismatch.serving.split("/").pop()} → ${r.configuredModel.split("/").pop()} 로 바뀝니다.`
        : "";
    return `기존 서버를 종료하고 같은 포트(${r.port})에서 ${r.configuredModel.split("/").pop()} 로 다시 올립니다.${change}`;
}
