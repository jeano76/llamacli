/**
 * Local-model metrics: which models this machine can actually run, and why.
 *
 * ── Why this is not just a size list ────────────────────────────────────────
 * "Will it run on my PC" is not a question about file size alone, and answering
 * it with a size column is how people end up with a 22 GB download that OOMs
 * on load. Three things decide it, and all three are measured here:
 *
 *   1. Does the WEIGHTS fit in VRAM? → full offload, GPU-bound decode.
 *   2. If not, is there RAM to stream the MoE experts from? → runs, slower.
 *      This is the case that matters most in practice: an 8 GB card running a
 *      35B-A3B works precisely because only the ~3B active parameters are
 *      resident and the rest pages from RAM (`--n-cpu-moe`, see tuning.ts).
 *   3. If neither, does it fit in RAM at all? → CPU-only, very slow, or no.
 *
 * The VRAM budget deliberately reuses `budgetVramGiB` rather than repeating the
 * reserve arithmetic. That function holds back 1 GiB for the compositor and
 * load-time allocations, measured against gnome-shell holding 150 MiB on this
 * box; a second copy of that arithmetic here would be free to drift from the one
 * the tuner actually launches with, and the table would then promise a fit that
 * the launch does not honour.
 *
 * Deliberately NOT here: tokens/second estimates. They depend on the quant, the
 * build, the card's clocks and what else is running, and a confident-looking
 * number that is wrong by 3x is worse than no number.
 */
import stringWidth from "string-width";
import { pickPrimaryGpu } from "./hardware.js";
import { budgetVramGiB } from "./tuning.js";
import { APPROX_SIZES, BONSAI_27B_REPO, BONSAI_8B_REPO, BONSAI_4B_REPO, ORNITH_35B_REPO, ORNITH_9B_REPO } from "./modelCatalog.js";
const GiB = 1024 ** 3;
/** The rungs offered, largest first — the order a user scans when deciding what
 *  they can trade away. Sizes are the measured files where this machine has
 *  them; the 27B figure is the PTQ1_0 quant's, which is why that rung is small
 *  for its parameter count. */
export const MODEL_RUNGS = [
    {
        id: "ornith-35b",
        label: "Ornith-1.5-35B-A3B",
        params: "35B",
        activeParamB: 3,
        activeParams: "3B 활성 (MoE)",
        quant: "Q4_K_M",
        sizeBytes: APPROX_SIZES["35b-a3b"],
        repo: ORNITH_35B_REPO,
    },
    {
        id: "bonsai-27b",
        label: "Ternary-Bonsai-2-27B",
        params: "27B (밀집)",
        quant: "PTQ1_0",
        // PTQ1_0: ~5.5 GiB, which is the whole reason this rung exists.
        sizeBytes: Math.round(5.5 * GiB),
        approximate: true,
        repo: BONSAI_27B_REPO,
    },
    {
        id: "ornith-9b",
        label: "Ornith-1.5-9B",
        params: "9B",
        quant: "Q4_K_M",
        sizeBytes: APPROX_SIZES["9b"],
        approximate: true,
        repo: ORNITH_9B_REPO,
    },
    {
        id: "bonsai-8b",
        label: "Ternary-Bonsai-8B",
        params: "8B (밀집)",
        quant: "PTQ1_0",
        sizeBytes: Math.round(1.9 * GiB),
        approximate: true,
        repo: BONSAI_8B_REPO,
    },
    {
        id: "bonsai-4b",
        label: "Ternary-Bonsai-4B",
        params: "4B (밀집)",
        quant: "PTQ1_0",
        sizeBytes: Math.round(1.0 * GiB),
        approximate: true,
        repo: BONSAI_4B_REPO,
    },
];
const KV_GIB_PER_TOKEN = 0.3 / (1024 * 1024); // ~0.3 MB/token at q8_0
/** How much VRAM is actually spendable on this machine right now. */
export function usableVramGiB(hw) {
    const gpu = pickPrimaryGpu(hw);
    return budgetVramGiB(hw, gpu);
}
/**
 * Decides how a rung runs on this machine.
 *
 * The three-way split mirrors what llama.cpp actually does:
 *   - weights ≤ budget          → `-ngl 999`, everything on the GPU
 *   - weights ≤ budget + RAM    → `--n-cpu-moe N` pages experts from RAM
 *   - weights ≤ RAM only        → `-ngl 0`, CPU-only, honest about being slow
 *   - otherwise                 → does not run, and says so
 */
export function evaluateFit(rung, hw) {
    const budget = usableVramGiB(hw);
    const ramGiB = hw.ramTotalBytes / GiB;
    const sizeGiB = rung.sizeBytes / GiB;
    // What has to be RESIDENT differs by architecture, and conflating the two is
    // how a table ends up promising a full offload that then streams.
    //
    // For a DENSE model that is the whole file: every weight is touched every
    // token, so all of it wants to be on the GPU.
    //
    // For a MoE model it is the ACTIVE parameters only. The inactive experts are
    // touched rarely enough that llama.cpp pages them from RAM (`--n-cpu-moe`),
    // and it is exactly this that lets a 35B-A3B run on an 8 GB card — measured
    // on this box as `-ngl 999 --n-cpu-moe 30`.
    //
    // The first version of this used a flat "15% of the file" guess, and the
    // version after that tested only the ACTIVE size against the budget. Both
    // reported the 21.9 GiB 35B-A3B as a ✅ FULL VRAM fit on a 7 GiB budget,
    // because neither asked whether the WHOLE FILE fits. An explicit active count
    // fixes the guess; asking about the total is what fixes the verdict.
    const bitsPerWeight = 4.8; // Q4-class: 4.5 for the quant plus GGUF metadata
    const activeGiB = rung.activeParamB ? (rung.activeParamB * 1e9 * (bitsPerWeight / 8)) / GiB : sizeGiB;
    // Full offload requires the WHOLE file to be resident, which is the one
    // question that decides "vram" vs "stream".
    if (sizeGiB <= budget) {
        const spare = budget - sizeGiB;
        const ctx = Math.floor(spare / KV_GIB_PER_TOKEN / 1024) * 1024;
        return {
            rung,
            fit: "vram",
            budgetGiB: budget,
            maxContext: Math.max(4096, Math.min(32768, ctx)),
            verdict: `✅ GPU에 완전히 올라갑니다 (모델 ${sizeGiB.toFixed(1)} GiB ≤ 여유 VRAM ${budget.toFixed(1)} GiB). ` +
                `GPU가 전부 계산하므로 가장 빠릅니다.`,
        };
    }
    // The file does not fit. A MoE model can still run if the active parameters
    // are what stay resident; a dense one cannot, because every weight is needed
    // every token.
    if (rung.activeParamB && activeGiB <= budget && sizeGiB <= ramGiB * 0.7) {
        return {
            rung,
            fit: "stream",
            budgetGiB: budget,
            verdict: `⚠️ 모델 전체(${sizeGiB.toFixed(1)} GiB)는 VRAM(${budget.toFixed(1)} GiB)에 안 올라갑니다. ` +
                `하지만 활성 파라미터 약 ${rung.activeParamB}B만 GPU에 남기고 나머지 expert 를 ` +
                `RAM(${ramGiB.toFixed(0)} GiB)에서 스트리밍하면 실행됩니다. 느리지만 동작합니다.`,
        };
    }
    if (sizeGiB <= ramGiB * 0.7) {
        return {
            rung,
            fit: "ram",
            budgetGiB: budget,
            verdict: `⚠️ GPU는 사용하지 않고 CPU 전용(-ngl 0)으로만 실행됩니다. ` +
                `RAM(${ramGiB.toFixed(0)} GiB)에는 들어가지만 생성 속도가 매우 느립니다.`,
        };
    }
    return {
        rung,
        fit: "no",
        budgetGiB: budget,
        verdict: `❌ 이 머신에서는 실행되지 않습니다 (RAM ${ramGiB.toFixed(0)} GiB, 여유 VRAM ${budget.toFixed(1)} GiB).`,
    };
}
/** Every rung, evaluated against this machine. */
export function evaluateAll(hw, rungs = MODEL_RUNGS) {
    return rungs.map((r) => evaluateFit(r, hw));
}
/** Finds a rung by id, case-insensitively. */
export function findRung(id, rungs = MODEL_RUNGS) {
    const q = id.trim().toLowerCase();
    return rungs.find((r) => r.id === q || r.label.toLowerCase() === q);
}
/**
 * Renders the catalogue as an aligned table.
 *
 * Column widths are computed from the content rather than hard-coded, because
 * these labels mix Korean and ASCII (a Korean glyph is two columns wide) and a
 * fixed-width template is exactly how a table ends up one column off. East Asian
 * width is measured with `string-width`, the same helper the TUI uses, so a row
 * cannot disagree with what is finally rendered.
 *
 * Returns BOTH the rendered lines and the 1-based numbers shown, so the caller
 * can tell the user which number to type and the selection code uses the same
 * numbering. Deriving them separately is how "/models 3" ends up selecting a
 * different row than the one labelled 3.
 */
export function formatModelTable(reports) {
    const head = ["#", "모델", "파라미터", "양자화", "크기", "판정"];
    const rows = reports.map((r, i) => [
        String(i + 1),
        r.rung.label,
        r.rung.activeParams ?? r.rung.params,
        r.rung.quant,
        `${(r.rung.sizeBytes / GiB).toFixed(1)} GiB${r.rung.approximate ? " (추정)" : ""}`,
        r.fit === "vram" ? "✅ VRAM" : r.fit === "stream" ? "⚠️ RAM 스트리밍" : r.fit === "ram" ? "⚠️ CPU 전용" : "❌ 불가",
    ]);
    // stringWidth counts display columns, which is what a terminal uses.
    const widths = head.map((h, c) => Math.max(stringWidth(h), ...rows.map((r) => stringWidth(r[c] ?? ""))));
    const pad = (s, w) => s + " ".repeat(Math.max(0, w - stringWidth(s)));
    const lines = [
        head.map((h, c) => pad(h, widths[c])).join("  ").trimEnd(),
        head.map((_, c) => "─".repeat(widths[c])).join("  "),
        ...rows.map((r) => r.map((cell, c) => pad(cell, widths[c])).join("  ").trimEnd()),
    ];
    return { lines, numbers: rows.map((_, i) => i + 1) };
}
// Imported late to keep the module's own imports at the top readable; it is the
// same helper the TUI measures rendered text with.
