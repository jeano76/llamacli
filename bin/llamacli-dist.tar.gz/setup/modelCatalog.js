/**
 * Choosing which model to download, and finding it on Hugging Face.
 *
 * Requested directly: "해당 컴퓨터의 gpu VRAM에 적합한 Ornith-1.5-35B-A3B-Q4_K_M.gguf
 * 또는 Ornith-1.5 9B 로컬 모델등 정합한 모델을 다운로드 받는 초기 과정을
 * 수행해야해" — pick the Ornith that fits this machine's VRAM.
 *
 * ── The decision ────────────────────────────────────────────────────────────
 * Two candidates, and the choice between them is a fit calculation, not a
 * preference:
 *
 *   - 35B-A3B Q4_K_M is a ~22 GB file but only ~3B parameters are active per
 *     token (Mixture-of-Experts). It therefore FITS ON A SMALL CARD — but only
 *     if the expert tensors that aren't needed for every token are allowed to
 *     live in system RAM (`--n-cpu-moe`, see tuning.ts). On the 8 GB RTX 2070
 *     this repo is developed on, it runs at ~19 tok/s.
 *   - 9B Q4_K_M is a ~5.5 GB file that fits fully on the same card and is
 *     several times faster, at some cost in capability.
 *
 * So the rule is: use the 35B when the card can hold the *active* parameters
 * comfortably AND there is enough system RAM to page experts from; otherwise
 * the 9B, which is the only one of the two that is fast without a RAM caveat.
 * Picking the 35B on a machine with too little RAM produces something that
 * technically loads and is unusable — which is why RAM is part of the test and
 * not just VRAM.
 *
 * ── Why the repos are pinned rather than searched ──────────────────────────
 * These ids are the publisher's own (`ornith-ai/…`), verified against the Hub
 * API: both return HTTP 200 and both list the Q4_K_M quant this prefers. They
 * were previously written WITHOUT the namespace, which is a repo that does not
 * exist and answers HTTP 401 — so on any machine with no model already
 * configured, first-run bootstrap failed to resolve anything, wrote a config
 * with no `modelPath`, and the spawn condition in index.tsx could never be
 * satisfied. A guessed id is not a safer default than a verified one; it is
 * just an unverifiable one.
 *
 * `MODEL_REPO_35B` / `MODEL_REPO_9B` still override both, for a mirror or a
 * different quantisation. A repository search remains the fallback when a
 * pinned repo is unreachable, so a renamed or moved repo degrades to a search
 * rather than to a dead first run.
 */
import { normalizeSha256 } from "./checksum.js";
export const HF_ENDPOINT = "https://huggingface.co";
/** The publisher's own repos, namespace included. See the header comment: the
 *  un-namespaced form of these ids is a repo that does not exist. */
export const ORNITH_35B_REPO = "ornith-ai/Ornith-1.5-35B-A3B-GGUF";
export const ORNITH_9B_REPO = "ornith-ai/Ornith-1.5-9B-GGUF";
/** The quant the request named explicitly. Preferred when present. */
export const PREFERRED_35B_QUANT = "Q4_K_M";
export const PREFERRED_9B_QUANT = "Q4_K_M";
/** Approximate on-disk sizes, used to plan BEFORE the Hub answers (and as the
 *  fallback when it can't). Close enough to size a download, not to be relied on
 *  for correctness. */
export const APPROX_SIZES = {
    "35b-a3b": 21_864_081_056,
    "9b": 5_497_000_000,
};
const GiB = 1024 ** 3;
/** Quants in descending quality, best-first. `Q4_K_M` is the sweet spot the
 *  request named; the others are only reached if it is absent from a repo. */
const QUANT_PREFERENCE = ["Q4_K_M", "Q5_K_M", "Q6_K", "Q4_K_S", "Q3_K_XL", "Q3_K_M", "Q2_K"];
/** Families this project ships that are DENSE (no experts): the Ornith 9B. */
export function isKnownDenseFamily(filename) {
    return /Ornith-1\.5-9B/i.test(filename);
}
/** `Ornith-1.5-9B-Q4_K_M.gguf` → `Ornith-1.5-9B`; the model family without its quant. */
export function modelFamilyOf(filename) {
    const base = filename.replace(/\.gguf$/i, "").replace(/-\d{5}-of-\d{5}$/, "");
    const quant = /-(Q\d_0(?:_g\d+)?|Q\d_K(?:_[SML]|_XL)?|UD-Q\d_K(?:_[SML]|_XL)?|IQ\d_\w+|BF16|F16|F32)$/i.exec(base);
    return quant ? base.slice(0, quant.index) : base;
}
/**
 * The candidate that IS the model the user selected, out of everything the Hub lists.
 *
 * An exact filename wins. Failing that, the same family (`Ornith-1.5-9B`) in the best available quant:
 * the model table names one quant per rung, which is not always what the repo publishes, and refusing
 * there would make a valid selection undownloadable. Anything outside the family is NEVER returned —
 * substituting a different model for the chosen one is the bug this exists to prevent (a selected
 * small model once downloaded a much larger one).
 */
export function pickPinnedCandidate(candidates, filename) {
    const exact = candidates.find((c) => c.filename.toLowerCase() === filename.toLowerCase());
    if (exact)
        return exact;
    const family = modelFamilyOf(filename).toLowerCase();
    const sameFamily = candidates.filter((c) => !/mmproj/i.test(c.filename) && modelFamilyOf(c.filename).toLowerCase() === family);
    if (sameFamily.length === 0)
        return null;
    return [...sameFamily].sort((a, b) => quantRank(a.filename) - quantRank(b.filename) || a.filename.localeCompare(b.filename))[0];
}
function quantRank(filename) {
    const i = QUANT_PREFERENCE.findIndex((q) => filename.includes(q));
    return i === -1 ? QUANT_PREFERENCE.length : i;
}
/**
 * The fit test, isolated and pure so it can be tested against every hardware
 * shape that matters without a network call.
 *
 * `vramFreeBytes` and `ramTotalBytes` are the two inputs; everything else is a
 * fixed allowance. The numbers were chosen from the one machine this feature
 * could be measured on (8 GB VRAM, 30 GB RAM, where the 35B runs well) and are
 * deliberately conservative: the failure this avoids is a download that
 * succeeds and a server that then runs at single-digit tok/s.
 */
export function chooseModel(opts) {
    const { vramTotalBytes, vramFreeBytes, ramTotalBytes } = opts;
    const pick35 = best(opts.candidates35b);
    const pick9 = best(opts.candidates9b);
    const vramGiB = vramTotalBytes / GiB;
    const freeGiB = Math.max(0, vramFreeBytes || vramTotalBytes) / GiB;
    const ramGiB = ramTotalBytes / GiB;
    // Room for the ACTIVE parameters of a 35B-A3B, plus the KV cache and the
    // transient allocations a load makes before it settles. 6 GB is the measured
    // floor for "the 3B active set + context" to run at a usable speed.
    const RESERVE_GIB = 1.0;
    const MIN_35B_VRAM_GIB = 6.0;
    // Each expert layer paged out of VRAM streams from RAM during decode, so the
    // system has to hold the whole 22 GB model plus room to work. Below ~1.4x the
    // model size, paging turns into swapping and the box becomes unusable.
    const MIN_RAM_MULTIPLE = 1.4;
    const size35 = pick35?.sizeBytes || APPROX_SIZES["35b-a3b"];
    const reasons = [];
    reasons.push(`VRAM ${vramGiB.toFixed(1)} GiB(여유 ${freeGiB.toFixed(1)} GiB), RAM ${ramGiB.toFixed(1)} GiB`);
    const vramOk = vramGiB >= MIN_35B_VRAM_GIB;
    const ramOk = ramGiB * GiB >= size35 * MIN_RAM_MULTIPLE;
    const canUse35b = Boolean(pick35) && vramOk && ramOk;
    if (canUse35b) {
        const how = vramGiB >= size35 / GiB
            ? "전량 오프로드"
            : "활성 파라미터만 GPU, expert 일부는 RAM에서 스트리밍(--n-cpu-moe)";
        return {
            candidate: pick35,
            reason: `Ornith-1.5-35B-A3B ${pick35.filename} 을 선택했습니다. ` +
                `${reasons[0]}. ${how}. ${(size35 / GiB).toFixed(1)} GiB 다운로드.`,
            alternatives: [pick9, ...opts.candidates9b.filter((c) => c.filename !== pick9?.filename)].filter(Boolean),
        };
    }
    const why = [];
    if (!pick35)
        why.push("35B 저장소를 찾지 못함");
    if (!vramOk)
        why.push(`VRAM ${vramGiB.toFixed(1)} GiB < 필요한 ${MIN_35B_VRAM_GIB} GiB`);
    if (!ramOk)
        why.push(`RAM ${ramGiB.toFixed(1)} GiB < 모델의 ${(size35 * MIN_RAM_MULTIPLE / GiB).toFixed(1)} GiB`);
    reasons.push(`35B 대신 9B 선택: ${why.join(", ")}`);
    // Nothing smaller than the 9B is offered. A machine that cannot hold it comfortably is told so in the
    // reason instead of being handed something else: the same 1.4x-RAM rule the 35B uses applies, and below
    // it the model pages from disk and the box becomes slow.
    const size9 = pick9?.sizeBytes || APPROX_SIZES["9b"];
    const tooSmallFor9b = ramGiB * GiB < size9 * MIN_RAM_MULTIPLE;
    if (pick9) {
        return {
            candidate: pick9,
            reason: `Ornith-1.5-9B ${pick9.filename} 을 선택했습니다. ${reasons.join(". ")}. ` +
                `약 ${((pick9.sizeBytes || APPROX_SIZES["9b"]) / GiB).toFixed(1)} GiB 이며 GPU에 전량 올라갑니다.` +
                (tooSmallFor9b
                    ? ` 주의: RAM ${ramGiB.toFixed(1)} GiB 는 이 모델 크기의 ${MIN_RAM_MULTIPLE}배(${((size9 * MIN_RAM_MULTIPLE) / GiB).toFixed(1)} GiB)에 못 미쳐 느릴 수 있습니다.`
                    : ""),
            alternatives: pick35 ? [pick35] : [],
        };
    }
    // Nothing at all: report it rather than pretending, so the caller can say so.
    throw new Error(`사용 가능한 모델을 찾지 못했습니다 (${reasons.join("; ")}). ` +
        `MODEL_REPO_35B / MODEL_REPO_9B 환경변수로 저장소를 직접 지정하세요.`);
}
function best(list) {
    if (list.length === 0)
        return null;
    return [...list].sort((a, b) => quantRank(a.filename) - quantRank(b.filename))[0];
}
/** The Hub's model search. Returns repo ids matching `query`. */
export async function searchHubModels(query, opts = {}) {
    const doFetch = opts.fetchImpl ?? fetch;
    const url = `${HF_ENDPOINT}/api/models?search=${encodeURIComponent(query)}&limit=${opts.limit ?? 20}&full=true`;
    const res = await doFetch(url, { signal: opts.signal });
    if (!res.ok)
        throw new Error(`HuggingFace 검색 실패: HTTP ${res.status}`);
    const json = (await res.json());
    return json.map((m) => m.id).filter((id) => Boolean(id));
}
/** Lists a repo's GGUF files. */
export async function listGgufFiles(repo, opts = {}) {
    const doFetch = opts.fetchImpl ?? fetch;
    // `?blobs=true` makes the Hub return each sibling's real byte size, which is
    // what lets the progress bar have a denominator before anything downloads.
    const res = await doFetch(`${HF_ENDPOINT}/api/models/${repo}?blobs=true`, { signal: opts.signal });
    if (!res.ok)
        throw new Error(`HuggingFace 파일 목록 실패 (${repo}): HTTP ${res.status}`);
    const json = (await res.json());
    return (json.siblings ?? [])
        .filter((s) => s.rfilename?.toLowerCase().endsWith(".gguf"))
        .map((s) => ({
        repo,
        filename: s.rfilename,
        sizeBytes: s.size ?? 0,
        url: `${HF_ENDPOINT}/${repo}/resolve/main/${s.rfilename}`,
        ...(normalizeSha256(s.lfs?.sha256) ? { sha256: normalizeSha256(s.lfs?.sha256) } : {}),
    }));
}
/**
 * Resolves the model to download: pinned repos from the environment if set,
 * otherwise a Hub search filtered to GGUFs.
 *
 * Search results are filtered to GGUF repos only — a search for "Ornith-1.5"
 * returns the safetensors weights too, and downloading 22 GB of the wrong file
 * format would be a spectacular waste.
 */
export async function resolveModel(opts = {}) {
    const env = opts.env ?? process.env;
    const log = opts.log ?? (() => { });
    const pinned35 = env.MODEL_REPO_35B;
    const pinned9 = env.MODEL_REPO_9B;
    // A repo that cannot be listed yields an empty list rather than throwing, so
    // one unreachable family cannot prevent the other from being considered.
    const c35 = await resolveOne(pinned35 ?? ORNITH_35B_REPO, ["Ornith-1.5-35B-A3B", "Ornith-1.5-35B"], opts, log, "35B", Boolean(pinned35)).catch(() => []);
    const c9 = await resolveOne(pinned9 ?? ORNITH_9B_REPO, ["Ornith-1.5-9B", "Ornith-1.5"], opts, log, "9B", Boolean(pinned9)).catch(() => []);
    return { c35, c9 };
}
/** The pinned repo when it answers, a repository search when it does not.
 *
 *  A pinned id that 401s or 404s must not end the first run: the whole point of
 *  pinning is that it is a good default, not that it is guaranteed to be
 *  permanent. Falling back to the search costs one request and turns a dead
 *  start into a possibly-slower working one. An explicit `MODEL_REPO_*` does
 *  NOT get this fallback — if the user named a repo, silently using a
 *  different one is worse than telling them it was unreachable. */
async function resolveOne(repo, fallbackQueries, opts, log, label, 
/** True when the user named this repo explicitly, in which case silently
 *  substituting a different one is worse than reporting the failure. */
explicit) {
    try {
        const files = await listGgufFiles(repo, opts);
        if (files.length > 0)
            return files;
        log(`${repo} 에서 .gguf 를 찾지 못했습니다.`);
    }
    catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        if (explicit) {
            log(`MODEL_REPO_${label}=${repo} 에 접근할 수 없습니다: ${msg}`);
            return [];
        }
        log(`${repo} 에 접근할 수 없습니다 (${msg}) — 저장소 검색으로 바꿉니다.`);
    }
    return searchAndList(fallbackQueries, opts, log);
}
async function searchAndList(queries, opts, log) {
    const seen = new Set();
    const out = [];
    for (const q of queries) {
        let ids;
        try {
            ids = await searchHubModels(q, opts);
        }
        catch {
            continue; // a failed query must not abort the whole bootstrap
        }
        for (const id of ids) {
            if (seen.has(id))
                continue;
            seen.add(id);
            if (!/gguf/i.test(id))
                continue; // never the safetensors repo
            try {
                const files = await listGgufFiles(id, opts);
                if (files.length > 0) {
                    out.push(...files);
                }
            }
            catch {
                continue;
            }
        }
        if (out.length > 0)
            break;
    }
    return out;
}
