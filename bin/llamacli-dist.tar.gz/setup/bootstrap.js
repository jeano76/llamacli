/**
 * The first-run bootstrap: make sure a llama-server binary, a model that fits
 * this machine, and a set of non-conflicting ports all exist, then write them
 * into `.llamacli/config.yaml` so every later launch is a no-op.
 *
 * Requested directly: "llamacli 의 초기 구동 시 llama.cpp 가 존재를 하지 않는다면
 * 관련 설치 패키지와 llama.cpp 를 설치하고 … 정합한 모델을 다운로드 받는 초기
 * 과정을 수행해야해 … llama.cpp의 포트와 llamacli 에서 사용하는 포트가 맞아야
 * 하고 … 초기 llama
 * 구동시 cpu 가 여러개 인경우에는 Nvidia gpu를 우선 순으로 정의 … 사용자 개입없이
 * 진행이 될수 있도록".
 *
 * ── The one rule that shapes everything: it must not need a human ───────────
 * Every step is derived from measurements (src/setup/hardware.ts) and every
 * step is idempotent, so a second run costs a few file checks and nothing
 * else. The steps that COULD ask — "which model?", "which port?" — are
 * answered by fit calculations and reported, never prompted.
 *
 * And it degrades instead of failing. A bootstrap that throws takes down a
 * working install; a bootstrap that returns a report lets the caller start
 * anyway with whatever is already there. That is why `ensureLocalStack` returns
 * a report containing `ok: false` with per-step errors rather than throwing.
 */
import { mkdir, writeFile, readFile, rename } from "node:fs/promises";
import { join, dirname, basename } from "node:path";
import { stringify, parse } from "yaml";
import { detectHardware, findOwnLlamaServerPids, ownLlamaServerVramGiB } from "./hardware.js";
import { getCapabilities } from "../tui/terminal.js";
import { tuneForHardware } from "./tuning.js";
import { findLlamaServer, defaultRun, probeModelCompatibility, looksLikeUnsupportedModelFormat, } from "./llamaCpp.js";
import { planPorts, tcpPortProbe, COMMON_PORTS } from "./ports.js";
import { acquireTernaryLlamaServer } from "./ternaryRuntime.js";
import { acquireStockLlamaServer } from "./stockRuntime.js";
import { chooseModel, resolveModel } from "./modelCatalog.js";
import { downloadFile, formatProgress } from "./download.js";
import { selectModelPath, hasRoom, RESERVE_BYTES } from "./disk.js";
import { discoverRunningServer, modelLoadBudgetMs } from "../backend/detect.js";
import { defaultModelsDir } from "./hostEnv.js";
/**
 * Kept as a value for existing callers, but it is a POSIX guess and is WRONG on
 * Windows, where `HOME` is normally unset. It is now derived from `homedir()`,
 * which resolves `USERPROFILE` there, instead of `process.env.HOME ?? "/root"` —
 * a hardcoded root that produced a plausible, impossible path rather than an
 * error. Anything that has the caller's `env` in hand must prefer
 * `defaultModelsDir(env)`, which honours an injected HOME.
 */
export const DEFAULT_MODELS_DIR = defaultModelsDir();
/** Idempotency marker. Without it there is no way to tell "never bootstrapped"
 *  from "bootstrapped and everything was already present", and the expensive
 *  steps would re-run their checks forever. */
const STATE_VERSION = 1;
export async function ensureLocalStack(opts) {
    const log = opts.log ?? (() => { });
    const run = opts.run ?? defaultRun;
    const env = opts.env ?? process.env;
    const steps = [];
    const errors = [];
    const step = async (name, fn) => {
        const t0 = Date.now();
        try {
            const detail = await fn();
            steps.push({ name, ok: true, detail, tookSeconds: (Date.now() - t0) / 1000 });
            return detail;
        }
        catch (err) {
            const message = err instanceof Error ? err.message : String(err);
            steps.push({ name, ok: false, detail: message, tookSeconds: (Date.now() - t0) / 1000 });
            errors.push(`${name}: ${message}`);
            return null;
        }
    };
    // ── 1. Hardware ───────────────────────────────────────────────────────────
    const hardware = opts.hardware ?? (await detectHardware(run));
    steps.push({
        name: "하드웨어 확인",
        ok: true,
        detail: `CPU ${hardware.cpuCount}코어, RAM ${(hardware.ramTotalBytes / 1024 ** 3).toFixed(0)} GiB, ` +
            (hardware.gpus.length > 0
                ? `GPU ${hardware.gpus.map((g) => `${g.name} ${(g.vramTotalBytes / 1024 ** 3).toFixed(0)}GiB`).join(", ")}`
                : "GPU 없음"),
    });
    log(steps[0].detail);
    // `force` is what `/reset` uses: re-derive the machine-derived settings from
    // the CURRENT hardware instead of inheriting them. It keeps only the keys a
    // human typed (apiKey, verify, browser, compaction…) — see
    // `keepUserOwnedKeys` — and it skips the adopt-a-running-server short-circuit
    // below, because a reset that just adopts whatever happens to be running has
    // re-derived nothing at all.
    //
    // Without it `/reset` would be a near no-op on a machine whose hardware has
    // not changed, and the user would reasonably conclude it did nothing.
    const existing = opts.force
        ? keepUserOwnedKeys(await readConfig(opts.projectRoot))
        : await readConfig(opts.projectRoot);
    // ── 2. llama-server binary ────────────────────────────────────────────────
    // The model is chosen in step 3, but a config that already names one is
    // enough to know whether the BINARY can read it — and that check has to
    // happen here, because a build whose type registry rejects the quant looks
    // exactly like a working install until the server starts. Two llama.cpp
    // builds coexisted on this machine, one of which read a 1-bit model fine and
    // the other rejecting it with "invalid ggml type 143".
    const configuredModel = typeof existing?.llama?.modelPath === "string" && existing.llama.modelPath
        ? existing.llama.modelPath
        : typeof existing?.model === "string" && existing.model
            ? existing.model
            : undefined;
    const { location: found, rejected, rejectedForModel } = await findLlamaServer({
        env,
        home: env.HOME,
        modelPath: configuredModel,
    });
    let llama = found ?? undefined;
    /** Gets a llama-server when none was found. DEFERRED until the model is known:
     *  this used to run here, before the running-server check and before the model
     *  choice, so a machine that already had a server up still compiled one, and a
     *  first launch compiled stock llama.cpp and then discovered the chosen Bonsai
     *  model needed the fork — 10-40 minutes spent on a binary that was thrown away. */
    let engineFailed = false;
    /** Progress sink for the engine's download/compile. Set before `acquireEngine`
     *  runs: a redrawn line normally, but nothing when a model download is running
     *  beside it (two writers on one transient line just flicker). */
    let engineProgress;
    const acquireEngine = async (chosen) => {
        if (llama)
            return;
        // A binary that exists but cannot run is a different problem from a binary
        // that is not installed, and reporting it as the latter sends the user
        // looking for an install that is sitting right there.
        const modelRejectedNote = rejectedForModel && rejectedForModel.length > 0
            ? ` (실행은 되지만 이 모델의 양자화 형식(${basename(configuredModel ?? "")})을 읽지 못하는 빌드: ${rejectedForModel.join(", ")})`
            : "";
        const rejectedNote = rejected.length > 0
            ? ` (찾았지만 실행 불가: ${rejected.join(", ")})${modelRejectedNote}`
            : modelRejectedNote;
        if (opts.offline || opts.allowBuild === false) {
            steps.push({
                name: "llama.cpp",
                ok: false,
                detail: `설치된 llama-server 를 찾지 못했습니다 (오프라인/빌드 금지 모드).${rejectedNote}`,
            });
        }
        else {
            if (rejected.length > 0) {
                // Rebuilding will not fix a binary that is present and broken, and the
                // 10-40 minutes it costs is better spent saying why.
                log(`찾은 llama-server 가 실행되지 않습니다: ${rejected.join(", ")}`);
                log("드라이버 또는 런타임 라이브러리 문제일 수 있습니다. 그래도 직접 빌드를 시도합니다.");
            }
            // Which llama.cpp is being installed is decided by what the MODEL needs, not
            // by what is easiest to build. The ternary quants (PTQ1_0 / PQ2_0) are a fork
            // feature -- stock ggml-org rejects them as "invalid ggml type 143" -- and the
            // fork's own roadmap still lists the CUDA kernels as unmerged upstream. So
            // building the stock repo for a Bonsai model spends 10-40 minutes to produce a
            // binary that fails on the very model it was built for.
            const wantsTernary = needsTernaryBuild(basename(configuredModel ?? "")) ||
                (chosen ? needsTernaryBuild(chosen.candidate.filename) : false) ||
                (rejectedForModel?.length ?? 0) > 0 ||
                (rejected ?? []).length > 0;
            if (wantsTernary) {
                // Download the fork's pinned prebuilt; build the fork only if the release
                // has nothing for this platform.
                const binPath = await step("PrismML llama-server 준비", async () => {
                    const got = await (opts.acquireTernary ?? acquireTernaryLlamaServer)({ hardware, run, log, onProgress: engineProgress });
                    if (!got)
                        throw new Error("PrismML llama-server 를 받을 수도, 빌드할 수도 없었습니다.");
                    return got.binPath;
                });
                if (binPath) {
                    llama = {
                        binPath,
                        source: "downloaded",
                        // The asset states which accelerator it was built for; claiming one we
                        // did not verify would be a guess wearing a fact's clothes.
                        backend: hardware.gpuBackend === "none" ? "cpu" : hardware.gpuBackend,
                    };
                }
            }
            else {
                // Prebuilt first, compile last, every rung run before it is believed — see
                // stockRuntime.ts. This used to be an unconditional 10-40 minute compile.
                await step("llama.cpp 준비", async () => {
                    const r = await (opts.acquireStock ?? acquireStockLlamaServer)({
                        hardware, run: run, log, modelPath: configuredModel,
                        onProgress: engineProgress,
                    });
                    if (!r)
                        throw new Error("llama-server 를 받을 수도, 빌드할 수도 없었습니다.");
                    llama = { binPath: r.binPath, source: r.source, backend: r.backend };
                    return `${r.binPath} (${r.source === "downloaded" ? "사전 빌드" : "소스 빌드"}, ${r.backend})`;
                });
            }
            if (!llama)
                engineFailed = true;
        }
    };
    if (llama) {
        steps.push({
            name: "llama-server 확인",
            ok: true,
            detail: `${llama.binPath} (${llama.source})`,
        });
        log(`기존 llama-server 사용: ${llama.binPath}`);
    }
    // ── 2.5 Adopt an already-running server, BEFORE touching the network ──────
    // This check used to live in step 5, AFTER the model had been resolved and
    // DOWNLOADED. On a machine that already has a healthy llama-server serving a
    // model, that meant the bootstrap searched HuggingFace and began a 20 GB
    // fetch before ever noticing there was nothing to do.
    //
    // Not a theoretical waste — confirmed live. A 20 GB model deleted to reclaim
    // disk space was silently re-downloaded, in full, on the next launch: the file
    // the running server was actually serving had a different name AND a
    // different byte count from the one the Hub publishes today, so the
    // "equivalent model already on disk" check could not match it — while the
    // server serving that very file was up the whole time.
    //
    // So "is there already a server I can simply use?" is asked FIRST, and a yes
    // ends the bootstrap before any model resolution or disk probe.
    //
    // `existing` is the UNTOUCHED config, and that matters more than it looks.
    // An earlier version narrowed it to the user-owned keys on the theory that a
    // re-derivation should discard machine-derived state — but the machine-owned
    // keys are exactly the ones that identify the model this install is ALREADY
    // running, so narrowing them made the "keep the model in use" check below
    // fail every time and sent the bootstrap to the Hub for a model the machine
    // was serving. Read whole, or not at all.
    // This was found by running the real bootstrap on a machine that already had
    // a llama-server up: planPorts saw 8080 busy and moved us to 8081, which
    // means llamacli spawns a SECOND llama-server. On this box that is fatal —
    // the running server already holds 7.2 GB of an 8 GB card, so a second one
    // OOMs on load. And it is pointless: the thing on 8080 is already answering
    // /v1/models with the model we just picked.
    //
    // So detection runs first, and only a genuinely free port leads to a spawn.
    // This is also the same probe config.ts already uses for a project with no
    // config, so "adopt the running server" and "detect a running server" are one
    // mechanism rather than two that can disagree.
    //
    // `discoverRunningServer`, not `detectRunningServer`: a llama-server binds its
    // port before the model finishes loading and answers nothing until the
    // weights are resident. A single fast probe cannot tell that apart from
    // "nothing is running", and answering it wrongly is how this ended up
    // spawning a SECOND llama-server beside a healthy one — which on an 8 GB
    // card is an OOM, not a slowdown. A port that is loading is waited out
    // instead, for as long as a model of the recorded size could plausibly take
    // to load.
    const waitBudget = modelLoadBudgetMs(typeof existing?.model === "string" ? await fileSize(existing.model) : 0);
    const detect = opts.detectServer ??
        ((h, p) => discoverRunningServer(h, p, {
            loadingWaitMs: waitBudget,
            onWait: (port, waited) => log(`${port} 포트 서버가 모델을 불러오는 중입니다 (${Math.round(waited / 1000)}초 경과)…`),
        }));
    const discovery = await detect("127.0.0.1", COMMON_PORTS);
    // ── A port that is held but still loading is NOT ours to take ─────────────
    // The budget ran out while a server was mid-load. Binding a different port
    // here is the exact failure this whole step exists to prevent: the loading
    // server already holds most of the card, and a second one does not fit.
    //
    // So llamacli points at the loading server instead. Its requests will fail
    // until the load finishes, which the agent loop's existing transient-failure
    // retry already handles, and no VRAM is spent on a duplicate.
    if (discovery.kind === "stub") {
        // The canonical port answers the API but has no real weights behind it — a
        // test double (here: harnessCli's `fake-llama-server.mjs`, configured via
        // HARNESSIDE_LLAMA_SERVER) that took port 8080 after the real server was
        // stopped.
        //
        // Two things matter here. First, DO NOT adopt it: every reply would be a
        // canned string, and it looks like a working session until you notice the
        // model never changes its mind. Second, DO NOT bind a different port and
        // spawn a second llama-server for it either — that is the OOM this whole
        // adopt-before-spawn path exists to prevent, and the port is not ours to
        // take. So: report it and let the operator free the port.
        steps.push({ name: "기존 서버 연결", ok: false, detail: discovery.reason });
        errors.push(`기존 서버 연결: ${discovery.reason}`);
        log(discovery.reason);
        steps.push({
            name: "포트 결정",
            ok: false,
            detail: `${discovery.port} 포트가 테스트용 더블 서버에 잡혀 있어 그대로 둡니다 (두 번째 서버를 띄우지 않음).`,
        });
        errors.push(`포트 결정: ${discovery.port} 이 더블 서버에 점유되어 있습니다. 그 서버를 종료하면 기존 llama-server 가 그 포트를 다시 사용할 수 있습니다.`);
        return {
            ok: false,
            steps,
            hardware,
            errors,
            config: existing,
        };
    }
    if (!opts.force && discovery.kind === "loading") {
        const waitedSec = Math.round(discovery.waitedMs / 1000);
        steps.push({
            name: "기존 서버 연결",
            ok: false,
            detail: `${discovery.baseUrl} 에서 서버가 아직 모델을 불러오는 중입니다 (${waitedSec}초 대기). ` +
                `두 번째 서버를 띄우지 않고 이 서버를 사용합니다 — 곧 응답하기 시작합니다.`,
        });
        errors.push(`기존 서버 연결: ${discovery.port} 포트의 서버가 모델 로딩 중입니다 (${waitedSec}초 대기).`);
        log(`${discovery.baseUrl} 서버가 아직 모델을 불러오는 중이라 ${waitedSec}초 기다렸습니다. ` +
            `두 번째 서버를 띄우지 않고 이 서버를 사용합니다.`);
        steps.push({ name: "포트 결정", ok: true, detail: `llama ${discovery.port} (로딩 중인 기존 서버)` });
        const attached = {
            ...(existing ?? {}),
            backend: "openai-compatible",
            baseUrl: discovery.baseUrl,
            // The model id is unknown until the server answers, so the recorded one
            // is kept: config.ts re-reads it live on every load anyway.
            ...(typeof existing?.model === "string" ? {} : { model: "local-model" }),
        };
        if (opts.projectRoot) {
            await step("설정 저장", async () => {
                await writeConfig(opts.projectRoot, attached);
                return ".llamacli/config.yaml (로딩 중인 기존 서버)";
            });
        }
        return {
            ok: false,
            steps,
            hardware,
            llama: llama ?? undefined,
            tuning: undefined,
            ports: { llamaPort: discovery.port },
            config: attached,
            errors,
        };
    }
    if (!opts.force && discovery.kind === "found") {
        const running = discovery.server;
        const adoptedPort = Number(new URL(running.baseUrl).port);
        steps.push({
            name: "기존 서버 연결",
            ok: true,
            detail: `이미 실행 중인 서버를 사용합니다: ${running.baseUrl} (${running.model})`,
        });
        log(`이미 실행 중인 llama-server 에 연결합니다: ${running.baseUrl}`);
        steps.push({ name: "포트 결정", ok: true, detail: `llama ${adoptedPort} (기존 서버)` });
        const adopted = {
            ...(existing ?? {}),
            backend: "openai-compatible",
            baseUrl: running.baseUrl,
            model: running.model,
        };
        if (opts.projectRoot) {
            await writeConfig(opts.projectRoot, adopted);
            steps.push({ name: "설정 저장", ok: true, detail: ".llamacli/config.yaml (기존 서버 연결)" });
        }
        return {
            ok: true,
            steps,
            hardware,
            llama: llama ?? undefined,
            tuning: undefined,
            ports: { llamaPort: adoptedPort },
            config: adopted,
            errors,
        };
    }
    // ── 3. Model ──────────────────────────────────────────────────────────────
    //
    // llamacli searches HuggingFace for a GGUF, picks one that fits this
    // machine's VRAM/RAM, and downloads it — but only after two things that are
    // checked FIRST:
    //
    //   1. an already-running server (above), which ends the bootstrap outright;
    //   2. the model this install is ALREADY using, below.
    //
    const modelsDir = opts.modelsDir ?? env.LLAMACLI_MODELS_DIR ?? defaultModelsDir(env);
    let equivalent = null;
    //
    // (2) exists because the Hub republishes filenames: this box's working model
    // is `Ornith-1.5-35B-A3B-Q4_K_M.gguf` (21,864,081,056 B) while the same
    // quant is published today as `Ornith-1.5-35B-Q4_K_M.gguf` (21,713,463,040)
    // -- different name, different size, same intended model. Resolving from the
    // catalogue first therefore produced a filename matching nothing on disk, and
    // a 20 GB download of weights the machine had been serving all along.
    // Observed twice, ~3h each at this link's speed.
    const configuredPaths = [
        typeof existing?.llama?.modelPath === "string" ? existing.llama.modelPath : undefined,
        typeof existing?.model === "string" ? existing.model : undefined,
    ];
    let alreadyInUse;
    for (const p of configuredPaths) {
        if (p && (await fileSize(p)) > 0) {
            alreadyInUse = p;
            break;
        }
    }
    let model;
    let modelPath = "";
    if (alreadyInUse) {
        const size = await fileSize(alreadyInUse);
        modelPath = alreadyInUse;
        model = {
            candidate: { repo: "(기존 설정)", filename: basename(alreadyInUse), sizeBytes: size, url: "" },
            reason: `이미 사용 중인 모델을 유지합니다: ${alreadyInUse}`,
            alternatives: [],
            // The file's real location, not something to be reconstructed later from
            // a basename — it usually lives outside `modelsDir`.
            localPath: alreadyInUse,
        };
        steps.push({ name: "모델 결정", ok: true, detail: `기존 모델 유지 (다운로드 불필요): ${alreadyInUse}` });
        log(`이미 사용 중인 모델을 유지합니다 — 내려받지 않습니다: ${alreadyInUse}`);
    }
    else if (!opts.offline) {
        const gpu = hardware.gpus[0];
        await step("모델 결정", async () => {
            const { c35, c9, bonsai } = await resolveModel({ env, fetchImpl: opts.fetchImpl, log });
            model = chooseModel({
                vramTotalBytes: gpu?.vramTotalBytes ?? 0,
                vramFreeBytes: gpu?.vramFreeBytes ?? 0,
                ramTotalBytes: hardware.ramTotalBytes,
                candidates35b: c35,
                candidates9b: c9,
                bonsai,
            });
            log(model.reason);
            return model.reason;
        });
    }
    // ── 3.2 The engine, now that the model is known ───────────────────────────
    // Not earlier: see `acquireEngine`. An already-running server ended the bootstrap
    // above, so a machine with a working server never reaches a download or a compile.
    // Runs BESIDE the download below (see the Promise.all). The two are independent — the
    // compatibility check needs only the model's filename — and a first launch otherwise
    // waits for a compile and THEN for a 20 GB transfer. If the engine cannot be had at
    // all the transfer is aborted: its .part file is kept, so the bytes already fetched
    // are not lost when the user fixes the engine and relaunches.
    const needDownload = Boolean(model) && !alreadyInUse && !opts.offline;
    const reportDefault = opts.onProgress ? opts.onProgress(() => renderProgressLine(log)) : renderProgressLine(log);
    engineProgress = needDownload ? undefined : reportDefault;
    const downloadAbort = new AbortController();
    const enginePart = (async () => {
        await acquireEngine(model);
        if (engineFailed && needDownload)
            downloadAbort.abort();
        // ── 3.5 Does the chosen binary plausibly read the chosen model? ────────────
        // The binary is settled in step 2 and the model in step 3, so a fresh install
        // has never seen them together. That gap is not theoretical: this machine has
        // two llama.cpp builds, one of which cannot read the ternary quants the
        // Bonsai ladder prefers, and the model is 5.5 GB. Downloading first and
        // discovering the mismatch at server start costs the whole transfer and then
        // reports a failure that reads like a port problem.
        //
        // What can be checked here is narrower than full compatibility, and is stated
        // as such: the model's own filename carries its quantisation, and the ternary
        // quant names are not stock llama.cpp's at all. So a model that needs a fork
        // can be recognised without the file being on disk. The reverse is not
        // claimed — a normal quant on a fork build passes silently, because proving
        // otherwise would require the file this step exists to avoid needing.
        if (model && llama) {
            // The path to ask about is the path the model will ACTUALLY be read from.
            // `model.candidate.filename` is a basename, so joining it onto `modelsDir`
            // rebuilt a path that usually does not exist: on this machine that produced
            // `/home/jeano/models/Ternary-Bonsai-2-27B-PTQ1_0.gguf` while the model sat
            // at `/media/jeano/nvme-usb/models/bonsai2/…`. The file-presence test in
            // checkBinaryAgainstChosenModel then failed, the exact binary probe never
            // ran, and the filename heuristic reported a build incompatibility that had
            // not been established — "ternary 지원 빌드가 필요합니다" about a build that
            // reads the model fine.
            //
            // `localPath` is set by the "keep existing model" branch and is the only
            // trustworthy locator; the models dir is a guess that applies solely to a
            // model still to be downloaded.
            const probePath = model.localPath ?? join(modelsDir, model.candidate.filename);
            let detail = await checkBinaryAgainstChosenModel(llama.binPath, model.candidate.filename, probePath);
            // ── ACT, not just warn ──────────────────────────────────────────────────
            // This step used to end at "the binary may not read this model", which left
            // the one case that cannot be recovered from by the user doing anything: a
            // FIRST launch on a clean machine. Step 2 picks the binary BEFORE step 3 picks
            // the model, so with no config there was nothing to know a fork was needed and
            // it installed stock llama.cpp — which rejects the Bonsai quant outright. The
            // user was then told to edit `llama.binPath` themselves, having never been told
            // which build would work.
            //
            // So the requirement is now met here rather than described: if the chosen model
            // needs a non-stock quant and the settled binary cannot read it, acquire one
            // that can — the fork's pinned prebuilt, or the fork itself.
            //
            // BEFORE the download, deliberately. A 5.5 GB transfer followed by "invalid
            // ggml type 143" is the failure this ordering exists to prevent, and re-running
            // after the fact means paying for the transfer twice.
            if (detail && needsTernaryBuild(model.candidate.filename)) {
                log(`${model.candidate.filename} 에는 stock llama.cpp 가 읽지 못하는 양자화(${quantSuffixOf(model.candidate.filename)})가 쓰였습니다.`);
                log("PrismML fork 의 llama-server 를 준비합니다 — 먼저 고정 릴리스 바이너리를 받고, 없으면 fork 를 빌드합니다.");
                const got = await step("PrismML llama-server 준비", async () => {
                    const acquired = await (opts.acquireTernary ?? acquireTernaryLlamaServer)({ hardware, run, log });
                    if (!acquired)
                        throw new Error("PrismML llama-server 를 받을 수도, 빌드할 수도 없았습니다.");
                    return acquired.binPath;
                });
                if (got) {
                    llama = { binPath: got, source: "downloaded", backend: hardware.gpuBackend === "none" ? "cpu" : hardware.gpuBackend };
                    steps.push({
                        name: "모델/빌드 호환성",
                        ok: true,
                        detail: `${model.candidate.filename} 을 읽을 수 있는 llama-server 로 교체했습니다: ${got}`,
                    });
                    log(`PrismML llama-server 로 교체했습니다: ${got}`);
                    detail = null;
                }
            }
            if (detail) {
                steps.push({ name: "모델/빌드 호환성", ok: false, detail });
                errors.push(detail);
                log(detail);
                // Only reached when acquiring a capable build did not happen or did not
                // work. Still a warning rather than a hard stop: llamacli cannot read a
                // binary's type registry from outside, and refusing outright would block every
                // user whose build does support the quant.
                log(`선택된 llama-server 빌드가 이 모델을 읽을 수 있는지 아직 확인되지 않았습니다. ` +
                    `다운로드 후에도 실패한다면 llama.binPath 를 ternary/1-bit 를 지원하는 빌드로 바꾸세요.`);
            }
        }
    })();
    const downloadPart = (async () => {
        // ── 4. Download ───────────────────────────────────────────────────────────
        // Disk space is checked BEFORE the transfer, never during it. A download that
        // runs the filesystem out doesn't fail at the start: it fills the disk, and
        // then unrelated things on the machine start failing too. By the time a
        // progress bar is on screen the space is already gone, so this has to be a
        // precondition.
        if (model) {
            const needed = (model.candidate.sizeBytes || 0) + RESERVE_BYTES;
            const target = await selectModelPath({ requestedDir: modelsDir, neededBytes: needed, env });
            if (!hasRoom(target, needed)) {
                steps.push({ name: "모델 다운로드", ok: false, detail: target.reason });
                errors.push(`모델 다운로드: ${target.reason}`);
                log(target.reason);
                log("모델을 다운로드하지 않습니다. 디스크 공간을 확보한 뒤 다시 실행하세요.");
            }
            else {
                if (target.switched) {
                    steps.push({ name: "저장 경로 변경", ok: true, detail: target.reason });
                    log(target.reason);
                }
                const dest = join(target.dir, model.candidate.filename);
                const already = await fileSize(dest);
                if (already > 0 && (model.candidate.sizeBytes === 0 || already >= model.candidate.sizeBytes)) {
                    modelPath = dest;
                    steps.push({ name: "모델 다운로드", ok: true, detail: `이미 있습니다: ${dest}` });
                    log(`모델 이미 있음: ${dest}`);
                }
                else if (alreadyInUse) {
                    // The model decision above found a real file on disk and deliberately
                    // declined to download, so this stage must not be entered at all.
                    //
                    // It used to be: only `dest` (under the models dir) and its equivalent
                    // were considered, so a model kept OUTSIDE that directory — which is the
                    // normal case, since `modelsDir` is only a default — fell through to
                    // `downloadFile` with the placeholder empty URL the "keep existing"
                    // branch assigns. That threw "Failed to parse URL from", the step was
                    // recorded as failed, and `modelPath` was left empty — so the run went
                    // on to start a server against an empty model path and died with
                    // "failed to open GGUF file", turning a working machine into a
                    // three-stage failure.
                    modelPath = alreadyInUse;
                    steps.push({ name: "모델 다운로드", ok: true, detail: `기존 경로에 있어 건너뜁니다: ${alreadyInUse}` });
                    log(`다운로드 단계 없이 기존 모델을 사용합니다: ${alreadyInUse}`);
                }
                else if ((equivalent = await findEquivalentModel(target.dir, model.candidate, opts))) {
                    // The Hub's filename and the filename on disk routinely disagree, so an
                    // existing correct model is reused instead of re-downloading 20 GB of
                    // the same weights.
                    modelPath = equivalent;
                    steps.push({
                        name: "모델 다운로드",
                        ok: true,
                        detail: `동일한 모델이 다른 이름으로 이미 있습니다: ${equivalent}`,
                    });
                    log(`이미 있는 동일 모델을 사용합니다: ${equivalent}`);
                }
                else if (opts.offline) {
                    steps.push({ name: "모델 다운로드", ok: false, detail: "오프라인이라 건너뜁니다." });
                }
                else {
                    await step("모델 다운로드", async () => {
                        await mkdir(dirname(dest), { recursive: true });
                        let result;
                        try {
                            result = await downloadFile(model.candidate.url, dest, {
                                connections: 8,
                                label: model.candidate.filename,
                                fetchImpl: opts.fetchImpl,
                                onProgress: reportDefault,
                                signal: downloadAbort.signal,
                            });
                        }
                        catch (err) {
                            if (downloadAbort.signal.aborted) {
                                throw new Error("llama-server 를 확보하지 못해 다운로드를 중단했습니다. 받은 부분은 보존되어 다시 실행하면 이어받습니다.");
                            }
                            throw err;
                        }
                        return `${result.bytes} 바이트 다운로드 완료 (${result.parallel ? "병렬 range" : "단일 스트림"})`;
                    });
                    modelPath = dest;
                }
            }
        }
    })();
    await Promise.all([enginePart, downloadPart]);
    const plan = await planPorts({
        probe: opts.probe ?? tcpPortProbe,
        llamaPort: typeof existing?.llama?.port === "number" ? existing.llama.port : undefined,
        // The ports discovery already looked at. Passing them keeps the walk-forward
        // from landing on a port where a server was seen doing something — which is
        // how a second llama-server ends up sharing a GPU with the first.
        avoid: COMMON_PORTS,
    });
    steps.push({
        name: "포트 결정",
        ok: true,
        detail: `llama ${plan.llamaPort}` +
            (plan.moved.length > 0 ? ` (변경: ${plan.moved.map((m) => `${m.what} ${m.from}→${m.to}`).join(", ")})` : ""),
    });
    for (const n of plan.notes)
        log(n);
    // ── 5. Tuning + config ────────────────────────────────────────────────────
    // `--n-cpu-moe` is the one flag on this machine that was BENCHMARKED rather
    // than computed, so a value already in the config is passed through instead
    // of being replaced. Every other flag here is derived from hardware on every
    // launch; this one would otherwise be a guess overwriting a measurement, on
    // every single start.
    const configuredCpuMoe = existing?.llama?.cpuMoeLayers;
    const envCpuMoe = Number(env.LLAMACLI_CPU_MOE_LAYERS);
    const measuredCpuMoe = Number.isFinite(envCpuMoe) && envCpuMoe > 0
        ? envCpuMoe
        : typeof configuredCpuMoe === "number" && configuredCpuMoe > 0
            ? configuredCpuMoe
            : undefined;
    // Our own llama-server's VRAM is added back to the budget before the context
    // is sized. This matters because the tuner runs on the path that STARTS a
    // server, but the card is not guaranteed empty — a second llamacli, or any
    // other CUDA process, may already be resident, and nvidia-smi's free-VRAM
    // reading cannot tell those apart from our own weights. Without the
    // add-back, memory we ourselves are holding reads as unavailable headroom and
    // collapses the context. See budgetVramGiB's doc comment for the measured
    // case (an 8 GiB card dropping from 16384 to 4096).
    //
    // Best-effort and additive-only: if the pid can't be attributed (no
    // nvidia-smi, no permission, MIG), this is 0 and the plain free-VRAM reading
    // stands, which is the correct conservative default.
    //
    // When the caller doesn't supply pids, we discover our own rather than
    // leaving the credit permanently unused — attribution is restricted to a
    // binary inside THIS install's build dir (see findOwnLlamaServerPids), so
    // this cannot credit a system llama-server or another user's.
    const serverPids = opts.serverPids ?? (await findOwnLlamaServerPids(llama ? dirname(llama.binPath) : undefined, run));
    const ownServerVramGiB = await ownLlamaServerVramGiB(serverPids, run);
    const tuning = tuneForHardware(hardware, {
        modelBytes: model?.candidate.sizeBytes,
        cpuMoeLayers: measuredCpuMoe,
        ownServerVramGiB,
    });
    for (const r of tuning.rationale)
        log(r);
    const config = buildConfig({ existing, llama, modelPath, plan, tuning });
    if (opts.projectRoot) {
        // Wrapped like every other step, because until now this was the ONE call
        // that could throw straight out of the function — which contradicted the
        // module's own contract ("a bootstrap that throws takes down a working
        // install; a bootstrap that returns a report lets the caller start anyway").
        //
        // Found by a project-axis sweep (100 project states): a read-only project
        // directory made `mkdir .llamacli` fail with EACCES and the whole bootstrap
        // rejected. That is a real and reachable state — a project on a read-only
        // mount, a checkout owned by another user, a container running as a
        // non-owner — and the user saw a crash instead of a report.
        //
        // Losing the write is genuinely bad (the run is not persisted), so it is
        // recorded as a FAILED step and pushes an error, rather than being
        // swallowed. The caller still gets a usable report and can start the
        // session with the settings it derived.
        await step("설정 저장", async () => {
            await writeConfig(opts.projectRoot, config);
            return ".llamacli/config.yaml";
        });
    }
    // NOTE: the config is written AFTER the download above. That ordering was
    // called out as a limitation and is deliberately left in place now that the
    // plan above already refuses to start a download it cannot finish: recording
    // a `modelPath` for a file that does not exist would make the next launch skip
    // the download (the size check sees a complete file) and then fail to load a
    // missing model. Writing early would trade a harmless extra Hub search on
    // relaunch for a config that lies.
    return {
        ok: errors.length === 0 && Boolean(llama),
        steps,
        hardware,
        llama: llama ?? undefined,
        model,
        modelPath: modelPath || undefined,
        tuning,
        ports: { llamaPort: plan.llamaPort },
        config,
        errors,
    };
}
/** Top-level config blocks whose feature was removed from llamacli. Kept as
 *  data so the removal is a single list a re-introduction has to delete from,
 *  rather than a `delete` scattered through the merge path. */
export const REMOVED_CONFIG_BLOCKS = ["laya"];
/** Turns the report into a config object.
 *
 *  Existing keys are PRESERVED and merged, never replaced wholesale. The
 *  bootstrap runs on every launch, so a config that a user has hand-tuned
 *  (apiKey, verify commands, browser settings) must survive it. Only the fields
 *  the bootstrap owns are written, and only when it actually determined them. */
/** The `llama.*` keys a tuning produces.
 *
 *  Shared rather than written twice because two writers exist — the bootstrap
 *  and the `/models` switch — and a key added to one and forgotten in the other
 *  does not fail loudly: the config simply keeps the previous model's value for
 *  it, so the replacement server silently launches with flags sized for a
 *  model that is no longer loaded. */
export function tuningToConfigKeys(tuning) {
    return {
        contextSize: tuning.contextSize,
        threads: tuning.threads,
        threadsBatch: tuning.threadsBatch,
        gpuLayers: tuning.gpuLayers,
        cpuMoeLayers: tuning.cpuMoeLayers,
        batchSize: tuning.batchSize,
        ubatchSize: tuning.ubatchSize,
        parallel: tuning.parallel,
        flashAttn: tuning.flashAttn,
        cacheTypeK: tuning.cacheTypeK,
        cacheTypeV: tuning.cacheTypeV,
    };
}
export function buildConfig(opts) {
    const base = opts.existing ?? {};
    const next = { ...base };
    // Config blocks belonging to features that no longer exist are DROPPED, not
    // merged forward. `laya` configured the deleted System-1 gate; carrying the
    // block forward would keep advertising a setting that nothing reads, and a
    // reader debugging a config would reasonably conclude it still did something.
    //
    // This is explicit rather than a general "strip unknown keys" rule: an
    // unknown key is far more likely to be a setting a NEWER llamacli wrote than
    // garbage, and deleting it on every launch would be its own data loss.
    for (const removed of REMOVED_CONFIG_BLOCKS) {
        if (removed in next)
            delete next[removed];
    }
    if (opts.llama) {
        // backend flips to local-llama ONLY when we have both a binary and a model.
        // Claiming a local backend with no modelPath is exactly the state index.tsx
        // treats as "not configured" and would silently fall through to a dead URL.
        if (opts.modelPath)
            next.backend = "local-llama";
        next.llama = {
            ...(base.llama ?? {}),
            binPath: opts.llama.binPath,
            ...(opts.modelPath ? { modelPath: opts.modelPath } : {}),
            port: opts.plan.llamaPort,
            ...tuningToConfigKeys(opts.tuning),
        };
    }
    return next;
}
async function readConfig(projectRoot) {
    try {
        return parse(await readFile(join(projectRoot, ".llamacli", "config.yaml"), "utf8")) ?? undefined;
    }
    catch {
        return undefined; // no config yet, or unreadable — both mean "start fresh"
    }
}
/** The config keys a HUMAN owns, as opposed to the ones the machine derives.
 *
 *  `llama.*`, `model`, `backend` and `baseUrl` are all machine-derived: they
 *  describe what this box is currently running. Everything named here is a
 *  human decision — a key they typed, a verification command they wrote — and
 *  the bootstrap must never be the thing that discards it.
 *
 *  This used to exist to serve `/reset`, which is gone. It is kept because
 *  `buildConfig` merges rather than replaces, and this is the list of what
 *  "merges" is protecting; the persona harness asserts the separation is real
 *  by checking a removed feature's block does not survive a merge. */
export function keepUserOwnedKeys(config) {
    if (!config)
        return config;
    const kept = {};
    if (config.apiKey)
        kept.apiKey = config.apiKey;
    if (config.verify !== undefined)
        kept.verify = config.verify;
    if (config.browser !== undefined)
        kept.browser = config.browser;
    if (config.checkpoint !== undefined)
        kept.checkpoint = config.checkpoint;
    if (config.enableThinking !== undefined)
        kept.enableThinking = config.enableThinking;
    if (config.repeatPenalty !== undefined)
        kept.repeatPenalty = config.repeatPenalty;
    if (config.compaction?.autoTriggerRatio !== undefined) {
        kept.compaction = {
            autoTriggerRatio: config.compaction.autoTriggerRatio,
            ...(config.compaction.autoResume !== undefined ? { autoResume: config.compaction.autoResume } : {}),
            ...(config.compaction.summaryMaxTokens !== undefined
                ? { summaryMaxTokens: config.compaction.summaryMaxTokens }
                : {}),
        };
    }
    return kept;
}
/** Written to a temp file and renamed, so a crash mid-write cannot leave a
 *  half-written config that the next launch fails to parse. */
export async function writeConfig(projectRoot, config) {
    const dir = join(projectRoot, ".llamacli");
    await mkdir(dir, { recursive: true });
    const final = join(dir, "config.yaml");
    const tmp = `${final}.tmp`;
    await writeFile(tmp, stringify(config), "utf8");
    await rename(tmp, final);
}
async function fileSize(path) {
    const { stat } = await import("node:fs/promises");
    try {
        return (await stat(path)).size;
    }
    catch {
        return 0;
    }
}
/** The quant token in a GGUF filename, e.g. "Q4_K_M" out of
 *  "Ornith-1.5-35B-A3B-Q4_K_M.gguf". */
export function quantOf(filename) {
    return /Q\d(_[A-Z0-9]+)+/i.exec(filename)?.[0]?.toUpperCase() ?? "";
}
/**
 * Looks for a file in `dir` that is the SAME MODEL under a different name.
 *
 * Matching is on the quant plus the exact byte size, never on the filename: the
 * two disagree constantly (Hub says `Ornith-1.5-35B-Q4_K_M.gguf`, the copy on
 * disk is `Ornith-1.5-35B-A3B-Q4_K_M.gguf`), and a name-based guess would be a
 * guess. An exact size match on the same quant IS the same file as far as
 * loading is concerned, and it is the only thing that stops a fresh install
 * re-downloading 20 GB the machine already has.
 */
export async function findEquivalentModel(dir, candidate, opts = {}) {
    if (!candidate.sizeBytes)
        return null;
    const wantQuant = quantOf(candidate.filename);
    if (!wantQuant)
        return null;
    const list = opts.listExistingModels ?? listGgufsIn;
    let files;
    try {
        files = await list(dir);
    }
    catch {
        return null;
    }
    for (const f of files) {
        const base = f.path.split("/").pop() ?? f.path;
        if (base === candidate.filename)
            continue;
        if (f.sizeBytes !== candidate.sizeBytes)
            continue;
        if (quantOf(base) !== wantQuant)
            continue;
        return f.path;
    }
    return null;
}
async function listGgufsIn(dir) {
    const { readdir, stat } = await import("node:fs/promises");
    let entries;
    try {
        entries = await readdir(dir);
    }
    catch {
        return [];
    }
    const out = [];
    for (const name of entries) {
        if (!name.toLowerCase().endsWith(".gguf"))
            continue;
        const path = join(dir, name);
        try {
            out.push({ path, sizeBytes: (await stat(path)).size });
        }
        catch {
            continue;
        }
    }
    return out;
}
/** A progress reporter for a long download.
 *
 *  Rewrites ONE terminal line rather than appending, because a 22 GB download
 *  at 4 updates/second would otherwise bury everything above it in thousands of
 *  lines. Falls back to periodic lines when the output is not a TTY, so a
 *  redirected log gets a readable record instead of one overwritten line.
 *
 *  Two things were wrong with the interactive branch, both visible in a real
 *  capture of a first run:
 *
 *  1. `\r[2K` was missing its ESC byte. The erase-line control sequence is
 *     `\x1b[2K`, so what actually reached the terminal was a carriage return
 *     followed by the literal characters `[2K` — visible garbage at the start
 *     of every update. Confirmed by driving this reporter directly: the bytes
 *     written were `"\r[2K[████..."`, and a whole download painted the line with
 *     `[2K` smeared across it.
 *  2. It wrote to `process.stdout` directly instead of going through `log`. That
 *     bypasses the caller's sink entirely, which is exactly why a TUI passing
 *     its own reporter had to wrap this one (see `onProgress`'s doc comment) —
 *     and why the bootstrap's own progress could never be routed anywhere else.
 *     Writing through `log` also means the line is suppressible on a terminal
 *     that cannot interpret escapes, instead of smearing control bytes over
 *     whatever is on screen.
 */
export function renderProgressLine(log) {
    const interactive = Boolean(process.stdout.isTTY);
    // Last logged decile. `floor(percent) % 10 === 0` is true for EVERY update
    // while the download is still under 10% done, so a real 20 GB fetch emitted a
    // line about four times a second for its first several minutes and buried
    // everything above it.
    let lastDecile = -1;
    // Carriage return + erase-line + cursor-to-column-1, or nothing at all when
    // the sink cannot take escapes (a non-ANSI terminal would print these
    // literally). Written through `log` so it honours that decision instead of
    // assuming stdout is a capable terminal.
    const canRewrite = interactive && supportsAnsiOutput();
    let first = true;
    return (p) => {
        if (canRewrite) {
            // The leading `\r` on the first update would blank a line of scrollback
            // the user has not read yet; later updates genuinely need it to rewrite
            // in place.
            log(`${first ? "" : "\r\x1b[2K"}${formatProgress(p)}`);
            first = false;
            return;
        }
        const decile = p.percent < 0 ? -1 : Math.floor(p.percent / 10);
        if (decile > lastDecile || p.percent >= 100) {
            lastDecile = decile;
            log(formatProgress(p));
        }
    };
}
/** Whether escape sequences can be written to the process's own stdout.
 *
 *  Deliberately narrower than the full TUI capability report: a redirected
 *  stdout is not a terminal, and a terminal that cannot interpret escapes would
 *  print `\x1b[2K` as text. Reuses the TUI's own verdict so this and the
 *  renderer can never disagree — terminal.ts pulls in chalk and nothing from
 *  React, so importing it here costs no dependency the setup path was avoiding. */
function supportsAnsiOutput() {
    if (!process.stdout.isTTY)
        return false;
    return getCapabilities().ansi;
}
/**
 * Quant names that exist only in a llama.cpp fork, measured rather than guessed.
 *
 * Diffing `llama-quantize`'s supported list between the two builds on this
 * machine gives exactly two: `PQ2_0` and `PTQ1_0`. Everything else — `Q1_0`,
 * `Q2_0`, `Q4_K_M`, the IQ and MXFP families, `TQ*` — is shared, so none of it
 * may be treated as evidence of anything.
 *
 * That measurement is also why the match is anchored to the quant SUFFIX. An
 * earlier version of this matched the substring `Ternary` anywhere in the
 * filename, which flagged `Ternary-Bonsai-4B-Q2_0.gguf` as needing a fork —
 * a false positive produced by the model FAMILY name, on a quant every
 * llama.cpp build reads. Telling a user their build is wrong when it is not is
 * worse than saying nothing.
 */
const NON_STOCK_QUANT_SUFFIXES = new Set(["PTQ1_0", "PQ2_0"]);
/** The quantisation token of a model filename.
 *
 *  `Ternary-Bonsai-2-27B-PTQ1_0.gguf` → `PTQ1_0`.
 *
 *  Two details that are both wrong without saying so:
 *
 *  - The character class excludes `-`, so the match starts at the LAST dash.
 *    Leaving it in makes the pattern greedy from the first dash and yields
 *    `BONSAI-2-27B-PTQ1_0`, which is in no quant set and silently reports every
 *    model as stock-compatible.
 *  - A `-00001-of-00002` shard tag is stripped first. Otherwise a sharded
 *    ternary model reads as quant `00002` and produces a false negative — the
 *    one direction that lets a doomed download start. */
export function quantSuffixOf(modelFilename) {
    const withoutShard = modelFilename.replace(/-\d{5}-of-\d{5}(?=\.(?:gguf|safetensors)$)/i, "");
    const match = /-([^-/\\]+)\.(?:gguf|safetensors)$/i.exec(withoutShard);
    return match ? match[1].toUpperCase() : "";
}
/** Whether this model requires a llama.cpp build with fork-only quant support. */
export function needsTernaryBuild(modelFilename) {
    return NON_STOCK_QUANT_SUFFIXES.has(quantSuffixOf(modelFilename));
}
/**
 * The pre-download compatibility check for step 3.5. Returns a message when
 * there is something to say, null when there is not.
 *
 * Two levels of evidence, strongest first:
 *
 *  1. The model file is already on disk — then the binary is actually asked, and
 *     the answer is exact. This is the common case for anyone who has run
 *     llamacli before and is merely re-resolving.
 *  2. The file is not there yet — then only the filename's quant is available,
 *     which proves a fork is REQUIRED but says nothing about whether the
 *     selected build happens to be one.
 *
 * Level 2 never claims incompatibility it has not established. It names the
 * requirement and leaves the verdict open, because "this will fail" from a
 * filename guess would be wrong for every user whose build does support it.
 */
export async function checkBinaryAgainstChosenModel(binPath, modelFilename, existingModelPath, opts = {}) {
    if ((await fileSize(existingModelPath)) > 0) {
        const compat = await (opts.probeModel ?? probeModelCompatibility)(binPath, existingModelPath);
        if (!compat.ok && looksLikeUnsupportedModelFormat(compat.error)) {
            const line = (compat.error ?? "").split("\n").find((l) => /invalid ggml type/i.test(l))?.trim() ??
                "형식 미지원";
            return `${basename(binPath)} 는 ${modelFilename} 의 양자화 형식을 읽지 못합니다: ${line}`;
        }
        // Readable, or failing for a reason that is not the binary's type registry.
        // Either way there is nothing to warn about before downloading.
        return null;
    }
    if (needsTernaryBuild(modelFilename)) {
        return (`${modelFilename} 는 ternary(3값) 양자화입니다. 이 형식은 stock llama.cpp 가 읽지 못하며 ` +
            `ternary 지원 빌드(PrismML 계열 등)가 필요합니다 — 현재 선택된 빌드는 ${basename(binPath)} 입니다.`);
    }
    return null;
}
