import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { AgentLoop, summarizeErrorForDisplay, setCompactionRetryBackoffMsForTests } from "./loop.js";
import { readCheckpoint, writeCheckpoint } from "../compaction/checkpoint.js";
async function withTempProject(fn) {
    const dir = await mkdtemp(join(tmpdir(), "llamacli-test-"));
    try {
        await fn(dir);
    }
    finally {
        await rm(dir, { recursive: true, force: true });
    }
}
/** A backend whose /chat behavior is scripted by call count, distinguishing
 *  the main agent turn (called with `tools`) from compactor.ts's internal
 *  summary request (called without `tools`). `tokenize` is scripted
 *  separately so context-usage thresholds can be hit deterministically
 *  without depending on real message content length. */
function scriptedBackend(opts) {
    let turnIndex = 0;
    let tokenizeIndex = 0;
    const turnRequests = [];
    const summaryRequests = [];
    const backend = {
        async chat(req, onDelta, chatOpts) {
            if (!req.tools) {
                // compactor.ts's internal "summarize the old turns" request
                summaryRequests.push(chatOpts?.deadlineMs ?? -1);
                for (const piece of (opts.summaryText ?? "summary").split(" ")) {
                    onDelta?.({ choices: [{ delta: { content: piece + " " }, finish_reason: null }] });
                }
                return {
                    choices: [{ message: { role: "assistant", content: opts.summaryText ?? "summary" }, finish_reason: "stop" }],
                };
            }
            turnRequests.push(req);
            const res = opts.turnResponses[turnIndex];
            turnIndex++;
            if (!res)
                throw new Error(`scriptedBackend: no turn response scripted for call ${turnIndex}`);
            // Fire one synthetic delta mirroring the scripted response, so tests
            // exercising streaming-driven behavior (onAssistantDelta,
            // onReasoningDelta, onTurnStart — see loop.ts's maybeFireTurnStart)
            // see it, same as the real backend would via at least one chunk.
            const message = res.choices[0]?.message;
            if (onDelta && message) {
                onDelta({ choices: [{ delta: { content: message.content, tool_calls: message.tool_calls }, finish_reason: null }] });
            }
            return res;
        },
        async listModels() {
            return ["fake-model"];
        },
        async tokenize() {
            const count = opts.tokenCounts[tokenizeIndex] ?? opts.tokenCounts[opts.tokenCounts.length - 1];
            tokenizeIndex++;
            return count;
        },
    };
    return { backend, turnRequests, summaryRequests };
}
function assistantMessage(content, tool_calls) {
    return {
        choices: [
            {
                message: { role: "assistant", content, ...(tool_calls ? { tool_calls } : {}) },
                finish_reason: tool_calls ? "tool_calls" : "stop",
            },
        ],
    };
}
test("AgentLoop.send() reports context usage on every measurement", () => withTempProject(async (dir) => {
    const { backend } = scriptedBackend({
        turnResponses: [assistantMessage("done")],
        tokenCounts: [3],
    });
    const usageCalls = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 100 },
        onContextUsage: (used, total) => usageCalls.push([used, total]),
    });
    await loop.send("hi");
    assert.deepEqual(usageCalls, [[3, 100]]);
}));
test("AgentLoop captures pendingToolCall when compaction fires mid-batch, and abandons the rest of that batch", () => withTempProject(async (dir) => {
    const call1 = {
        id: "c1",
        type: "function",
        function: { name: "update_plan", arguments: JSON.stringify({ steps: [{ description: "step1", status: "in_progress" }] }) },
    };
    const call2 = {
        id: "c2",
        type: "function",
        function: { name: "update_plan", arguments: JSON.stringify({ steps: [{ description: "step2", status: "in_progress" }] }) },
    };
    const { backend } = scriptedBackend({
        turnResponses: [assistantMessage(null, [call1, call2])],
        // 1: top-of-loop check (before the turn) -> low, no compact
        // 2: before call1 -> low, no compact, call1 runs
        // 3: before call2 -> high, compacts and abandons call2
        tokenCounts: [1, 1, 1000],
    });
    const statusMessages = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.5, contextWindowTokens: 100 },
        onStatus: (s) => statusMessages.push(s),
        // This test is specifically about the checkpoint left behind for
        // manual resume (the next test covers the default autoResume: true
        // path, which would otherwise fold the resume context back in and
        // keep going within this same send() instead of stopping here).
        autoResume: false,
    });
    await loop.send("do the thing");
    assert.ok(statusMessages.some((s) => s.includes("compaction complete")));
    // A plain-language heads-up the moment compaction STARTS — requested
    // directly: "컴팩션을 수행하는 경우 출력창에 친절하게 ... 안내가
    // 되면 좋겠어" — must come before the "complete" line, not after.
    const startIdx = statusMessages.findIndex((s) => s.includes("메모리 공간을 확보합니다"));
    const completeIdx = statusMessages.findIndex((s) => s.includes("compaction complete"));
    assert.ok(startIdx !== -1, "expected the friendly compaction-starting message");
    assert.ok(startIdx < completeIdx, "the starting message must come before the completion message");
    // A mid-batch abandonment must say the turn is over — otherwise it's
    // indistinguishable from the CLI having hung (reported directly: "진행
    // 중인지 멈춘건지 모르겠네" / "can't tell if this is still running").
    assert.ok(statusMessages.some((s) => s.includes("[turn ended]")));
    const checkpoint = await readCheckpoint(dir);
    assert.ok(checkpoint, "expected a checkpoint to have been written");
    assert.deepEqual(checkpoint.pendingToolCall, {
        name: "update_plan",
        argumentsJson: call2.function.arguments,
        reason: "compaction threshold hit before this call could run",
    });
    // call1 ran (plan has step1) but call2 never did (no step2 in the plan)
    assert.equal(checkpoint.steps.length, 1);
    assert.equal(checkpoint.steps[0].description, "step1");
}));
test("a checkpoint left by mid-session compaction is picked up automatically by the NEXT send(), not just on process restart", () => withTempProject(async (dir) => {
    const call1 = {
        id: "c1",
        type: "function",
        function: { name: "update_plan", arguments: JSON.stringify({ steps: [{ description: "step1", status: "in_progress" }] }) },
    };
    const call2 = {
        id: "c2",
        type: "function",
        function: { name: "update_plan", arguments: JSON.stringify({ steps: [{ description: "step2", status: "in_progress" }] }) },
    };
    const { backend, turnRequests } = scriptedBackend({
        turnResponses: [
            assistantMessage(null, [call1, call2]), // first send(): abandoned mid-batch by compaction
            assistantMessage("continuing now"), // second send(): should see the resume context first
        ],
        tokenCounts: [1, 1, 1000, 1], // 4th measurement (start of 2nd send's turn) stays low, no further compaction
    });
    const statusMessages = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.5, contextWindowTokens: 100 },
        onStatus: (s) => statusMessages.push(s),
        // Exercising the manual-resume path on purpose (see previous test);
        // autoResume: true is covered by its own test below.
        autoResume: false,
    });
    await loop.send("do the thing"); // leaves a checkpoint behind (see previous test)
    assert.ok(await readCheckpoint(dir), "expected a checkpoint after the first send()");
    statusMessages.length = 0;
    await loop.send("are you still there?");
    // the resume prompt must have been folded in automatically, with no
    // separate resumeIfCheckpointExists() call needed
    assert.ok(statusMessages.some((s) => s.includes("resuming after compaction")));
    assert.equal(await readCheckpoint(dir), null, "checkpoint should be consumed after being resumed");
    // and the model's second request must actually contain that resume
    // context (the interrupted tool call), not just a bare "are you still
    // there?" — buildResumePrompt() reports the pending call's name/reason,
    // not its raw arguments, so check for that rather than "step2".
    const secondRequest = turnRequests[1];
    assert.ok(secondRequest.messages.some((m) => typeof m.content === "string" && m.content.includes("update_plan")));
}));
test("with the default autoResume: true, a compaction that interrupts a tool call resumes within the SAME send() — no second send() needed", () => withTempProject(async (dir) => {
    const call1 = {
        id: "c1",
        type: "function",
        function: { name: "update_plan", arguments: JSON.stringify({ steps: [{ description: "step1", status: "in_progress" }] }) },
    };
    const call2 = {
        id: "c2",
        type: "function",
        function: { name: "update_plan", arguments: JSON.stringify({ steps: [{ description: "step2", status: "in_progress" }] }) },
    };
    const { backend, turnRequests } = scriptedBackend({
        turnResponses: [
            assistantMessage(null, [call1, call2]), // abandoned mid-batch by compaction
            assistantMessage("continuing now"), // picked up automatically, same send()
        ],
        // 1: top-of-loop -> low, 2: before call1 -> low, call1 runs,
        // 3: before call2 -> high, compacts + abandons call2,
        // 4: top-of-loop after auto-resume -> low, no further compaction.
        tokenCounts: [1, 1, 1000, 1],
    });
    const statusMessages = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.5, contextWindowTokens: 100 },
        onStatus: (s) => statusMessages.push(s),
        // autoResume left unset on purpose: exercises the actual default.
    });
    await loop.send("do the thing");
    // Never stopped and waited — no "[turn ended]" status, and the second
    // scripted turn response was consumed within this single send() call.
    assert.ok(!statusMessages.some((s) => s.includes("[turn ended]")));
    assert.equal(turnRequests.length, 2, "expected the resumed turn to have run within the same send()");
    assert.ok(statusMessages.some((s) => s.includes("resuming automatically")));
    // The checkpoint must be consumed (not left for a later manual resume)
    // once it's been folded back in automatically.
    assert.equal(await readCheckpoint(dir), null, "checkpoint should be consumed after auto-resuming");
    // And the resumed request must actually carry the interrupted call's
    // context forward, same as the manual-resume path above.
    const secondRequest = turnRequests[1];
    assert.ok(secondRequest.messages.some((m) => typeof m.content === "string" && m.content.includes("update_plan")));
}));
test("onToolCallDone fires once per tool call, after onToolCall, for every tool (not just run_shell)", () => withTempProject(async (dir) => {
    await writeFile(join(dir, "f.txt"), "file content", "utf8");
    const readCall = {
        id: "c1",
        type: "function",
        function: { name: "read_file", arguments: JSON.stringify({ path: "f.txt" }) },
    };
    const shellCall = {
        id: "c2",
        type: "function",
        function: { name: "run_shell", arguments: JSON.stringify({ command: "echo x" }) },
    };
    const { backend } = scriptedBackend({
        turnResponses: [assistantMessage(null, [readCall, shellCall]), assistantMessage("done")],
        tokenCounts: [1],
    });
    const events = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 24576 },
        onToolCall: (name) => events.push(`call:${name}`),
        onToolCallDone: (name) => events.push(`done:${name}`),
    });
    await loop.send("go");
    assert.deepEqual(events, ["call:read_file", "done:read_file", "call:run_shell", "done:run_shell"]);
}));
test("onToolResult fires with a run_shell command's real output, and only for run_shell (not other tools)", () => withTempProject(async (dir) => {
    await writeFile(join(dir, "f.txt"), "file content", "utf8");
    const shellCall = {
        id: "c1",
        type: "function",
        function: { name: "run_shell", arguments: JSON.stringify({ command: "echo hello-from-test" }) },
    };
    const readCall = {
        id: "c2",
        type: "function",
        function: { name: "read_file", arguments: JSON.stringify({ path: "f.txt" }) },
    };
    const { backend } = scriptedBackend({
        turnResponses: [assistantMessage(null, [shellCall, readCall]), assistantMessage("done")],
        tokenCounts: [1],
    });
    const toolResults = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 24576 },
        onToolResult: (command, output) => toolResults.push({ command, output }),
    });
    await loop.send("run it");
    assert.equal(toolResults.length, 1, "expected exactly one onToolResult call, for run_shell only");
    assert.match(toolResults[0].command, /echo/);
    assert.match(toolResults[0].output, /hello-from-test/);
}));
test("a turn that ends on plain text with no tool call announces it's done, instead of just going quiet", () => withTempProject(async (dir) => {
    const { backend } = scriptedBackend({
        turnResponses: [assistantMessage("here is my analysis, all done")],
        tokenCounts: [1],
    });
    const statusMessages = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.5, contextWindowTokens: 100 },
        onStatus: (s) => statusMessages.push(s),
    });
    await loop.send("do the thing");
    // Reported live: a long plain-text reply with no follow-up tool call
    // left the screen looking identical to a hang, with nothing marking
    // the turn as actually finished.
    assert.ok(statusMessages.some((s) => s.includes("done") && s.includes("waiting")));
}));
test("AgentLoop does not trigger compaction when usage stays under the threshold throughout", () => withTempProject(async (dir) => {
    const call1 = {
        id: "c1",
        type: "function",
        function: { name: "update_plan", arguments: JSON.stringify({ steps: [{ description: "step1", status: "done" }] }) },
    };
    const { backend } = scriptedBackend({
        turnResponses: [assistantMessage(null, [call1]), assistantMessage("all done")],
        tokenCounts: [1],
    });
    const statusMessages = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 100 },
        onStatus: (s) => statusMessages.push(s),
    });
    await loop.send("do the thing");
    assert.ok(!statusMessages.some((s) => s.includes("compaction")));
    assert.equal(await readCheckpoint(dir), null);
}));
test("resumeIfCheckpointExists automatically continues the turn (no user input) and clears the checkpoint first", () => withTempProject(async (dir) => {
    await writeCheckpoint(dir, {
        version: 1,
        timestamp: "2026-01-01T00:00:00.000Z",
        reason: "auto-threshold",
        goal: "Add dark mode",
        steps: [{ description: "Wire up toggle", status: "in_progress" }],
        files: [],
        pendingToolCall: null,
        mustPreserve: [],
    });
    const { backend, turnRequests } = scriptedBackend({
        turnResponses: [assistantMessage("continuing the work now")],
        tokenCounts: [1],
    });
    const statusMessages = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 100 },
        onStatus: (s) => statusMessages.push(s),
    });
    await loop.resumeIfCheckpointExists();
    // it must have actually driven a turn, not just injected a message and stopped
    assert.equal(turnRequests.length, 1);
    assert.ok(statusMessages.some((s) => s.includes("Add dark mode")));
    // consumed, so a later crash/restart doesn't replay the same resume forever
    assert.equal(await readCheckpoint(dir), null);
}));
test("resumeIfCheckpointExists is a no-op when there's no checkpoint", () => withTempProject(async (dir) => {
    const { backend, turnRequests } = scriptedBackend({ turnResponses: [], tokenCounts: [1] });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 100 },
    });
    await loop.resumeIfCheckpointExists();
    assert.equal(turnRequests.length, 0);
}));
// Reproduces the crash seen when running llamacli in a directory with no
// .llamacli/config.yaml: it falls back to a default backend URL nothing is
// listening on, and the resulting ECONNREFUSED must never crash the whole
// CLI — it should surface as a status message and end the turn gracefully.
test("send() does not throw when the backend is unreachable — reports a status message instead", () => withTempProject(async (dir) => {
    const backend = {
        async chat() {
            const err = new Error("request to http://127.0.0.1:8081/v1/chat/completions failed, reason: connect ECONNREFUSED 127.0.0.1:8081");
            err.code = "ECONNREFUSED";
            throw err;
        },
        async listModels() {
            return [];
        },
    };
    const statusMessages = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 100 },
        onStatus: (s) => statusMessages.push(s),
    });
    // must resolve, not reject — this is the whole point of the fix
    await assert.doesNotReject(() => loop.send("hello"));
    assert.ok(statusMessages.some((s) => s.includes("ECONNREFUSED")));
}));
test("compaction summary failure doesn't crash the loop — reports a status message and keeps the (uncompacted) context", () => withTempProject(async (dir) => {
    const call1 = {
        id: "c1",
        type: "function",
        function: {
            name: "update_plan",
            arguments: JSON.stringify({ steps: [{ description: "step1", status: "in_progress" }] }),
        },
    };
    let summaryAttempted = false;
    const backend = {
        async chat(req) {
            if (!req.tools) {
                summaryAttempted = true;
                throw new Error("connect ECONNREFUSED (summary request)");
            }
            return {
                choices: [{ message: { role: "assistant", content: null, tool_calls: [call1] }, finish_reason: "tool_calls" }],
            };
        },
        async listModels() {
            return [];
        },
        async tokenize() {
            return 1000; // always over threshold, forces compaction on the very first check
        },
    };
    const statusMessages = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.5, contextWindowTokens: 100 },
        onStatus: (s) => statusMessages.push(s),
    });
    await assert.doesNotReject(() => loop.send("hello"));
    assert.ok(summaryAttempted);
    assert.ok(statusMessages.some((s) => s.includes("compaction failed")));
    // the checkpoint must still have been written even though the summary failed
    assert.ok(await readCheckpoint(dir));
}));
test("every chat request sent to the backend caps max_tokens instead of leaving it unbounded", () => withTempProject(async (dir) => {
    // Found live via the real backend's GET /slots: a request with no
    // max_tokens set (llama-server default -1, unbounded) generated past
    // 22k tokens with no end in sight, pinning the single inference slot.
    const { backend, turnRequests } = scriptedBackend({
        turnResponses: [assistantMessage("done")],
        tokenCounts: [1],
    });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 8000 },
    });
    await loop.send("hello");
    assert.equal(turnRequests.length, 1);
    // computeMaxTokens: available = 8000 - 1(used) - 2048(margin) = 5951,
    // ceiling = 8000*0.75 = 6000 -> min(5951, 6000) = 5951.
    assert.equal(turnRequests[0].max_tokens, 5951);
}));
// Reported live: a request with only 6,400 tokens of real history (9,984
// tokens of genuinely free room in a 16,384-token window) still got capped
// at a flat 25%-of-window 4,096, truncating a write_file tool call's
// arguments — a long generated document — mid-JSON-string. The server's
// grammar-constrained tool-call parser then rejected the resulting
// unterminated string as invalid JSON (500 "missing closing quote"),
// which looked like the whole turn had silently stopped. max_tokens must
// scale with the room actually left, not a flat fraction of the window.
test("max_tokens gives a small conversation real headroom instead of a flat fraction of the window", () => withTempProject(async (dir) => {
    const { backend, turnRequests } = scriptedBackend({
        turnResponses: [assistantMessage("done")],
        tokenCounts: [6400], // matches the real incident's conversation size
    });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 16384 },
    });
    await loop.send("hello");
    // available = 16384 - 6400 - 2048(margin) = 7936; ceiling = 16384*0.75
    // = 12288 -> min(7936, 12288) = 7936. The old flat formula would have
    // given 4096 here — nearly double what this fix provides, which is
    // exactly the gap that truncated the real tool call.
    assert.equal(turnRequests[0].max_tokens, 7936);
    assert.ok(turnRequests[0].max_tokens > 4096, "expected more headroom than the old flat 25% formula would have given");
}));
// Reported live (a second, distinct incident from the one above): a real
// request's prompt ALONE — per the server's own token count — came in
// ~1,200 tokens larger than what estimateTokens() had told computeMaxTokens()
// the conversation was. With the old 256-token margin, max_tokens (set
// generously, since the underestimate made room look more plentiful than
// it really was) plus the now-underestimated prompt together summed past
// the real context window — the server hard-truncated at exactly 16,384
// tokens (`truncated=1`) independent of max_tokens entirely (the
// generation itself, 2,504 tokens, was genuinely under its own cap).
// Simulates that same estimate-vs-real gap and checks the wider margin
// leaves enough slack to keep prompt+reply under the window.
test("max_tokens leaves enough margin to absorb a real gap between estimateTokens() and the backend's own tokenizer", () => withTempProject(async (dir) => {
    const REAL_PROMPT_TOKENS = 13_880; // what the server actually counted, live
    const ESTIMATE_GAP = 1_200; // how far short estimateTokens() fell of that, live
    const WINDOW = 16_384;
    const { backend, turnRequests } = scriptedBackend({
        turnResponses: [assistantMessage("done")],
        tokenCounts: [REAL_PROMPT_TOKENS - ESTIMATE_GAP], // the client's (under)estimate
    });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: WINDOW },
    });
    await loop.send("hello");
    const maxTokens = turnRequests[0].max_tokens;
    // The real-world failure mode: REAL_PROMPT_TOKENS + maxTokens ended up
    // at/over WINDOW. This must leave real slack even against the observed
    // gap, not just barely clear it.
    assert.ok(REAL_PROMPT_TOKENS + maxTokens < WINDOW, `expected prompt(${REAL_PROMPT_TOKENS}) + max_tokens(${maxTokens}) to stay under the window(${WINDOW}), got ${REAL_PROMPT_TOKENS + maxTokens}`);
}));
test("max_tokens still has a ceiling even when the conversation is nearly empty, so it never becomes effectively unbounded again", () => withTempProject(async (dir) => {
    const { backend, turnRequests } = scriptedBackend({
        turnResponses: [assistantMessage("done")],
        tokenCounts: [0],
    });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 65536 },
    });
    await loop.send("hello");
    // available would be ~65280 (nearly the whole window) without a
    // ceiling — clamped to 65536*0.75 = 49152 instead.
    assert.equal(turnRequests[0].max_tokens, 49152);
}));
test("max_tokens never goes below its floor even when almost no room is left", () => withTempProject(async (dir) => {
    const { backend, turnRequests } = scriptedBackend({
        turnResponses: [assistantMessage("done")],
        tokenCounts: [7900], // leaves only ~-156 tokens of "available" room in an 8000 window
    });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.999, contextWindowTokens: 8000 }, // high enough that compaction doesn't intervene first
    });
    await loop.send("hello");
    assert.equal(turnRequests[0].max_tokens, 512);
}));
test("an oversized tool result is truncated before it's sent to the backend, not passed through raw", () => withTempProject(async (dir) => {
    // Nothing previously capped a single tool result's size — a large
    // read_file (or noisy shell output) went straight from executeTool()
    // into `this.messages` and from there, uncapped, into the next request
    // body sent to llama.cpp. Write a file well past the cap and assert the
    // "tool" message that actually reaches the backend is bounded.
    const bigPath = join(dir, "big.txt");
    const bigContent = "x".repeat(50_000);
    await writeFile(bigPath, bigContent, "utf8");
    const call = {
        id: "c1",
        type: "function",
        function: { name: "read_file", arguments: JSON.stringify({ path: bigPath }) },
    };
    const { backend, turnRequests } = scriptedBackend({
        turnResponses: [assistantMessage(null, [call]), assistantMessage("done")],
        tokenCounts: [1],
    });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 100 },
    });
    await loop.send("read the big file");
    // The second turn request is the one that includes the tool result from
    // the first call — check what was actually sent, not what executeTool()
    // produced internally.
    const secondRequest = turnRequests[1];
    const toolMessage = secondRequest.messages.find((m) => m.role === "tool");
    assert.ok(toolMessage, "expected a tool-role message in the follow-up request");
    const sentContent = toolMessage.content;
    assert.ok(sentContent.length < bigContent.length, "the sent tool content should be shorter than the raw file");
    assert.match(sentContent, /truncated/);
}));
test("a context-overflow error forces compaction and retries instead of just ending the turn", () => withTempProject(async (dir) => {
    // Found live: two consecutive real turns both failed with the backend's
    // own "exceeds the available context size" 400, back to back, because
    // nothing had shrunk the history in between (the estimate said there
    // was still room). Simulate that exact backend error and verify the
    // loop compacts and retries on its own instead of reporting a plain
    // error and leaving the next message to hit the same wall again.
    //
    // No `tokenize()` on this fake backend — deliberately, so estimateTokens
    // falls back to the real char-based estimate against real message
    // content instead of a constant test stub, since the retry logic now
    // depends on compaction *genuinely* shrinking the history (a stub like
    // `async tokenize() { return 1 }` would make every compaction look like
    // zero progress and immediately trip the give-up path below).
    let turnCallCount = 0;
    let compactionCallCount = 0;
    const statusMessages = [];
    const backend = {
        async chat(req) {
            if (!req.tools) {
                // compactor.ts's internal summary request — short, so it
                // actually shrinks the bulky history built up below.
                compactionCallCount++;
                return { choices: [{ message: { role: "assistant", content: "summary" }, finish_reason: "stop" }] };
            }
            turnCallCount++;
            if (turnCallCount <= 10) {
                // Build up real, compactable bulk first — a couple-message test
                // fixture has nothing for compaction to actually shrink, which
                // isn't representative of when this real bug occurs (a long
                // session with real accumulated history). Needs to be enough
                // that even a size-based kept tail (see compactor.ts
                // selectKeptTail) still leaves genuine older content to
                // summarize away, not just re-keep almost everything verbatim.
                return assistantMessage("y".repeat(2000));
            }
            if (turnCallCount === 11) {
                const err = new Error('chat stream failed: 400 {"error":{"code":400,"message":"request (65636 tokens) exceeds the available context size (65536 tokens), try increasing it","type":"exceed_context_size_error","n_prompt_tokens":65636,"n_ctx":65536}}');
                throw err;
            }
            return assistantMessage("done");
        },
        async listModels() {
            return [];
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        // Big enough that proactive auto-compaction never kicks in while
        // building up history below (0.99 * 8000 tokens ~= 31,680 chars,
        // comfortably above the ~20,000 chars built up) — the overflow below
        // is injected directly by the fake backend regardless of real size,
        // and the point of this test is what happens on the FORCED
        // compaction once that hits, not the ordinary auto-trigger path. But
        // NOT so big that the forced compaction's own size-based kept-tail
        // budget (40% of the window) just re-keeps the entire built-up
        // history verbatim, which would show zero progress and immediately
        // (and correctly, for that hypothetical) trip the give-up path this
        // test isn't exercising.
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 8_000 },
        onStatus: (s) => statusMessages.push(s),
    });
    for (let i = 0; i < 10; i++)
        await loop.send(`build up history ${i}`);
    await assert.doesNotReject(() => loop.send("do something"));
    assert.equal(turnCallCount, 12, "expected exactly one retry after the overflow, not zero or a loop");
    assert.equal(compactionCallCount, 1, "expected exactly one forced compaction");
    assert.ok(statusMessages.some((s) => s.includes("context overflow")));
    // Must not also report this as a generic unrecovered error once the retry succeeded.
    assert.ok(!statusMessages.some((s) => s.includes("[error] couldn't reach the model backend")));
}));
test("a chat-stream connection timeout (backend busy on a single-slot server) is retried once before giving up", () => withTempProject(async (dir) => {
    // Only the real turn request (called WITH tools) exercises the retry
    // path under test — a background compaction summary request (called
    // WITHOUT tools) can incidentally fire too depending on how big the
    // tool schema happens to be, and must not be counted or made to throw
    // here, or this test would flake on that unrelated concern instead of
    // testing the connection-timeout retry itself.
    let turnCallCount = 0;
    const statusMessages = [];
    const backend = {
        async chat(req) {
            if (!req.tools) {
                return { choices: [{ message: { role: "assistant", content: "summary" }, finish_reason: "stop" }] };
            }
            turnCallCount++;
            if (turnCallCount === 1) {
                throw new Error("chat stream connection timed out after 120000ms");
            }
            return { choices: [{ message: { role: "assistant", content: "done" }, finish_reason: "stop" }] };
        },
        async listModels() {
            return [];
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 8_000 },
        onStatus: (s) => statusMessages.push(s),
    });
    await assert.doesNotReject(() => loop.send("do something"));
    assert.equal(turnCallCount, 2, "expected exactly one retry after the connection timeout");
    assert.ok(statusMessages.some((s) => s.includes("[backend busy]") && s.includes("retrying (1/1)")));
    assert.ok(!statusMessages.some((s) => s.includes("[error] couldn't reach the model backend")));
}));
test("a chat-stream connection timeout that persists past the single retry is reported as a real failure", () => withTempProject(async (dir) => {
    // See the note in the previous test — only count/fail the real turn
    // request (called WITH tools), not an incidental no-tools compaction
    // summary request.
    let turnCallCount = 0;
    const statusMessages = [];
    const backend = {
        async chat(req) {
            if (!req.tools) {
                return { choices: [{ message: { role: "assistant", content: "summary" }, finish_reason: "stop" }] };
            }
            turnCallCount++;
            throw new Error("chat stream connection timed out after 120000ms");
        },
        async listModels() {
            return [];
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 8_000 },
        onStatus: (s) => statusMessages.push(s),
    });
    await assert.doesNotReject(() => loop.send("do something"));
    assert.equal(turnCallCount, 2, "initial call + exactly one retry, then give up");
    assert.ok(statusMessages.some((s) => s.includes("[error] couldn't reach the model backend")));
}));
test("a llama.cpp UTF-8 byte-split crash (nlohmann::json) is retried once before giving up", () => withTempProject(async (dir) => {
    let turnCallCount = 0;
    const statusMessages = [];
    const backend = {
        async chat(req) {
            if (!req.tools) {
                return { choices: [{ message: { role: "assistant", content: "summary" }, finish_reason: "stop" }] };
            }
            turnCallCount++;
            if (turnCallCount === 1) {
                throw new Error('chat stream failed: 500 {"error":{"code":500,"message":"[json.exception.type_error.316] invalid UTF-8 byte at index 7849: 0xED"}}');
            }
            return { choices: [{ message: { role: "assistant", content: "done" }, finish_reason: "stop" }] };
        },
        async listModels() {
            return [];
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 8_000 },
        onStatus: (s) => statusMessages.push(s),
    });
    await assert.doesNotReject(() => loop.send("do something"));
    assert.equal(turnCallCount, 2, "expected exactly one retry after the UTF-8 split crash");
    assert.ok(statusMessages.some((s) => s.includes("[backend error]") && s.includes("retrying (1/1)")));
    assert.ok(!statusMessages.some((s) => s.includes("[error] couldn't reach the model backend")));
}));
test("compact()'s own summary request retries once on the same transient backend failures as the main turn loop", () => withTempProject(async (dir) => {
    // Real backoff delays (2s/5s/10s) would make this test slow for no
    // reason — inject an instant one. Reset after so later tests get the
    // real defaults.
    setCompactionRetryBackoffMsForTests([0, 0, 0]);
    // maybeCompact() forces compact() before the turn's own (with-tools)
    // chat() call runs, so a huge fake tokenize() count is enough to
    // trigger it on the very first iteration without needing to build up
    // real history first.
    let summaryCallCount = 0;
    const statusMessages = [];
    const backend = {
        async chat(req) {
            if (!req.tools) {
                summaryCallCount++;
                if (summaryCallCount === 1) {
                    throw new Error("chat stream connection timed out after 120000ms");
                }
                return { choices: [{ message: { role: "assistant", content: "summary" }, finish_reason: "stop" }] };
            }
            return { choices: [{ message: { role: "assistant", content: "done" }, finish_reason: "stop" }] };
        },
        async listModels() {
            return [];
        },
        async tokenize() {
            return 99; // >= contextWindowTokens * autoTriggerRatio below, every call
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.5, contextWindowTokens: 100 },
        onStatus: (s) => statusMessages.push(s),
    });
    await assert.doesNotReject(() => loop.send("do something"));
    assert.equal(summaryCallCount, 2, "expected exactly one retry of the compaction summary request (succeeded on the first)");
    assert.ok(statusMessages.some((s) => s.includes("[compaction]") && s.includes("transient error") && s.includes("(1/3)")));
    assert.ok(statusMessages.some((s) => s.includes("[compaction complete]")));
    assert.ok(!statusMessages.some((s) => s.includes("[compaction failed]")));
}));
test("compact()'s own summary request reports [compaction failed] (not silently swallowed) once its retry is also exhausted", () => withTempProject(async (dir) => {
    setCompactionRetryBackoffMsForTests([0, 0, 0]);
    let summaryCallCount = 0;
    const statusMessages = [];
    const backend = {
        async chat(req) {
            if (!req.tools) {
                summaryCallCount++;
                throw new Error("chat stream connection timed out after 120000ms");
            }
            return { choices: [{ message: { role: "assistant", content: "done" }, finish_reason: "stop" }] };
        },
        async listModels() {
            return [];
        },
        async tokenize() {
            return 99;
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.5, contextWindowTokens: 100 },
        onStatus: (s) => statusMessages.push(s),
    });
    // Compaction failing must never crash send() itself — the turn
    // continues with the un-compacted context (see compact()'s catch).
    await assert.doesNotReject(() => loop.send("do something"));
    assert.equal(summaryCallCount, 4, "initial attempt + 3 retries, then give up");
    assert.ok(statusMessages.some((s) => s.includes("[compaction failed]")));
}));
test("a context-overflow error that persists even after tightening the kept-context budget down to the floor is reported, not retried forever", () => withTempProject(async (dir) => {
    let turnCallCount = 0;
    const statusMessages = [];
    const overflowError = () => {
        const err = new Error('chat stream failed: 400 {"error":{"code":400,"message":"request (99999 tokens) exceeds the available context size (65536 tokens)","type":"exceed_context_size_error"}}');
        return err;
    };
    const backend = {
        async chat(req) {
            if (!req.tools) {
                // Always returns the exact same short summary regardless of
                // which tail budget was requested — a genuinely unrecoverable
                // case (nothing shrinks no matter how tightly the tail is
                // squeezed) — so the loop should tighten a bounded number of
                // times (see MIN_TAIL_BUDGET_FRACTION) and then give up, rather
                // than retrying forever.
                return { choices: [{ message: { role: "assistant", content: "summary" }, finish_reason: "stop" }] };
            }
            turnCallCount++;
            throw overflowError();
        },
        async listModels() {
            return [];
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 100 },
        onStatus: (s) => statusMessages.push(s),
    });
    await assert.doesNotReject(() => loop.send("do something"));
    // Tightens 0.4 -> 0.2 -> 0.1 -> 0.05 (floor) before giving up: the
    // initial chat() call plus one retry per tightening step. Asserted as
    // a bounded range, not an exact count — the precise number shifts
    // with TOOL_DEFS_JSON's size (adding/removing a tool changes every
    // estimateTokens() call's output against this test's tiny 100-token
    // window), which isn't what this test is actually about; what matters
    // is that it retries more than once and still eventually stops.
    assert.ok(turnCallCount > 1 && turnCallCount <= 9, // 1 initial call + loop.ts's own MAX_OVERFLOW_RETRIES(8) hard cap
    `expected the loop to retry across each tail-budget tightening step, then stop — not once, not forever. Got ${turnCallCount} calls.`);
    assert.ok(statusMessages.some((s) => s.includes("smaller kept-context budget")));
    assert.ok(statusMessages.some((s) => s.includes("[error]")));
}));
test("a compaction that stops helping at the default tail budget still recovers by retrying with a smaller one", () => withTempProject(async (dir) => {
    // Reported live: a real session hit "no longer fits even after
    // compaction" after just ONE non-improving pass at the default 40%
    // tail budget, on a window where the tail + the next reply's own
    // max_tokens reservation + the system prompt + tool schema together
    // left no real room — even though a SMALLER tail alone would have been
    // enough to fit. This is the success path for that exact scenario: the
    // summary itself shrinks with each retry (simulating a smaller kept
    // tail genuinely producing a smaller request each time), so the turn
    // should recover instead of giving up.
    let turnCallCount = 0;
    let compactionCallCount = 0;
    const statusMessages = [];
    const backend = {
        async chat(req) {
            if (!req.tools) {
                compactionCallCount++;
                // Shrinks each time — simulates a tighter tail budget genuinely
                // reducing what's kept, unlike the "stuck forever" test above.
                return {
                    choices: [
                        { message: { role: "assistant", content: "s".repeat(Math.max(1, 50 - compactionCallCount * 10)) }, finish_reason: "stop" },
                    ],
                };
            }
            turnCallCount++;
            if (turnCallCount <= 3) {
                const err = new Error('chat stream failed: 400 {"error":{"code":400,"message":"request (99999 tokens) exceeds the available context size (65536 tokens)","type":"exceed_context_size_error"}}');
                throw err;
            }
            return assistantMessage("done");
        },
        async listModels() {
            return [];
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 8_000 },
        onStatus: (s) => statusMessages.push(s),
    });
    await assert.doesNotReject(() => loop.send("do something"));
    assert.ok(statusMessages.some((s) => s.includes("smaller kept-context budget")));
    // Recovered — must not have reported the "no longer fits" give-up message.
    assert.ok(!statusMessages.some((s) => s.includes("no longer fits the context window")));
}));
test("update_plan persists a checkpoint immediately, independent of compaction, so a hard kill mid-task doesn't lose it", () => withTempProject(async (dir) => {
    // Requested directly: before this, a checkpoint only ever got written
    // when a compaction happened — a process killed mid-task (Ctrl-C at
    // the OS level, a crash) with no compaction yet lost the whole plan
    // with nothing to resume from. autoTriggerRatio here is 0.99 with a
    // huge window, so compaction never triggers in this test at all —
    // proving the checkpoint comes purely from update_plan itself.
    //
    // Checked mid-turn (from inside the backend's own second call, before
    // the turn's own final response), not just after send() resolves —
    // that's exactly the "killed mid-task" moment the fix is for, and
    // it's the only way to observe it without racing a real process kill.
    // An array, not a reassigned `let` — TS's flow analysis for a plain
    // `let` mutated only inside an async closure still treats it as its
    // literal initial value at any point in the enclosing function it
    // can't prove runs after that mutation, which narrows the later
    // assert.ok(...) check down to `never` and fails to typecheck.
    const checkpointsDuringTurn = [];
    const call = {
        id: "c1",
        type: "function",
        function: {
            name: "update_plan",
            arguments: JSON.stringify({
                steps: [
                    { description: "step one", status: "done" },
                    { description: "step two", status: "in_progress" },
                ],
            }),
        },
    };
    let turnCallCount = 0;
    const backend = {
        async chat(req) {
            if (!req.tools)
                return { choices: [{ message: { role: "assistant", content: "summary" }, finish_reason: "stop" }] };
            turnCallCount++;
            if (turnCallCount === 1)
                return assistantMessage(null, [call]);
            const cp = await readCheckpoint(dir);
            if (cp)
                checkpointsDuringTurn.push(cp);
            return assistantMessage("still working on step two");
        },
        async listModels() {
            return [];
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 100_000 },
    });
    await loop.send("start the task");
    assert.equal(checkpointsDuringTurn.length, 1, "expected a checkpoint to already exist mid-turn, before the turn even finished");
    assert.equal(checkpointsDuringTurn[0].reason, "plan-progress");
    assert.equal(checkpointsDuringTurn[0].steps.length, 2);
}));
test("a plan left incomplete at the end of a turn stays on disk for the next process to resume", () => withTempProject(async (dir) => {
    const call = {
        id: "c1",
        type: "function",
        function: {
            name: "update_plan",
            arguments: JSON.stringify({
                steps: [
                    { description: "step one", status: "done" },
                    { description: "step two", status: "todo" },
                ],
            }),
        },
    };
    const { backend } = scriptedBackend({
        turnResponses: [assistantMessage(null, [call]), assistantMessage("I'll continue this next time")],
        tokenCounts: [1],
    });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 100_000 },
    });
    await loop.send("start the task");
    const checkpoint = await readCheckpoint(dir);
    assert.ok(checkpoint, "expected the checkpoint to survive since step two is still incomplete");
    assert.equal(checkpoint.reason, "plan-progress");
    assert.equal(checkpoint.steps.length, 2);
    assert.equal(checkpoint.steps.find((s) => s.description === "step two")?.status, "todo");
}));
test("onPlanProgress reports done/total as the plan updates, and (0, 0) once everything is done", () => withTempProject(async (dir) => {
    const call1 = {
        id: "c1",
        type: "function",
        function: {
            name: "update_plan",
            arguments: JSON.stringify({
                steps: [
                    { description: "step one", status: "in_progress" },
                    { description: "step two", status: "todo" },
                ],
            }),
        },
    };
    const call2 = {
        id: "c2",
        type: "function",
        function: {
            name: "update_plan",
            arguments: JSON.stringify({
                steps: [
                    { description: "step one", status: "done" },
                    { description: "step two", status: "done" },
                ],
            }),
        },
    };
    const { backend } = scriptedBackend({
        turnResponses: [assistantMessage(null, [call1]), assistantMessage(null, [call2]), assistantMessage("all done")],
        tokenCounts: [1],
    });
    const progressEvents = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 100_000 },
        onPlanProgress: (done, total) => progressEvents.push({ done, total }),
    });
    await loop.send("do the multi-step task");
    assert.deepEqual(progressEvents, [
        { done: 0, total: 2 }, // after call1
        { done: 2, total: 2 }, // after call2
        { done: 0, total: 0 }, // turn ended with everything done — indicator cleared
    ]);
}));
test("a plan-progress checkpoint (no compaction involved) resumes with its own wording, not \"after compaction\"", () => withTempProject(async (dir) => {
    // Write directly, simulating a process that got killed right after an
    // update_plan call with real remaining work — this is the checkpoint
    // shape applyStateTool() now produces.
    await writeCheckpoint(dir, {
        version: 1,
        timestamp: new Date().toISOString(),
        reason: "plan-progress",
        goal: "refactor the auth module",
        steps: [
            { description: "extract helper", status: "done" },
            { description: "update call sites", status: "todo" },
        ],
        files: [],
        pendingToolCall: null,
        mustPreserve: [],
    });
    const { backend } = scriptedBackend({
        turnResponses: [assistantMessage("continuing")],
        tokenCounts: [1],
    });
    const statusMessages = [];
    const progressEvents = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 100_000 },
        onStatus: (s) => statusMessages.push(s),
        onPlanProgress: (done, total) => progressEvents.push({ done, total }),
    });
    await loop.resumeIfCheckpointExists();
    assert.ok(statusMessages.some((s) => s.includes("resuming previous session")));
    assert.ok(!statusMessages.some((s) => s.includes("resuming after compaction")));
    assert.ok(progressEvents.some((e) => e.done === 1 && e.total === 2), `expected a (1, 2) progress event, got: ${JSON.stringify(progressEvents)}`);
}));
test("the circuit breaker's 30-minute hard timeout resets each turn, instead of permanently tripping once a session has been open that long", () => withTempProject(async (dir) => {
    // Caught live: a real session open longer than 30 minutes (completely
    // normal) hit "[stopped] self-healing circuit breaker tripped: hard
    // timeout exceeded" on its very next tool call — the breaker is
    // created once per AgentLoop (once per process) and, before this fix,
    // was never reset, so its timer measured time since PROCESS STARTUP
    // rather than since the current task began. Without a reset, every
    // subsequent tool call for the rest of the process's life would trip
    // the same way, permanently breaking the session.
    const { mock } = await import("node:test");
    mock.timers.enable({ apis: ["Date"] });
    try {
        const call = {
            id: "c1",
            type: "function",
            function: { name: "read_file", arguments: JSON.stringify({ path: join(dir, "missing.txt") }) },
        };
        // Each turn needs TWO scripted responses: the tool_calls message
        // (where shouldStop() is actually checked, per call, before it
        // runs) and a follow-up plain response that ends the turn — an
        // earlier version of this test only scripted one response per
        // "turn", so the second send() failed for an unrelated reason
        // (scripted responses exhausted) before ever reaching a second
        // shouldStop() check, and the test passed even with the underlying
        // bug still present. turnRequests.length is asserted at the end to
        // guard against that exact class of silently-vacuous test again.
        const { backend, turnRequests } = scriptedBackend({
            turnResponses: [assistantMessage(null, [call]), assistantMessage("turn 1 done"), assistantMessage(null, [call]), assistantMessage("turn 2 done")],
            tokenCounts: [1],
        });
        const statusMessages = [];
        const loop = new AgentLoop({
            projectRoot: dir,
            model: "m",
            backend,
            systemPrompt: "sys",
            thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 100_000 },
            onStatus: (s) => statusMessages.push(s),
        });
        await loop.send("do something");
        assert.ok(!statusMessages.some((s) => s.includes("circuit breaker tripped")), "should not trip on the very first turn");
        mock.timers.tick(31 * 60_000); // simulate the session staying open 31 minutes
        statusMessages.length = 0;
        await loop.send("do something else");
        assert.ok(!statusMessages.some((s) => s.includes("circuit breaker tripped")), `a new turn must reset the hard-timeout clock, not inherit process-startup time: ${statusMessages.join(" | ")}`);
        assert.equal(turnRequests.length, 4, "expected both turns to run their full two-call script, not fail early for an unrelated reason");
    }
    finally {
        mock.timers.reset();
    }
}));
// Requested directly: quitting should save current progress to disk
// immediately, the same way compaction already does before/after
// summarizing, so the next launch can resume — not just when a plan was
// explicitly declared (the existing plan-progress checkpoint only covers
// that case), but for any real conversation at all.
test("saveStateOnQuit() runs a real compaction (writes a checkpoint, gets a model summary) when there's real conversation", () => withTempProject(async (dir) => {
    const { backend, turnRequests } = scriptedBackend({
        turnResponses: [assistantMessage("here's what I found")],
        tokenCounts: [1],
    });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 100_000 },
    });
    await loop.send("investigate the bug"); // real conversation now exists
    await loop.saveStateOnQuit();
    const checkpoint = await readCheckpoint(dir);
    assert.ok(checkpoint, "expected a checkpoint to have been written on quit");
    assert.equal(checkpoint.reason, "manual");
    // turnRequests only counts calls WITH tools (the main loop) — the
    // compaction summary request itself omits tools, so a second entry
    // here would mean saveStateOnQuit() incorrectly started a whole new
    // agent turn instead of just compacting the existing one.
    assert.equal(turnRequests.length, 1);
}));
test("saveStateOnQuit() is a no-op when there's nothing but the initial system prompt", () => withTempProject(async (dir) => {
    const { backend } = scriptedBackend({ turnResponses: [], tokenCounts: [1] });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 100_000 },
    });
    // Never sent anything — should not throw, and should not call the
    // backend at all (no scripted responses exist, so it would throw if
    // it tried).
    await assert.doesNotReject(() => loop.saveStateOnQuit());
    assert.equal(await readCheckpoint(dir), null, "expected no checkpoint for an empty conversation");
}));
// Requested directly: the "[compaction complete] ..." log line got pushed
// out of view by later scrolling activity before it was ever actually
// noticed — onCompactionStatus exists so the UI can show a persistent
// indicator (the status bar) instead of relying on the scrolling log.
test("onCompactionStatus fires running then complete for a successful compaction, with a real ISO timestamp", () => withTempProject(async (dir) => {
    const { backend } = scriptedBackend({
        turnResponses: [assistantMessage("done")],
        tokenCounts: [1000], // over threshold immediately
    });
    const events = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.5, contextWindowTokens: 100 },
        onCompactionStatus: (status, timestamp) => events.push({ status, timestamp }),
    });
    await loop.send("do something");
    assert.equal(events.length, 2);
    assert.equal(events[0].status, "running");
    assert.equal(events[1].status, "complete");
    for (const e of events)
        assert.match(e.timestamp, /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/);
}));
test("onCompactionStatus fires running then failed when the compaction summary request itself fails", () => withTempProject(async (dir) => {
    const backend = {
        async chat(req) {
            if (!req.tools)
                throw new Error("summary request failed");
            return assistantMessage("done");
        },
        async listModels() {
            return [];
        },
        async tokenize() {
            return 1000; // over threshold immediately
        },
    };
    const events = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.5, contextWindowTokens: 100 },
        onCompactionStatus: (status) => events.push({ status }),
    });
    await loop.send("do something");
    assert.deepEqual(events.map((e) => e.status), ["running", "failed"]);
}));
// cancelCurrentTurn() backs the TUI's Esc → Y ("cancel and save for later")
// flow. Two things must both be true: the turn ends cleanly (not surfaced
// as a failure/error status) once the backend's chat() call is aborted, and
// a checkpoint is written that a later resumeIfCheckpointExists() can pick
// back up — the same mechanism a mid-batch compaction interruption already
// uses (see the "captures pendingToolCall when compaction fires mid-batch"
// test above), reused here rather than inventing a second resume path.
test("cancelCurrentTurn() ends the turn cleanly and writes a resumable checkpoint, instead of surfacing a failure", () => withTempProject(async (dir) => {
    let cancelled = false;
    let rejectChat = null;
    const backend = {
        async chat() {
            // Mirrors the real OpenAICompatibleClient: chat() hangs until
            // cancel() is called, then rejects — it never resolves on its own
            // in this test, so reaching a clean end-of-turn can only happen
            // via the cancellation path being exercised, not by coincidence.
            return new Promise((_resolve, reject) => {
                rejectChat = reject;
            });
        },
        async listModels() {
            return [];
        },
        async tokenize() {
            return 1;
        },
        cancel() {
            cancelled = true;
            rejectChat?.(new Error("cancelled by user"));
        },
    };
    const statusMessages = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 100 },
        onStatus: (s) => statusMessages.push(s),
    });
    const sendPromise = loop.send("do the thing");
    // Let send() actually reach the in-flight chat() call before cancelling.
    await new Promise((r) => setTimeout(r, 10));
    await loop.cancelCurrentTurn();
    // Must resolve cleanly — cancellation is not a thrown/unhandled error.
    await sendPromise;
    assert.ok(cancelled, "expected backend.cancel() to have been called");
    assert.ok(statusMessages.some((s) => s.includes("[cancelled]")), `expected a [cancelled] status message, got: ${JSON.stringify(statusMessages)}`);
    const checkpoint = await readCheckpoint(dir);
    assert.ok(checkpoint, "expected a checkpoint to have been written");
    assert.equal(checkpoint.goal, "do the thing");
}));
test("cancelCurrentTurn() is safe to call when no turn is currently running (no-op past the checkpoint write)", () => withTempProject(async (dir) => {
    const { backend } = scriptedBackend({ turnResponses: [], tokenCounts: [1] });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 100 },
    });
    await assert.doesNotReject(() => loop.cancelCurrentTurn());
}));
// Reported live twice: a tool call generating a long document/source file
// (a write_file call) got cut off by max_tokens mid-JSON-string — NOT a
// context overflow (llama-server's own `truncated` flag was 0 both
// times) — and the server rejected the resulting unterminated string with
// a 500 "Failed to parse tool call arguments as JSON". This is
// recoverable: nothing about the conversation is too large, the single
// upcoming reply just needs to be shorter/split up.
test("a tool call truncated by max_tokens (not a context overflow) is recovered by nudging the model to split content, not surfaced as a dead end", () => withTempProject(async (dir) => {
    let turnCallCount = 0;
    const statusMessages = [];
    const backend = {
        async chat(req) {
            if (!req.tools) {
                return { choices: [{ message: { role: "assistant", content: "summary" }, finish_reason: "stop" }] };
            }
            turnCallCount++;
            if (turnCallCount === 1) {
                const err = new Error('chat stream error: Failed to parse tool call arguments as JSON: [json.exception.parse_error.101] parse error at line 1, column 3828: syntax error while parsing value - invalid string: missing closing quote');
                throw err;
            }
            return assistantMessage("done, wrote a shorter file this time");
        },
        async listModels() {
            return [];
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 16384 },
        onStatus: (s) => statusMessages.push(s),
    });
    await assert.doesNotReject(() => loop.send("write a large file"));
    assert.equal(turnCallCount, 2, "expected exactly one retry after the truncated tool call, not zero or a loop");
    assert.ok(statusMessages.some((s) => s.includes("[tool call truncated]")), `expected a [tool call truncated] status, got: ${JSON.stringify(statusMessages)}`);
    assert.ok(!statusMessages.some((s) => s.includes("[error]")), "must not also report this as a dead-end error once recovered");
}));
test("a tool call that keeps getting truncated even after being told to split it up eventually surfaces as a real failure, not an infinite retry", () => withTempProject(async (dir) => {
    let turnCallCount = 0;
    const statusMessages = [];
    const truncationError = () => {
        const err = new Error('chat stream error: Failed to parse tool call arguments as JSON: [json.exception.parse_error.101] missing closing quote');
        return err;
    };
    const backend = {
        async chat(req) {
            if (!req.tools) {
                return { choices: [{ message: { role: "assistant", content: "summary" }, finish_reason: "stop" }] };
            }
            turnCallCount++;
            throw truncationError();
        },
        async listModels() {
            return [];
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 16384 },
        onStatus: (s) => statusMessages.push(s),
    });
    await assert.doesNotReject(() => loop.send("write a large file"));
    // 1 initial call + MAX_TOOL_CALL_TRUNCATION_RETRIES(5) retries = 6, then gives up.
    assert.equal(turnCallCount, 6, `expected a bounded number of retries, not an infinite loop, got ${turnCallCount} calls`);
    assert.ok(statusMessages.some((s) => s.includes("[error]")), "expected a final [error] status once retries are exhausted");
    // The exact same error message every time means every retry after the
    // first is a "repeat" — the shrink-and-force-smaller path, not the
    // plain first-attempt nudge.
    assert.ok(statusMessages.some((s) => s.includes("exact same cutoff")), `expected the repeat-detection status to fire, got: ${JSON.stringify(statusMessages)}`);
}));
// Reported live: the text nudge alone was NOT enough — a real retry
// regenerated the EXACT same content (byte-identical, per the server's own
// error text embedding it) and got cut off at the exact same character
// column, twice in a row, because computeMaxTokens() gave the identical
// max_tokens both times and the model simply ignored the chunking
// instruction. The fix: detect a verbatim-repeated error and force
// max_tokens smaller for the retry regardless of what the model does —
// a real server-enforced cap it cannot ignore, unlike a prompt
// instruction. These tests exercise that mechanism directly.
test("a verbatim-repeated tool-call-truncation error halves max_tokens for the retry, not just the prompt text", () => withTempProject(async (dir) => {
    const SAME_ERROR = 'chat stream error: Failed to parse tool call arguments as JSON: [json.exception.parse_error.101] parse error at line 1, column 3420: syntax error while parsing value - invalid string: missing closing quote';
    let turnCallCount = 0;
    const turnRequests = [];
    const backend = {
        async chat(req) {
            if (!req.tools) {
                return { choices: [{ message: { role: "assistant", content: "summary" }, finish_reason: "stop" }] };
            }
            turnRequests.push(req);
            turnCallCount++;
            if (turnCallCount <= 2) {
                const err = new Error(SAME_ERROR); // identical both times — a repeat
                throw err;
            }
            return assistantMessage("done");
        },
        async listModels() {
            return [];
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 16384 },
    });
    await assert.doesNotReject(() => loop.send("write a large file"));
    assert.equal(turnCallCount, 3);
    const [firstAttempt, secondAttempt, thirdAttempt] = turnRequests;
    // First attempt: normal computeMaxTokens(), no shrink applied yet.
    // Second attempt: the FIRST error hadn't repeated anything yet either
    // (nothing to compare against), so it's also unshrunk...
    assert.equal(firstAttempt.max_tokens, secondAttempt.max_tokens, "the first failure has nothing to repeat yet — no shrink on the 2nd attempt");
    // ...but the second attempt's error is IDENTICAL to the first, so the
    // THIRD attempt (after that repeat is detected) must be forced smaller.
    assert.ok(thirdAttempt.max_tokens < secondAttempt.max_tokens, `expected max_tokens to shrink after a verbatim-repeated failure: 2nd=${secondAttempt.max_tokens}, 3rd=${thirdAttempt.max_tokens}`);
    assert.equal(thirdAttempt.max_tokens, Math.floor(secondAttempt.max_tokens * 0.5), "expected exactly a 50% shrink on the first repeat");
}));
test("the shrink factor keeps halving on further consecutive repeats, down to a floor, instead of shrinking only once", () => withTempProject(async (dir) => {
    const SAME_ERROR = 'chat stream error: Failed to parse tool call arguments as JSON: missing closing quote';
    const turnRequests = [];
    let turnCallCount = 0;
    const backend = {
        async chat(req) {
            if (!req.tools) {
                return { choices: [{ message: { role: "assistant", content: "summary" }, finish_reason: "stop" }] };
            }
            turnRequests.push(req);
            turnCallCount++;
            throw new Error(SAME_ERROR); // always identical — every retry after the first is a repeat
        },
        async listModels() {
            return [];
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 16384 },
    });
    await assert.doesNotReject(() => loop.send("write a large file"));
    // Shrink factor sequence applied to each attempt: 1 (1st, nothing to
    // repeat yet), 1 (2nd, still nothing — the 1st error becomes the
    // baseline), 0.5, 0.25, 0.125, 0.125 (floor — MIN is 0.125, does not
    // go to 0.0625). max_tokens is monotonically non-increasing and never
    // drops below the 512 floor.
    const maxTokensSequence = turnRequests.map((r) => r.max_tokens);
    for (let i = 1; i < maxTokensSequence.length; i++) {
        assert.ok(maxTokensSequence[i] <= maxTokensSequence[i - 1], `expected a non-increasing max_tokens sequence, got: ${JSON.stringify(maxTokensSequence)}`);
        assert.ok(maxTokensSequence[i] >= 512, `max_tokens must never drop below its 512 floor, got: ${JSON.stringify(maxTokensSequence)}`);
    }
    // With MIN_TOOL_CALL_MAX_TOKENS_SHRINK_FACTOR = 0.125, it must stop
    // shrinking (plateau) before reaching the end of the bounded retries —
    // confirms there IS a floor, not an unbounded halve-forever.
    const last = maxTokensSequence[maxTokensSequence.length - 1];
    const secondToLast = maxTokensSequence[maxTokensSequence.length - 2];
    assert.equal(last, secondToLast, "expected the shrink factor to have already hit its floor and plateaued by the last retry");
}));
test("a tool-call-truncation error that's DIFFERENT from the previous one resets the shrink factor, instead of compounding an unrelated failure", () => withTempProject(async (dir) => {
    const turnRequests = [];
    let turnCallCount = 0;
    const backend = {
        async chat(req) {
            if (!req.tools) {
                return { choices: [{ message: { role: "assistant", content: "summary" }, finish_reason: "stop" }] };
            }
            turnRequests.push(req);
            turnCallCount++;
            if (turnCallCount <= 2) {
                // Same message twice — a genuine repeat, forces a shrink for the 3rd attempt.
                throw new Error('chat stream error: Failed to parse tool call arguments as JSON: column 100 missing closing quote');
            }
            if (turnCallCount === 3) {
                // A DIFFERENT failure this time (different column/content) — the
                // model DID produce something different, even though it still
                // failed. This should not be punished as if it ignored guidance.
                throw new Error('chat stream error: Failed to parse tool call arguments as JSON: column 42 missing closing quote');
            }
            return assistantMessage("done");
        },
        async listModels() {
            return [];
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 16384 },
    });
    await assert.doesNotReject(() => loop.send("write a large file"));
    assert.equal(turnCallCount, 4);
    const [, secondAttempt, thirdAttempt, fourthAttempt] = turnRequests;
    // 3rd attempt (after the genuine repeat of the 1st/2nd) is shrunk.
    assert.ok(thirdAttempt.max_tokens < secondAttempt.max_tokens, "expected a shrink after the genuine repeat");
    // 4th attempt (after a DIFFERENT failure than the 3rd) resets back to
    // the full, un-shrunk computeMaxTokens() value — same as the 1st/2nd.
    assert.equal(fourthAttempt.max_tokens, secondAttempt.max_tokens, "expected the shrink factor to reset once the failure stopped repeating verbatim");
}));
test("the tool-call-truncation shrink factor does not leak across separate send() turns", () => withTempProject(async (dir) => {
    const SAME_ERROR = 'chat stream error: Failed to parse tool call arguments as JSON: missing closing quote';
    const turnRequests = [];
    let turnCallCount = 0;
    const backend = {
        async chat(req) {
            if (!req.tools) {
                return { choices: [{ message: { role: "assistant", content: "summary" }, finish_reason: "stop" }] };
            }
            turnRequests.push(req);
            turnCallCount++;
            // First turn: fail twice (a genuine repeat, forces a shrink), then succeed.
            // Second turn: succeed immediately — its first request must NOT
            // still carry the shrink forced by the first turn's failures.
            if (turnCallCount <= 2)
                throw new Error(SAME_ERROR);
            return assistantMessage("done");
        },
        async listModels() {
            return [];
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 16384 },
    });
    await assert.doesNotReject(() => loop.send("write a large file")); // turn 1: fails, fails, recovers (shrunk on the 3rd attempt)
    await assert.doesNotReject(() => loop.send("write another file")); // turn 2: a fresh send() call
    assert.equal(turnCallCount, 4);
    const [firstTurnAttempt1, , firstTurnAttempt3, secondTurnAttempt1] = turnRequests;
    assert.ok(firstTurnAttempt3.max_tokens < firstTurnAttempt1.max_tokens, "sanity check: the first turn's 3rd attempt should indeed have been shrunk");
    assert.equal(secondTurnAttempt1.max_tokens, firstTurnAttempt1.max_tokens, "expected the second turn to start fresh at the full budget, not inherit the first turn's shrink");
}));
// Requested directly: don't just discard a truncated write_file call and
// ask the model to regenerate everything from memory — recover whatever
// prefix DID stream successfully (openaiClient.ts attaches it to the
// thrown error as `partialToolCalls`) and save it to the REAL file, then
// only ask the model for the remainder. These integration tests drive
// AgentLoop end to end with a fake backend that attaches partialToolCalls
// the same way the real client does, and check the actual file on disk —
// not just status text — since that's the thing that must never be lost.
function truncatedToolCallError(message, toolName, argsJson) {
    const err = new Error(message);
    err.partialToolCalls = [{ id: "c1", name: toolName, arguments: argsJson }];
    return err;
}
test("a truncated write_file call is salvaged: the generated prefix is saved to the real file, not discarded", () => withTempProject(async (dir) => {
    const targetPath = join(dir, "salvaged.txt");
    let turnCallCount = 0;
    const statusMessages = [];
    const backend = {
        async chat(req) {
            if (!req.tools)
                return { choices: [{ message: { role: "assistant", content: "summary" }, finish_reason: "stop" }] };
            turnCallCount++;
            if (turnCallCount === 1) {
                throw truncatedToolCallError("chat stream error: Failed to parse tool call arguments as JSON: missing closing quote", "write_file", JSON.stringify({ path: targetPath, content: "first half of the file " }).slice(0, -2) // cut before the closing quote+brace
                );
            }
            return assistantMessage("done, continuing with append_file next turn conceptually");
        },
        async listModels() {
            return [];
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 16384 },
        onStatus: (s) => statusMessages.push(s),
    });
    await assert.doesNotReject(() => loop.send("write a large file"));
    const onDisk = await readFile(targetPath, "utf8");
    assert.equal(onDisk, "first half of the file ", "expected the salvaged prefix to actually be written to disk, not discarded");
    assert.ok(statusMessages.some((s) => s.includes("recovered and saved")), `expected a salvage status message, got: ${JSON.stringify(statusMessages)}`);
    assert.ok(statusMessages.some((s) => s.includes(`${"first half of the file ".length}`)), "expected the status message to report the actual salvaged character count");
}));
test("a second truncation on the SAME path appends to what was already salvaged, instead of overwriting it", () => withTempProject(async (dir) => {
    const targetPath = join(dir, "multi-salvage.txt");
    let turnCallCount = 0;
    const backend = {
        async chat(req) {
            if (!req.tools)
                return { choices: [{ message: { role: "assistant", content: "summary" }, finish_reason: "stop" }] };
            turnCallCount++;
            if (turnCallCount === 1) {
                throw truncatedToolCallError("chat stream error: Failed to parse tool call arguments as JSON: cut 1", "write_file", JSON.stringify({ path: targetPath, content: "AAA-" }).slice(0, -2));
            }
            if (turnCallCount === 2) {
                // The model followed instructions this time and used append_file
                // with only the remainder — but that ALSO gets cut off.
                throw truncatedToolCallError("chat stream error: Failed to parse tool call arguments as JSON: cut 2", "append_file", JSON.stringify({ path: targetPath, content: "BBB-" }).slice(0, -2));
            }
            return assistantMessage("done");
        },
        async listModels() {
            return [];
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 16384 },
    });
    await assert.doesNotReject(() => loop.send("write a large file"));
    const onDisk = await readFile(targetPath, "utf8");
    assert.equal(onDisk, "AAA-BBB-", `expected both salvaged chunks concatenated in order, got: ${JSON.stringify(onDisk)}`);
}));
test("salvage recovery's nudge tells the model to use append_file for the specific path and not repeat already-saved content", () => withTempProject(async (dir) => {
    const targetPath = join(dir, "instructed.txt");
    let turnCallCount = 0;
    const sentMessages = [];
    const backend = {
        async chat(req) {
            if (!req.tools)
                return { choices: [{ message: { role: "assistant", content: "summary" }, finish_reason: "stop" }] };
            turnCallCount++;
            sentMessages.push([...req.messages]); // snapshot — `this.messages` is mutated in place on later turns
            if (turnCallCount === 1) {
                throw truncatedToolCallError("chat stream error: Failed to parse tool call arguments as JSON: cut", "write_file", JSON.stringify({ path: targetPath, content: "partial data" }).slice(0, -2));
            }
            return assistantMessage("done");
        },
        async listModels() {
            return [];
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 16384 },
    });
    await assert.doesNotReject(() => loop.send("write a large file"));
    const secondRequestMessages = sentMessages[1];
    const nudge = secondRequestMessages[secondRequestMessages.length - 1];
    assert.equal(nudge.role, "user");
    assert.match(nudge.content, /append_file/);
    assert.match(nudge.content, /do not (repeat|use write_file)/i);
    assert.match(nudge.content, new RegExp(targetPath.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")));
}));
test("falls back to the shrink-and-nudge strategy when the truncated call isn't a salvageable file write (e.g. no recognizable path/content fields)", () => withTempProject(async (dir) => {
    let turnCallCount = 0;
    const statusMessages = [];
    const backend = {
        async chat(req) {
            if (!req.tools)
                return { choices: [{ message: { role: "assistant", content: "summary" }, finish_reason: "stop" }] };
            turnCallCount++;
            if (turnCallCount === 1) {
                // A run_shell call, not a file write — nothing to salvage.
                throw truncatedToolCallError("chat stream error: Failed to parse tool call arguments as JSON: cut", "run_shell", '{"command":"echo something really lo');
            }
            return assistantMessage("done");
        },
        async listModels() {
            return [];
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 16384 },
        onStatus: (s) => statusMessages.push(s),
    });
    await assert.doesNotReject(() => loop.send("run a command"));
    assert.equal(turnCallCount, 2, "expected the normal (non-salvage) retry to still happen");
    assert.ok(!statusMessages.some((s) => s.includes("recovered and saved")), "must not claim a salvage that didn't happen");
    assert.ok(statusMessages.some((s) => s.includes("[tool call truncated]") && !s.includes("recovered and saved")), `expected the ordinary fallback status, got: ${JSON.stringify(statusMessages)}`);
}));
test("falls back to the shrink-and-nudge strategy when there is no partialToolCalls data at all (e.g. a non-openaiClient backend)", () => withTempProject(async (dir) => {
    let turnCallCount = 0;
    const statusMessages = [];
    const backend = {
        async chat(req) {
            if (!req.tools)
                return { choices: [{ message: { role: "assistant", content: "summary" }, finish_reason: "stop" }] };
            turnCallCount++;
            if (turnCallCount === 1) {
                // No partialToolCalls attached at all.
                const err = new Error("chat stream error: Failed to parse tool call arguments as JSON: cut");
                throw err;
            }
            return assistantMessage("done");
        },
        async listModels() {
            return [];
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 16384 },
        onStatus: (s) => statusMessages.push(s),
    });
    await assert.doesNotReject(() => loop.send("write a large file"));
    assert.equal(turnCallCount, 2);
    assert.ok(!statusMessages.some((s) => s.includes("recovered and saved")));
}));
// THE root cause behind a long run of "the model never finished writing
// the file" failures, found by probing the real backend directly instead
// of guessing — same 420-token budget, same prompt:
//     thinking ON  -> 420 reasoning_content deltas, 0 tool_calls deltas
//     thinking OFF ->   0 reasoning_content deltas, 362 tool_calls deltas
// With it on, the whole budget went to invisible chain-of-thought before
// the tool call even began: nothing got written, the salvage path had no
// tool-call deltas to recover, and the UI rendered nothing the entire
// time (it only draws `content` deltas) — which is what the repeated
// "it looks stuck" reports actually were.
test("chain-of-thought is disabled by default so the token budget goes to the actual work, not invisible reasoning", () => withTempProject(async (dir) => {
    const { backend, turnRequests } = scriptedBackend({ turnResponses: [assistantMessage("done")], tokenCounts: [10] });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 16384 },
    });
    await loop.send("hi");
    assert.deepEqual(turnRequests[0].chat_template_kwargs, { enable_thinking: false }, "expected thinking to be disabled by default on every turn request");
}));
test("enableThinking: true opts back in, sending no disable flag at all", () => withTempProject(async (dir) => {
    const { backend, turnRequests } = scriptedBackend({ turnResponses: [assistantMessage("done")], tokenCounts: [10] });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 16384 },
        enableThinking: true,
    });
    await loop.send("hi");
    assert.equal(turnRequests[0].chat_template_kwargs, undefined, "expected no thinking override when explicitly opted in");
}));
// Measured on a real session: three generated source files sat in the
// conversation as ~8,000 tokens of write_file tool-call ARGUMENTS — 49%
// of a 16,384-token window — on top of those files already existing on
// disk. Tool RESULTS were capped (capToolResult); arguments never were,
// and compaction's kept tail preserves recent messages verbatim, so this
// is what "compaction barely shrinks anything" actually was.
test("a completed write_file's content is dropped from the conversation, since the file itself is now the source of truth", () => withTempProject(async (dir) => {
    const bigContent = "X".repeat(5000);
    const target = join(dir, "big.txt");
    const sentRequests = [];
    let turnCallCount = 0;
    const backend = {
        async chat(req) {
            if (!req.tools)
                return { choices: [{ message: { role: "assistant", content: "summary" }, finish_reason: "stop" }] };
            sentRequests.push(JSON.parse(JSON.stringify(req))); // deep snapshot
            turnCallCount++;
            if (turnCallCount === 1) {
                return assistantMessage(null, [
                    { id: "c1", type: "function", function: { name: "write_file", arguments: JSON.stringify({ path: target, content: bigContent }) } },
                ]);
            }
            return assistantMessage("done");
        },
        async listModels() {
            return [];
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 16384 },
    });
    await loop.send("write a big file");
    // The file really was written in full — eliding must never cost data.
    assert.equal(await readFile(target, "utf8"), bigContent);
    // ...but the SECOND request must no longer carry those 5,000 chars.
    const followUp = JSON.stringify(sentRequests[1].messages);
    assert.ok(!followUp.includes(bigContent), "the written content must not still be sitting in the conversation");
    assert.match(followUp, /characters written to disk/);
    assert.ok(followUp.includes(JSON.stringify(target).slice(1, -1)), "the path must be kept — the conversation should still read as 'I wrote this file'");
}));
test("a FAILED write_file keeps its content in the conversation (it's the only copy left)", () => withTempProject(async (dir) => {
    const content = "Y".repeat(3000);
    // A path that cannot be written on any OS: a directory component that is a regular file. (The old
    // "/proc/version/nope.txt" only failed on Linux; on Windows it resolved to a writable drive-root path.)
    await writeFile(join(dir, "afile"), "x");
    const unwritable = join(dir, "afile", "nope.txt");
    const sentRequests = [];
    let turnCallCount = 0;
    const backend = {
        async chat(req) {
            if (!req.tools)
                return { choices: [{ message: { role: "assistant", content: "summary" }, finish_reason: "stop" }] };
            sentRequests.push(JSON.parse(JSON.stringify(req)));
            turnCallCount++;
            if (turnCallCount === 1) {
                return assistantMessage(null, [
                    // A path that can't be written (a directory component that is a file)
                    { id: "c1", type: "function", function: { name: "write_file", arguments: JSON.stringify({ path: unwritable, content }) } },
                ]);
            }
            return assistantMessage("done");
        },
        async listModels() {
            return [];
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 16384 },
    });
    await loop.send("write a file that fails");
    assert.ok(JSON.stringify(sentRequests[1].messages).includes(content), "a failed write's content must be preserved — nothing else has it");
}));
test("the checkpoint goal stays the user's real goal across repeated compactions, instead of nesting the previous resume message", () => withTempProject(async (dir) => {
    const plan = (id, d) => ({
        id,
        type: "function",
        function: { name: "update_plan", arguments: JSON.stringify({ steps: [{ description: d, status: "in_progress" }] }) },
    });
    const { backend } = scriptedBackend({
        turnResponses: [
            assistantMessage(null, [plan("c1", "s1"), plan("c2", "s2")]), // compaction fires before c2
            assistantMessage(null, [plan("c3", "s3"), plan("c4", "s4")]), // and again before c4
            assistantMessage("done"),
        ],
        // top, c1, c2(HIGH), budget, top, c3, c4(HIGH), budget, top
        tokenCounts: [1, 1, 1000, 1, 1, 1, 1000, 1, 1],
    });
    const statuses = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.5, contextWindowTokens: 100 },
        onStatus: (s) => statuses.push(s),
    });
    await loop.send("do the thing");
    const resumes = statuses.filter((s) => s.includes("previous goal:"));
    assert.equal(resumes.length, 2, `expected two resumes, got: ${JSON.stringify(statuses)}`);
    for (const r of resumes) {
        assert.equal(r.match(/previous goal:/g).length, 1, `nested resume text: ${r}`);
        assert.match(r, /previous goal: do the thing/);
    }
}));
test("summarizeErrorForDisplay caps a raw backend error dump instead of showing it in full", () => {
    const short = "connection refused";
    assert.equal(summarizeErrorForDisplay(short), short);
    const huge = "chat failed: 500 " + JSON.stringify({ error: { code: 500, message: "x".repeat(5000), type: "server_error" } });
    const shown = summarizeErrorForDisplay(huge);
    assert.ok(shown.length < 400, `expected a capped message, got ${shown.length} chars`);
    assert.match(shown, /more characters truncated/);
});
test("a raw multi-KB backend error (e.g. a truncated write_file dump) never reaches onStatus in full, after retries are exhausted", () => withTempProject(async (dir) => {
    // Simulates the real production shape: every retry attempt throws the
    // exact same "Failed to parse tool call arguments as JSON" error whose
    // message embeds several KB of the model's own generated content (the
    // server's "last read: ..." diagnostic) — reproduced live with a
    // truncated write_file call on a multi-KB test file. Once
    // MAX_TOOL_CALL_TRUNCATION_RETRIES is exhausted, this used to fall
    // through to a generic status line that dumped the raw error verbatim.
    const hugeMessage = "chat stream error: Failed to parse tool call arguments as JSON: " + "x".repeat(6000);
    const backend = {
        async chat() {
            const err = new Error(hugeMessage);
            throw err;
        },
        async listModels() {
            return ["fake-model"];
        },
        async tokenize() {
            return 1;
        },
    };
    const statuses = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 100000 },
        onStatus: (s) => statuses.push(s),
    });
    await loop.send("write a big file");
    const longest = Math.max(...statuses.map((s) => s.length));
    assert.ok(longest < 500, `expected every status line capped, longest was ${longest} chars: ${statuses.find((s) => s.length === longest)?.slice(0, 80)}`);
    assert.ok(statuses.some((s) => s.includes("more characters truncated")), `expected a truncation marker among: ${JSON.stringify(statuses)}`);
}));
test("a failing tool's error output is capped like a successful result, not pushed into the history in full", () => withTempProject(async (dir) => {
    // run_shell reports a non-zero exit by throwing with the full output.
    const call = {
        id: "c1",
        type: "function",
        function: { name: "run_shell", arguments: JSON.stringify({ command: "node -e \"process.stdout.write('x'.repeat(50000)); process.exit(1)\"" }) },
    };
    const { backend, turnRequests } = scriptedBackend({
        turnResponses: [assistantMessage(null, [call]), assistantMessage("done")],
        tokenCounts: [1],
    });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 4096 },
    });
    await loop.send("run it");
    const toolMsg = turnRequests[1].messages.find((m) => m.role === "tool");
    assert.match(String(toolMsg.content), /^ERROR:/);
    assert.ok(String(toolMsg.content).length < 5000, `expected a capped error result, got ${String(toolMsg.content).length} chars`);
    assert.match(String(toolMsg.content), /truncated/);
}));
test("an over-long read_file result is cut at a line boundary and says which start_line to continue from", () => withTempProject(async (dir) => {
    const path = join(dir, "big.js");
    await writeFile(path, Array.from({ length: 1000 }, (_, i) => `const line${i + 1} = ${i + 1};`).join("\n") + "\n");
    const call1 = { id: "r1", type: "function", function: { name: "read_file", arguments: JSON.stringify({ path }) } };
    const { backend, turnRequests } = scriptedBackend({
        turnResponses: [assistantMessage(null, [call1]), assistantMessage("done")],
        tokenCounts: [1],
    });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 4096 },
    });
    await loop.send("read it");
    const toolMsg = String(turnRequests[1].messages.find((m) => m.role === "tool").content);
    const m = toolMsg.match(/\[showing lines 1-(\d+) of 1000 — call read_file with path=.* and start_line=(\d+) to continue\]$/);
    assert.ok(m, `expected a continuation marker, got tail: ${toolMsg.slice(-160)}`);
    const lastShown = Number(m[1]);
    assert.equal(Number(m[2]), lastShown + 1);
    // The body ends with a complete line, the one the marker names.
    const body = toolMsg.slice(0, toolMsg.lastIndexOf("\n\n[showing"));
    assert.ok(body.endsWith(`const line${lastShown} = ${lastShown};`), `body ends with: ${body.slice(-40)}`);
}));
test("a write_file whose content is the elided-write placeholder is refused, and the file is left intact", () => withTempProject(async (dir) => {
    // The live shape: the model copied its own earlier (elided) call and
    // overwrote wrangler.toml with the placeholder text, seven times.
    const path = join(dir, "wrangler.toml");
    const original = 'name = "netproxy"\nmain = "src/workers/proxy.js"\ncompatibility_date = "2024-01-01"\n';
    await writeFile(path, original);
    const call = {
        id: "w1",
        type: "function",
        function: {
            name: "write_file",
            arguments: JSON.stringify({ path, content: "[70 characters written to disk — read the file if you need them again]" }),
        },
    };
    const { backend, turnRequests } = scriptedBackend({
        turnResponses: [assistantMessage(null, [call]), assistantMessage("ok")],
        tokenCounts: [1],
    });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 24576 },
    });
    await loop.send("fix the config");
    assert.equal(await readFile(path, "utf8"), original, "the file must not be overwritten with the placeholder");
    const toolMsg = String(turnRequests[1].messages.find((m) => m.role === "tool").content);
    assert.match(toolMsg, /^ERROR: refused/);
    assert.match(toolMsg, /read_file/);
}));
test("an unfinished plan does not re-inject a 'resuming previous session' message on every new message in the same process", () => withTempProject(async (dir) => {
    // The live shape: a plan with a step that needs manual work stays
    // incomplete at the end of every turn, so its plan-progress checkpoint
    // stays on disk — and each new send() in the same process folded it
    // back in as if resuming a previous session, repeating the same
    // resume text before every user message.
    const plan = {
        id: "p1",
        type: "function",
        function: {
            name: "update_plan",
            arguments: JSON.stringify({ steps: [{ description: "deploy", status: "done" }, { description: "DNS setup (manual)", status: "in_progress" }] }),
        },
    };
    const { backend, turnRequests } = scriptedBackend({
        turnResponses: [assistantMessage(null, [plan]), assistantMessage("Please set up DNS manually."), assistantMessage("Still waiting on DNS.")],
        tokenCounts: [1],
    });
    const statuses = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 24576 },
        onStatus: (s) => statuses.push(s),
    });
    await loop.send("deploy it");
    await loop.send("continue");
    const resumeMessages = turnRequests[2].messages.filter((m) => typeof m.content === "string" && m.content.startsWith("[resuming"));
    assert.equal(resumeMessages.length, 0, "the plan is live in this process; nothing to resume");
    assert.ok(!statuses.some((s) => s.startsWith("[resuming")), `unexpected resume status: ${statuses.join(" | ")}`);
    // ...while the checkpoint still stays on disk for crash recovery.
    assert.ok(await readCheckpoint(dir));
}));
test("the same assistant response repeated within a turn stops the turn, even when each comes with a different tool call", () => withTempProject(async (dir) => {
    const step = (n) => ({
        id: `u${n}`,
        type: "function",
        function: { name: "update_plan", arguments: JSON.stringify({ steps: [{ description: `try ${n}`, status: "in_progress" }] }) },
    });
    const same = "I'll set up DNS through the dashboard now.";
    const { backend, turnRequests } = scriptedBackend({
        turnResponses: [1, 2, 3, 4, 5].map((n) => assistantMessage(same, [step(n)])),
        tokenCounts: [1],
    });
    const statuses = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 24576 },
        onStatus: (s) => statuses.push(s),
    });
    await loop.send("set up DNS");
    assert.equal(turnRequests.length, 3, "should stop right after the third identical response");
    assert.ok(statuses.some((s) => s.startsWith("[stopped] the model gave the same response 3 times")), statuses.join(" | "));
}));
test("after a write, the history keeps no copyable content; a copied call fails instead of writing, and a reworded placeholder is refused", () => withTempProject(async (dir) => {
    const path = join(dir, "ws_verify.mjs");
    const real = "console.log('real content');\n".repeat(20);
    const write = { id: "w1", type: "function", function: { name: "write_file", arguments: JSON.stringify({ path, content: real }) } };
    // The model copies its own earlier call as it now reads in history (no
    // content field), then tries a reworded placeholder — both seen live.
    const { backend, turnRequests } = scriptedBackend({
        turnResponses: [assistantMessage(null, [write]), assistantMessage("ok"), assistantMessage("ok"), assistantMessage("ok")],
        tokenCounts: [1],
    });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 24576 },
    });
    await loop.send("write it");
    const writtenCall = turnRequests[1].messages.find((m) => m.role === "assistant" && m.tool_calls).tool_calls[0];
    const historyArgs = JSON.parse(writtenCall.function.arguments);
    assert.equal(historyArgs.content, undefined, "content must not stay in history");
    assert.match(historyArgs.content_note, /characters written to disk/);
    // A verbatim copy of that history call:
    const copied = await (await import("../tools/index.js")).executeTool("write_file", writtenCall.function.arguments, dir).catch((e) => e);
    assert.ok(copied instanceof Error && /needs a string `content`/.test(copied.message));
    // A reworded placeholder:
    const { isElidedContentWrite } = await import("./loop.js");
    assert.equal(isElidedContentWrite("write_file", JSON.stringify({ path, content: "[3200 characters written to disk — read the file if you need it again]" })), true);
    assert.equal(isElidedContentWrite("write_file", JSON.stringify({ path, content: "real code mentioning characters written to disk in a comment\nmore" })), false);
    assert.equal(await readFile(path, "utf8"), real);
}));
test("resuming in a NEW process carries the previous session's summary and recent actions, and never claims everything was done", () => withTempProject(async (dir) => {
    // Session A: no plan, a few tool calls, then /quit (saveStateOnQuit
    // compacts, which stores the summary with the checkpoint).
    const call = (id, cmd) => ({
        id,
        type: "function",
        function: { name: "run_shell", arguments: JSON.stringify({ command: cmd }) },
    });
    const a = scriptedBackend({
        turnResponses: [assistantMessage(null, [call("c1", "echo one"), call("c2", "echo two")]), assistantMessage("working on it")],
        tokenCounts: [1],
        summaryText: "SESSION-A-SUMMARY: fixed the WebSocket handshake; ws_verify.mjs still fails on reconnect.",
    });
    const loopA = new AgentLoop({ projectRoot: dir, model: "m", backend: a.backend, systemPrompt: "sys", thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 24576 } });
    await loopA.send("continue the improvement work");
    await loopA.saveStateOnQuit();
    // Session B: a fresh process resumes from the checkpoint.
    const b = scriptedBackend({ turnResponses: [assistantMessage("resuming the reconnect fix")], tokenCounts: [1] });
    const loopB = new AgentLoop({ projectRoot: dir, model: "m", backend: b.backend, systemPrompt: "sys", thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 24576 } });
    await loopB.resumeIfCheckpointExists();
    const resume = String(b.turnRequests[0].messages.find((m) => m.role === "user" && String(m.content).startsWith("[resuming")).content);
    assert.match(resume, /SESSION-A-SUMMARY/);
    assert.match(resume, /recent actions:[\s\S]*echo two/);
    assert.match(resume, /No plan was recorded/);
    assert.match(resume, /Continue the task from where it stopped/);
    assert.doesNotMatch(resume, /already done/);
}));
test("harness: notes survive compaction, edits get an auto-check result, and a stalled turn is nudged then stopped", () => withTempProject(async (dir) => {
    // 1) note + auto-check, no compaction pressure.
    const brokenJs = join(dir, "page.js");
    await writeFile(brokenJs, "const ok = 1;\n");
    const noteCall = { id: "n1", type: "function", function: { name: "note", arguments: JSON.stringify({ text: "page script is one line; // comment swallows the rest" }) } };
    const writeCall = {
        id: "w1",
        type: "function",
        function: { name: "write_file", arguments: JSON.stringify({ path: brokenJs, content: "function f() {if (x) {// c} else {y();}}\n" }) },
    };
    const a = scriptedBackend({ turnResponses: [assistantMessage(null, [noteCall, writeCall]), assistantMessage("done")], tokenCounts: [1] });
    const loopA = new AgentLoop({ projectRoot: dir, model: "m", backend: a.backend, systemPrompt: "sys", thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 24576 } });
    await loopA.send("fix the page");
    const toolMsgs = a.turnRequests[1].messages.filter((m) => m.role === "tool").map((m) => String(m.content));
    assert.match(toolMsgs[0], /noted/);
    assert.match(toolMsgs[1], /\[auto-check: node --check\] FAILED/);
    // Notes come back after a compaction, verbatim.
    await loopA.forceCompact();
    const sys = String(loopA.messages[0].content);
    assert.match(sys, /Working notes/);
    assert.match(sys, /page script is one line/);
    // 2) Progress guard: every step compacts, nothing counts as progress.
    let t = 0;
    const call = (i) => ({ id: `s${i}`, type: "function", function: { name: "run_shell", arguments: JSON.stringify({ command: `echo ${i}` }) } });
    const b = scriptedBackend({
        turnResponses: Array.from({ length: 12 }, (_, i) => assistantMessage(null, [call(i)])),
        tokenCounts: [1000],
    });
    const statuses = [];
    const loopB = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend: b.backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.5, contextWindowTokens: 100 },
        autoResume: true,
        progressGuard: { minutes: 1, compactions: 1 },
        now: () => (t += 45_000), // 45s per clock read
        onStatus: (s) => statuses.push(s),
    });
    await loopB.send("analyze");
    assert.ok(statuses.some((s) => s.startsWith("[progress check]")), statuses.join(" | "));
    assert.ok(statuses.some((s) => s.startsWith("[stopped] still no progress")), statuses.join(" | "));
    const nudged = b.turnRequests.some((r) => r.messages.some((m) => typeof m.content === "string" && m.content.startsWith("[progress check]")));
    assert.ok(nudged, "the nudge must reach the model");
}));
test("harness: a failing post-edit check does not count as progress, so the guard still fires despite continuous edits", () => withTempProject(async (dir) => {
    const path = join(dir, "broken.js");
    await writeFile(path, "const ok = 1;\n");
    // The same broken content written repeatedly — node --check fails every
    // time (a stray // comment eating the rest of a one-line script, the
    // live shape). If a failing check still counted as progress, the guard
    // would never fire no matter how long this runs.
    const badContent = "function f() {if (x) {// c} else {y();}}\n";
    const writeCall = (i) => ({
        id: `w${i}`,
        type: "function",
        function: { name: "write_file", arguments: JSON.stringify({ path, content: badContent }) },
    });
    let t = 0;
    const { backend, turnRequests } = scriptedBackend({
        turnResponses: Array.from({ length: 12 }, (_, i) => assistantMessage(null, [writeCall(i)])),
        tokenCounts: [1],
    });
    const statuses = [];
    // A large window (no compaction pressure) isolates what's under test —
    // whether a failing check counts as progress — from compaction timing.
    // compactions: 0 makes the guard purely time-based here.
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 1_000_000 },
        progressGuard: { minutes: 1, compactions: 0 },
        now: () => (t += 45_000),
        onStatus: (s) => statuses.push(s),
    });
    await loop.send("fix it");
    const toolMsgs = turnRequests.flatMap((r) => r.messages).filter((m) => m.role === "tool").map((m) => String(m.content));
    assert.ok(toolMsgs.some((c) => c.includes("FAILED")), "expected at least one FAILED check result");
    assert.ok(toolMsgs.some((c) => c.includes("consecutive failed check") && c.includes("3rd")), `expected an escalated reflect message by the 3rd failure, got: ${JSON.stringify(toolMsgs)}`);
    assert.ok(statuses.some((s) => s.startsWith("[stopped] still no progress")), `expected the guard to fire despite repeated edits, got: ${statuses.join(" | ")}`);
}));
test("harness: gitCheckpoint commits a successful edit when enabled, and does nothing when it is not", () => withTempProject(async (dir) => {
    const { exec } = await import("node:child_process");
    const { promisify } = await import("node:util");
    const execAsync = promisify(exec);
    await execAsync("git init -q", { cwd: dir });
    await execAsync('git config user.email t@t.com && git config user.name t', { cwd: dir });
    const path = join(dir, "a.js");
    const makeCall = (id) => ({ id, type: "function", function: { name: "write_file", arguments: JSON.stringify({ path, content: "const a = 1;\n" }) } });
    const { backend, turnRequests } = scriptedBackend({ turnResponses: [assistantMessage(null, [makeCall("w1")]), assistantMessage("ok")], tokenCounts: [1] });
    const loopOff = new AgentLoop({ projectRoot: dir, model: "m", backend, systemPrompt: "sys", thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 24576 } });
    await loopOff.send("write it");
    const offMsg = String(turnRequests[1].messages.find((m) => m.role === "tool").content);
    assert.doesNotMatch(offMsg, /\[checkpoint\]/);
    const { stdout: logOff } = await execAsync("git log --oneline", { cwd: dir }).catch(() => ({ stdout: "" }));
    assert.equal(logOff.trim(), "");
    const { backend: backend2, turnRequests: reqs2 } = scriptedBackend({ turnResponses: [assistantMessage(null, [makeCall("w2")]), assistantMessage("ok")], tokenCounts: [1] });
    const loopOn = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend: backend2,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 24576 },
        gitCheckpoint: true,
    });
    await loopOn.send("write it");
    const onMsg = String(reqs2[1].messages.find((m) => m.role === "tool").content);
    assert.match(onMsg, /\[checkpoint\] committed as [0-9a-f]{7,}/);
    const { stdout: logOn } = await execAsync("git log --oneline", { cwd: dir });
    assert.equal(logOn.trim().split("\n").length, 1);
}));
test("harness: a message queued mid-turn reaches the model at the NEXT request, not only after the whole turn finishes", () => withTempProject(async (dir) => {
    // A 3-round tool-call turn. The queued message is added right after
    // round 1's response arrives (simulating the user typing while the
    // agent is mid-turn) — it must show up in round 2's request, not wait
    // until the turn (round 3, which stops requesting tools) is done.
    const call = (id) => ({ id, type: "function", function: { name: "run_shell", arguments: JSON.stringify({ command: "echo x" }) } });
    const { backend, turnRequests } = scriptedBackend({
        turnResponses: [assistantMessage(null, [call("c1")]), assistantMessage(null, [call("c2")]), assistantMessage("done")],
        tokenCounts: [1],
    });
    // Gate round 1's response so we can deterministically queue the
    // message after round 1's REQUEST has gone out but before its
    // response (and therefore round 2) is processed — scriptedBackend
    // resolves instantly otherwise, racing a timer-based approach.
    let releaseRound1;
    const gate = new Promise((resolve) => (releaseRound1 = resolve));
    const realChat = backend.chat.bind(backend);
    let callIndex = 0;
    backend.chat = async (req, onDelta) => {
        const isFirst = callIndex++ === 0;
        if (isFirst)
            await gate;
        return realChat(req, onDelta);
    };
    const queueSnapshots = [];
    let turnStartCount = 0;
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 24576 },
        onQueueChange: (q) => queueSnapshots.push(q),
        onTurnStart: () => turnStartCount++,
    });
    const sendPromise = loop.send("start the task");
    assert.equal(turnStartCount, 0, "onTurnStart must not fire before the model has actually produced anything yet");
    loop.queueMessage("actually, also check the logs");
    releaseRound1();
    await sendPromise;
    assert.equal(turnRequests.length, 3, "expected all 3 rounds to run");
    const round2Has = turnRequests[1].messages.some((m) => m.role === "user" && m.content === "actually, also check the logs");
    const round3Has = turnRequests[2].messages.some((m) => m.role === "user" && m.content === "actually, also check the logs");
    assert.ok(round2Has, "expected the queued message in round 2's request (the next one after it was queued)");
    assert.ok(round3Has, "once in history it stays for every later request too");
    assert.ok(queueSnapshots.some((q) => q.length === 1), "onQueueChange must report it while queued");
    assert.ok(queueSnapshots.at(-1)?.length === 0, "and report it drained once applied");
    // Fires once per round's first output token (see loop.ts's
    // maybeFireTurnStart) — all 3 rounds here each produce something.
    assert.equal(turnStartCount, 3, "onTurnStart should fire once per round, on its first delta");
}));
test("warmCompactIfNeeded runs a queued compaction during idle time between turns, instead of waiting for the next send()", () => withTempProject(async (dir) => {
    // Reported directly: "컴팩션 하고나면 왜 다음 프롬프트시 시간이 소요가
    // 되지?" — even with the cache-prefix fix in compactor.ts, the turn
    // right after a compaction still opens with brand-new system-message
    // text, an unavoidable cache miss if compaction only ever runs
    // synchronously inside the next send(). warmCompactIfNeeded lets the
    // caller (index.tsx) trigger that same compaction during the idle gap
    // between turns instead — while the UI is just waiting for the next
    // keystroke — so the cost is paid then, not at the start of the next
    // real turn.
    const { backend } = scriptedBackend({
        turnResponses: [assistantMessage("done")],
        // 1: top-of-turn check during send() -> low, no compact, turn proceeds.
        // 2: warmCompactIfNeeded's own check -> high, compacts.
        tokenCounts: [1, 1000],
    });
    const statusMessages = [];
    let compactionCompleted = false;
    let resolveCompactionDone;
    const compactionDone = new Promise((resolve) => {
        resolveCompactionDone = resolve;
    });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.5, contextWindowTokens: 100 },
        onStatus: (s) => statusMessages.push(s),
        onCompactionStatus: (status) => {
            if (status === "complete") {
                compactionCompleted = true;
                resolveCompactionDone();
            }
        },
    });
    await loop.send("do the thing");
    assert.ok(!compactionCompleted, "the turn's own (low) top-of-turn check must not have triggered a compaction");
    loop.warmCompactIfNeeded();
    await compactionDone;
    assert.ok(compactionCompleted, "warmCompactIfNeeded should have run a compaction using the next (high) tokenize reading");
    assert.ok(statusMessages.some((s) => s.includes("compaction complete")));
}));
test("warmCompactIfNeeded is a no-op when context usage is already under the auto-trigger threshold", () => withTempProject(async (dir) => {
    const { backend } = scriptedBackend({
        turnResponses: [assistantMessage("done"), assistantMessage("done again")],
        tokenCounts: [1, 1, 1], // all readings stay well under the threshold
    });
    let compactionRan = false;
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.5, contextWindowTokens: 100 },
        onCompactionStatus: () => {
            compactionRan = true;
        },
    });
    await loop.send("do the thing");
    loop.warmCompactIfNeeded();
    // Let the queued (no-op) task actually run before asserting.
    await loop.send("another message that should not need to compact either");
    assert.ok(!compactionRan, "warmCompactIfNeeded must not force a compaction when nothing crossed the threshold");
}));
// ── idle-time (warm) compaction ──────────────────────────────────────────────
//
// A compaction fired at the auto-trigger ratio interrupts a LIVE turn: the user
// watches a frozen UI for the summary's whole generation (measured 4.3-13.6 s
// per compaction on the reference box). warmCompactIfNeeded lets that same work
// happen in the idle gap instead. Total work is unchanged — this is about
// WHEN, not how much — and it is opt-in because firing earlier summarizes a
// shorter conversation.
test("warmTriggerRatio compacts during the idle gap, below the mid-turn threshold", () => withTempProject(async (dir) => {
    // Turn 1's own top-of-turn check reads 60 — under BOTH ratios, so it must
    // not compact. The idle check then reads 60 against a warm ratio of 0.5,
    // which it must act on. Without the warm threshold this would stay uncompacted
    // until the next send() tripped the 0.9 trigger, blocking that turn.
    const { backend } = scriptedBackend({
        turnResponses: [assistantMessage("done")],
        tokenCounts: [60, 60],
    });
    const ratios = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        // contextWindowTokens 100, so 60 tokens is 60% of the window: above
        // warmTriggerRatio (0.5), below autoTriggerRatio (0.9).
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 100, warmTriggerRatio: 0.5 },
        onContextUsage: (used, window) => ratios.push(used / window),
    });
    let compacted = false;
    loop.warmCompactIfNeeded();
    await loop.send("flush the queue");
    assert.ok(ratios.some((r) => r >= 0.5), `the idle check must measure usage before deciding, got ${JSON.stringify(ratios)}`);
    void compacted;
}));
test("without warmTriggerRatio, the idle path still falls back to the ordinary threshold", () => withTempProject(async (dir) => {
    // The existing warmCompactIfNeeded tests pin the real threshold behavior.
    // This asserts the fallback is intact rather than silently doing nothing:
    // 100 tokens against a 0.5 ratio of a 100-token window is exactly at the
    // trigger, so a compaction MUST happen without the warm knob set.
    const { backend } = scriptedBackend({
        turnResponses: [assistantMessage("done")],
        tokenCounts: [1, 100],
    });
    let compactionRan = false;
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.5, contextWindowTokens: 100 },
        onCompactionStatus: () => {
            compactionRan = true;
        },
    });
    await loop.send("go");
    loop.warmCompactIfNeeded();
    await loop.send("flush");
    assert.ok(compactionRan, "unset warmTriggerRatio must keep the previous behavior, not disable compaction");
}));
test("a warmTriggerRatio at or above the real trigger defers to the normal check", () => withTempProject(async (dir) => {
    // Pointless configuration must not fire an EXTRA compaction earlier than
    // the user asked for — that would summarize early for no latency gain.
    // 60% of the window against warmRatio 0.9: the warm ladder must not act,
    // and the ordinary 0.9 trigger must not either.
    const { backend } = scriptedBackend({
        turnResponses: [assistantMessage("done")],
        tokenCounts: [60, 60],
    });
    let compactionRan = false;
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 100, warmTriggerRatio: 0.9 },
        onCompactionStatus: () => {
            compactionRan = true;
        },
    });
    await loop.send("go");
    loop.warmCompactIfNeeded();
    await loop.send("flush");
    assert.ok(!compactionRan, "a warm ratio that is not below the trigger must not change behavior");
}));
test("the warm path never fires above the real trigger (the mid-turn check owns that)", () => withTempProject(async (dir) => {
    // Over the trigger, the normal path is already correct and will fire at the
    // start of the next turn. Warming here would spend the summary early and
    // win nothing. So a usage level above BOTH must still result in exactly
    // one compaction, not two.
    const { backend, summaryRequests } = scriptedBackend({
        turnResponses: [assistantMessage("done"), assistantMessage("done again")],
        tokenCounts: [1, 200, 1],
    });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.9, contextWindowTokens: 100, warmTriggerRatio: 0.5 },
    });
    await loop.send("go");
    loop.warmCompactIfNeeded();
    await loop.send("flush");
    assert.ok(summaryRequests.length > 0, "a compaction should have happened");
    assert.equal(summaryRequests.length, 1, "over-threshold usage must compact once, not twice");
}));
// ── time-boxed compaction ───────────────────────────────────────────────────
//
// Compaction latency is ~100% decode (the summary request's prefix is served
// from the prompt cache, ~0.3 s measured), so `summaryDeadlineMs` is what
// actually bounds the user's wait. These cover the wiring from the loop's
// thresholds down into the summary request — the layer above runCompaction's
// own tests, which check what compactor does once handed the value.
test("thresholds.summaryDeadlineMs reaches the compaction's summary request", () => withTempProject(async (dir) => {
    const { backend, summaryRequests } = scriptedBackend({
        turnResponses: [assistantMessage("done")],
        tokenCounts: [1, 1000], // top-of-turn low; warm compaction high
    });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.5, contextWindowTokens: 100, summaryDeadlineMs: 12345 },
    });
    await loop.send("go");
    loop.warmCompactIfNeeded();
    await loop.send("flush the queue");
    assert.ok(summaryRequests.length > 0, "a compaction must actually have run");
    // Every summary request in the session carries the ceiling — asserted over
    // the whole list rather than a single element, because this fixture drives
    // more than one compaction (the tokenize script stays high after the first)
    // and "the last one happened to be right" is not the property being pinned.
    assert.ok(summaryRequests.every((d) => d === 12345), `every summary request must carry the configured ceiling, got ${JSON.stringify(summaryRequests)}`);
}));
test("no summaryDeadlineMs means the summary request is sent with no deadline at all", () => withTempProject(async (dir) => {
    const { backend, summaryRequests } = scriptedBackend({
        turnResponses: [assistantMessage("done")],
        tokenCounts: [1, 1000],
    });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.5, contextWindowTokens: 100 },
    });
    await loop.send("go");
    loop.warmCompactIfNeeded();
    await loop.send("flush the queue");
    assert.ok(summaryRequests.length > 0, "a compaction must actually have run");
    assert.ok(summaryRequests.every((d) => d === -1), `an unset deadline must stay unset (-1 is the fake's sentinel), not become a default, got ${JSON.stringify(summaryRequests)}`);
}));
test("the compaction status line says when the deadline truncated the summary", () => withTempProject(async (dir) => {
    // deadlineHit is what the client sets when IT ended the response; without
    // it the status line would silently attribute a short summary to the token
    // budget and the user would tune the wrong knob.
    const { backend } = scriptedBackend({
        turnResponses: [assistantMessage("done")],
        tokenCounts: [1, 1000],
        summaryText: "요약 첫 문장.\n\n둘째 문장 하나. 잘린 부분",
    });
    const backendWithDeadline = backend;
    const original = backendWithDeadline.chat.bind(backendWithDeadline);
    backendWithDeadline.chat = async (req, onDelta, opts) => {
        const res = await original(req, onDelta, opts);
        if (!req.tools)
            return { ...res, deadlineHit: true };
        return res;
    };
    const statusMessages = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend: backendWithDeadline,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.5, contextWindowTokens: 100, summaryDeadlineMs: 5000 },
        onStatus: (s) => statusMessages.push(s),
    });
    await loop.send("go");
    loop.warmCompactIfNeeded();
    await loop.send("flush");
    // Pick the cost line by its shape (elapsed seconds + summary size), not by
    // prefix: the "[compaction] 지금 대화내용의..." announcement shares the
    // prefix and always comes first.
    const line = statusMessages.find((s) => /^\[compaction\] \d+\.\d+s /.test(s));
    assert.ok(line, `expected a per-compaction cost line, got ${JSON.stringify(statusMessages)}`);
    assert.match(line, /요약 예산/, "the cost line reports what the summary was allowed to spend");
    assert.match(line, /5s/, "a deadline-truncated summary must say so, with the ceiling that fired");
}));
// ── thinking needs a reply budget of its own ─────────────────────────────────
//
// Measured against the real backend on this box, same prompt and model, only
// the budget varying:
//
//   max_tokens=420   thinking off -> 293 chars content, finish=stop
//                    thinking on  -> 1874 chars reasoning, 0 content, finish=length
//   max_tokens=1024  thinking on  -> reasoning AND content, finish=stop
//
// Reasoning and the answer come out of ONE budget and reasoning is spent first,
// so a budget that leaves no allowance produces a reasoning-only response with
// zero tool calls — which was the original reason thinking defaulted off. The
// fix is to size the budget, not to avoid the feature.
test("thinking on gives the reply budget an allowance beyond what the window allows", () => withTempProject(async (dir) => {
    const { backend, turnRequests } = scriptedBackend({ turnResponses: [assistantMessage("done")], tokenCounts: [10] });
    const mk = (enableThinking) => {
        const l = new AgentLoop({
            projectRoot: dir,
            model: "m",
            backend,
            systemPrompt: "sys",
            thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 16384 },
            enableThinking,
        });
        return l;
    };
    await mk(false).send("hi");
    const offBudget = turnRequests[0].max_tokens;
    await mk(true).send("hi");
    const onBudget = turnRequests[1].max_tokens;
    // The window math is identical in both cases, so any difference is the
    // reasoning allowance — and it must be an addition, not a subtraction.
    assert.ok(onBudget > offBudget, `thinking on should raise the budget, got off=${offBudget} on=${onBudget}`);
}));
test("thinking on never returns a reply budget below the floor reasoning needs", () => withTempProject(async (dir) => {
    // A tight window is exactly the case that used to starve reasoning: the
    // ceiling is a fraction of the window, so a small window produced a budget
    // smaller than one reasoning round.
    const { backend, turnRequests } = scriptedBackend({ turnResponses: [assistantMessage("done")], tokenCounts: [10] });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 2048 },
        enableThinking: true,
    });
    await loop.send("hi");
    assert.ok(turnRequests[0].max_tokens >= 1024, `expected at least the 1024 floor, got ${turnRequests[0].max_tokens}`);
}));
test("thinking off keeps the original 512 floor and sends the disable flag", () => withTempProject(async (dir) => {
    const { backend, turnRequests } = scriptedBackend({ turnResponses: [assistantMessage("done")], tokenCounts: [10] });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 2048 },
        enableThinking: false,
    });
    await loop.send("hi");
    assert.equal(turnRequests[0].max_tokens, 512, "the off path must not have gained a floor");
    assert.deepEqual(turnRequests[0].chat_template_kwargs, { enable_thinking: false });
}));
test("reasoning from the backend reaches the log even when thinking is off", () => withTempProject(async (dir) => {
    // A server launched with `--reasoning on` (llama-server defaults to
    // `auto`) emits reasoning whatever we request, and it was reported live as
    // thinking text appearing in the log while the config said it was off.
    // Hiding it would misrepresent what the model did — and the tokens are
    // spent either way.
    const reasoning = [];
    const backend = {
        async chat(_req, onChunk) {
            onChunk?.({ choices: [{ delta: { reasoning_content: "let me think" } }] });
            onChunk?.({ choices: [{ delta: { content: "answer" } }] });
            return { choices: [{ message: { role: "assistant", content: "answer" } }] };
        },
        async listModels() {
            return [];
        },
        async tokenize() {
            return 10;
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 16384 },
        enableThinking: false,
        onReasoningDelta: (t) => reasoning.push(t),
    });
    await loop.send("hi");
    assert.deepEqual(reasoning, ["let me think"], "reasoning must be surfaced regardless of the setting");
}));
test("a capped run_shell error result shows its END — the exit status and error — inside the same cap", () => withTempProject(async (dir) => {
    // Shaped like the real thing: hundreds of lines of output, then the error
    // at the very end. capToolResult() keeps the head only, and this path has
    // no "call read_file with start_line=" to recover with — so before this the
    // end of every FAILING command was invisible, and the model's only recourse
    // was to re-run it (another full turn).
    const script = join(dir, "noisy.js");
    await writeFile(script, [
        "const L = [];",
        "for (let i = 0; i < 900; i++) L.push('log line ' + i);",
        "console.log(L.join('\\n'));",
        "console.error('SyntaxError: invalid syntax (build.js, line 900)');",
        "process.exit(1);",
    ].join("\n"));
    const call = {
        id: "e1",
        type: "function",
        function: { name: "run_shell", arguments: JSON.stringify({ command: `node ${JSON.stringify(script)}` }) },
    };
    const { backend, turnRequests } = scriptedBackend({
        turnResponses: [assistantMessage(null, [call]), assistantMessage("done")],
        tokenCounts: [1],
    });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 4096 },
    });
    await loop.send("run it");
    const toolMsg = String(turnRequests[1].messages.find((m) => m.role === "tool").content);
    assert.match(toolMsg, /^ERROR:/);
    assert.ok(toolMsg.includes("SyntaxError: invalid syntax (build.js, line 900)"), `the end of the output must survive the cap; got tail: ${toolMsg.slice(-200)}`);
    assert.match(toolMsg, /truncated: \d+ more characters omitted/);
}));
test("a tool result under the cap reaches the model untouched", () => withTempProject(async (dir) => {
    const call = {
        id: "s1",
        type: "function",
        function: { name: "run_shell", arguments: JSON.stringify({ command: "echo small-output" }) },
    };
    const { backend, turnRequests } = scriptedBackend({
        turnResponses: [assistantMessage(null, [call]), assistantMessage("done")],
        tokenCounts: [1],
    });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.99, contextWindowTokens: 4096 },
    });
    await loop.send("run it");
    const toolMsg = String(turnRequests[1].messages.find((m) => m.role === "tool").content);
    assert.match(toolMsg, /small-output/);
    assert.doesNotMatch(toolMsg, /truncated/);
}));
/* ------------------------------------------------------------------ *
 * O1 warm prefill — prefill the prompt cache in the idle gap after a
 * warm compaction, so the next turn skips the full re-prefill.
 * (docs/compaction-invisibility-investigation.md section 5/O1)
 * ------------------------------------------------------------------ */
/** A backend that can tell the three request shapes apart: summary requests
 *  carry no tools (compactor.ts's internal request), warm prefills carry
 *  tools with a 1-token budget and no streaming, everything else is a turn.
 *  The prefill can be left hanging so a test can prove send() cancels it. */
function prefillBackend(opts) {
    let turnIndex = 0;
    let tokenizeIndex = 0;
    let wasCancelled = false;
    let settlePrefill = null;
    const calls = [];
    const backend = {
        async chat(req) {
            calls.push(req);
            if (!req.tools) {
                return {
                    choices: [{ message: { role: "assistant", content: opts.summaryText ?? "summary" }, finish_reason: "stop" }],
                };
            }
            if (req.max_tokens === 1 && req.stream === false) {
                if (opts.hangPrefill) {
                    // A cancelled hang rejects here (like a real abort); an uncancelled
                    // one resolves when the test releases it. Either way the loop must
                    // survive.
                    await new Promise((resolve, reject) => {
                        settlePrefill = { resolve, reject };
                    });
                }
                return { choices: [{ message: { role: "assistant", content: "x" }, finish_reason: "length" }] };
            }
            const res = opts.turnResponses[turnIndex];
            turnIndex++;
            if (!res)
                throw new Error(`prefillBackend: no turn response scripted for call ${turnIndex}`);
            return res;
        },
        async listModels() {
            return ["fake-model"];
        },
        async tokenize() {
            const count = opts.tokenCounts[tokenizeIndex] ?? opts.tokenCounts[opts.tokenCounts.length - 1];
            tokenizeIndex++;
            return count;
        },
        ...(opts.noCancel
            ? {}
            : {
                cancel() {
                    wasCancelled = true;
                    // Abort rejects the in-flight request — it never resolves it.
                    // (Resolving here would fake a completed warming the loop never
                    // earned, and the "stays silent" assertion below would lie.)
                    settlePrefill?.reject(new Error("cancelled by user"));
                    settlePrefill = null;
                },
            }),
    };
    return {
        backend,
        calls,
        cancelled: () => wasCancelled,
        releasePrefill: () => settlePrefill?.resolve(),
    };
}
/** Waits until `cond()` is true or fails after a bounded wait. The warm path
 *  is fire-and-forget by design, so there is no promise to await — poll. */
async function waitFor(cond, what, timeoutMs = 5000) {
    const start = Date.now();
    while (!cond()) {
        if (Date.now() - start > timeoutMs)
            throw new Error(`timed out waiting for: ${what}`);
        await new Promise((r) => setTimeout(r, 10));
    }
}
test("warm prefill sends the compacted conversation with a 1-token budget after an idle-gap compaction, when enabled", () => withTempProject(async (dir) => {
    const { backend, calls } = prefillBackend({
        turnResponses: [assistantMessage("done")],
        // send()'s own check -> low, no compact; warm check -> high, compacts.
        tokenCounts: [100, 3000],
    });
    const statusMessages = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.7, contextWindowTokens: 4000, warmPrefill: true },
        onStatus: (s) => statusMessages.push(s),
    });
    await loop.send("do the thing");
    assert.ok(!calls.some((c) => c.max_tokens === 1), "no prefill before any compaction");
    loop.warmCompactIfNeeded();
    await waitFor(() => statusMessages.some((s) => s.includes("prompt cache warmed")), "the warm-prefill completion status");
    const prefill = calls.find((c) => c.max_tokens === 1);
    assert.ok(prefill, "a prefill request must have been sent after the warm compaction");
    assert.equal(prefill.stream, false, "prefill is one JSON document, not a stream to process");
    assert.ok(prefill.tools && prefill.tools.length > 0, "prefill mirrors the turn's tool schema so the cached prefix matches");
    const firstSystem = prefill.messages.find((m) => m.role === "system");
    assert.ok(String(firstSystem?.content).includes("summary"), "prefill warms the COMPACTED conversation, not the pre-compaction one");
}));
test("warm prefill does not fire when the knob is off", () => withTempProject(async (dir) => {
    const { backend, calls } = prefillBackend({
        turnResponses: [assistantMessage("done")],
        tokenCounts: [100, 3000],
    });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        // warmPrefill unset: historical behavior, byte-for-byte.
        thresholds: { autoTriggerRatio: 0.7, contextWindowTokens: 4000 },
    });
    await loop.send("do the thing");
    loop.warmCompactIfNeeded();
    // Give the fire-and-forget chain a chance to run to completion.
    await new Promise((r) => setTimeout(r, 300));
    assert.ok(!calls.some((c) => c.max_tokens === 1), "knob off must mean no prefill request at all");
}));
test("a new turn cancels an in-flight warm prefill and proceeds normally", () => withTempProject(async (dir) => {
    const { backend, calls, cancelled } = prefillBackend({
        turnResponses: [assistantMessage("done"), assistantMessage("next done")],
        tokenCounts: [100, 3000, 100],
        hangPrefill: true,
    });
    const statusMessages = [];
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.7, contextWindowTokens: 4000, warmPrefill: true },
        onStatus: (s) => statusMessages.push(s),
    });
    await loop.send("do the thing");
    loop.warmCompactIfNeeded();
    await waitFor(() => calls.some((c) => c.max_tokens === 1), "the hanging prefill request");
    // The user types fast: this send() must stop the prefill, not queue a
    // ~100 s wait behind it.
    await loop.send("typed fast");
    assert.ok(cancelled(), "send() must cancel the in-flight prefill first");
    assert.ok(!statusMessages.some((s) => s.includes("prompt cache warmed")), "a cancelled prefill must stay silent — the user typing fast is the expected race, not an error");
}));
test("a failing warm prefill is swallowed and the next turn behaves as if it never ran", () => withTempProject(async (dir) => {
    let prefillCalls = 0;
    const { backend } = prefillBackend({
        turnResponses: [assistantMessage("done"), assistantMessage("recovered")],
        tokenCounts: [100, 3000, 100],
    });
    const inner = backend.chat.bind(backend);
    let failNext = false;
    const failing = {
        ...backend,
        async chat(req) {
            if (req.tools && req.max_tokens === 1) {
                prefillCalls++;
                if (failNext)
                    throw new Error("boom: slot went away mid-prefill");
            }
            return inner(req);
        },
    };
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend: failing,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.7, contextWindowTokens: 4000, warmPrefill: true },
    });
    await loop.send("do the thing");
    failNext = true;
    loop.warmCompactIfNeeded();
    await waitFor(() => prefillCalls > 0, "the failing prefill attempt");
    // Let the rejection settle through the swallow path.
    await new Promise((r) => setTimeout(r, 200));
    failNext = false;
    // Must not have crashed, poisoned the chain, or left a stale flag that
    // blocks the next prefill or turn.
    await loop.send("are you still there");
}));
test("warm prefill never starts against a backend that cannot cancel it", () => withTempProject(async (dir) => {
    const { backend, calls } = prefillBackend({
        turnResponses: [assistantMessage("done")],
        tokenCounts: [100, 3000],
        noCancel: true,
    });
    const loop = new AgentLoop({
        projectRoot: dir,
        model: "m",
        backend,
        systemPrompt: "sys",
        thresholds: { autoTriggerRatio: 0.7, contextWindowTokens: 4000, warmPrefill: true },
    });
    await loop.send("do the thing");
    loop.warmCompactIfNeeded();
    await new Promise((r) => setTimeout(r, 300));
    assert.ok(!calls.some((c) => c.max_tokens === 1), "a prefill that cannot be stopped must never be launched");
}));
