import { exec } from "node:child_process";
import { promisify } from "node:util";
const execAsync = promisify(exec);
let repoRootCache;
async function findRepoRoot(cwd) {
    repoRootCache ??= new Map();
    if (repoRootCache.has(cwd))
        return repoRootCache.get(cwd);
    let root = null;
    try {
        const { stdout } = await execAsync("git rev-parse --show-toplevel", { cwd, timeout: 5000 });
        root = stdout.trim() || null;
    }
    catch {
        root = null;
    }
    repoRootCache.set(cwd, root);
    return root;
}
/** Commits exactly `path` (relative to `projectRoot`, or absolute under it)
 *  with a short, machine-attributable message. No-ops outside a git repo,
 *  or when the path is gitignored, or when there is nothing to commit
 *  (content identical to HEAD). */
export async function gitCheckpoint(path, message, projectRoot) {
    const root = await findRepoRoot(projectRoot);
    if (!root)
        return { committed: false, reason: "not a git repository" };
    try {
        const ignored = await execAsync(`git check-ignore -q -- ${JSON.stringify(path)}`, { cwd: root }).then(() => true, () => false);
        if (ignored)
            return { committed: false, reason: "path is gitignored" };
        await execAsync(`git add -- ${JSON.stringify(path)}`, { cwd: root, timeout: 10_000 });
        const staged = await execAsync("git diff --cached --quiet -- " + JSON.stringify(path), { cwd: root }).then(() => false, // exit 0 = no staged diff = nothing to commit
        () => true // exit 1 = there IS a staged diff
        );
        if (!staged)
            return { committed: false, reason: "no change to commit" };
        await execAsync(`git commit --no-verify -m ${JSON.stringify(message)} -- ${JSON.stringify(path)}`, { cwd: root, timeout: 10_000, env: { ...process.env, GIT_AUTHOR_NAME: "llamacli", GIT_AUTHOR_EMAIL: "llamacli@local" } });
        const { stdout } = await execAsync("git rev-parse --short HEAD", { cwd: root, timeout: 5000 });
        return { committed: true, hash: stdout.trim() };
    }
    catch (err) {
        return { committed: false, reason: String(err.message ?? err).slice(0, 200) };
    }
}
/** Test-only: clears the repo-root memo between runs against different dirs. */
export function resetGitCheckpointCacheForTests() {
    repoRootCache = undefined;
}
