import fetch from "node-fetch";
import { Agent } from "node:http";
/** Every request this client makes opts out of HTTP keep-alive.
 *
 *  Node's global agent has `keepAlive: true` (Node >= 19), and it does NOT
 *  honor the server's advertised keep-alive window — there is no code path
 *  that reads `Keep-Alive: timeout=N` back out of the response. llama-server
 *  advertises `Keep-Alive: timeout=5, max=100` and really does close an idle
 *  connection after 5s, but Node keeps that socket in its free pool and
 *  happily hands it back out. The next request writes onto a socket the
 *  server has already torn down, and the client sees a RST before a single
 *  response byte arrives.
 *
 *  Measured against the real backend, 8 sequential streaming requests:
 *  implicit global agent → 4 ok / 4 failed ("socket hang up"); the same
 *  requests with keep-alive off → 8 ok / 0 failed. The failures are pure
 *  connection-reuse races: they surface in 0.0s, and llama-server's own log
 *  shows no task ever launched for them, so the request never reached
 *  inference at all.
 *
 *  This reached the user as `llamacli` randomly failing a turn with an
 *  unexplained network error, and — worse — the agent loop treats a chat
 *  failure as end-of-turn, so a failed retry looked like the model had simply
 *  stopped working.
 *
 *  Disabling keep-alive costs one TCP handshake per request, which is free on
 *  the loopback backend this is built for; the server was closing the
 *  connection anyway, so there is no reuse left to lose. */
const HTTP_AGENT = new Agent({ keepAlive: false });
// Found auditing for the same class of bug already fixed three times
// (run_shell's missing timeout, browser.ts's missing CDP timeout, the
// streaming max_tokens gap): every fetch() call in this file had no
// timeout at all. `tokenize()` in particular is called on EVERY turn
// (compactor.ts's estimateTokens(), via maybeCompact() before every
// single request) — a hang there freezes the entire agent loop
// permanently, with no recovery short of killing the process. Lightweight
// metadata endpoints (models/tokenize/props) don't need the shared
// inference slot on a real llama.cpp server, so they should always be
// fast; a generous bound still catches a genuinely stuck connection
// instead of waiting forever. Exported so tests can shrink them.
export let LIGHTWEIGHT_FETCH_TIMEOUT_MS = 30_000;
// Chat requests DO compete for the single inference slot and can
// legitimately queue behind other work for a while — a much longer bound,
// but still a bound, since "still queued" and "the connection itself is
// dead" must eventually be distinguishable from the caller's side.
export let CHAT_FETCH_TIMEOUT_MS = 120_000;
export function setFetchTimeoutsForTests(lightweightMs, chatMs) {
    LIGHTWEIGHT_FETCH_TIMEOUT_MS = lightweightMs;
    CHAT_FETCH_TIMEOUT_MS = chatMs;
}
/**
 * Any OpenAI-compatible /v1 endpoint: a locally spawned llama.cpp `llama-server`,
 * a remote llama-server, vLLM, LM Studio, or a real OpenAI-compatible account.
 * This is the single client used everywhere else in the codebase — swapping
 * backends is a config change (baseUrl/apiKey), never a code change.
 */
/** Distinguishes a deliberate cancel() from a real timeout on the same
 *  AbortController — both produce an identical AbortError otherwise,
 *  and the caller (loop.ts) needs to tell them apart to report a clean
 *  "[cancelled]" status instead of a scary-looking timeout/network error. */
const CANCELLED_REASON = "llamacli:cancelled-by-user";
export class OpenAICompatibleClient {
    baseUrl;
    apiKey;
    // Tracks whichever chat() request is currently in flight, so cancel() has
    // something to abort. Only ever one at a time in practice (the agent
    // loop is single-turn-at-a-time), so a single field is enough — no need
    // for a set/map of concurrent requests.
    currentChatController = null;
    constructor(baseUrl, apiKey = undefined) {
        this.baseUrl = baseUrl;
        this.apiKey = apiKey;
    }
    headers() {
        const h = { "Content-Type": "application/json" };
        if (this.apiKey)
            h.Authorization = `Bearer ${this.apiKey}`;
        return h;
    }
    /** Aborts the in-flight chat() request, if any — see ModelBackend.cancel
     *  doc comment. A no-op if nothing is currently in flight (e.g. the user
     *  pressed Esc between turns). */
    cancel() {
        this.currentChatController?.abort(CANCELLED_REASON);
    }
    /** Wraps fetch() with a real timeout — plain fetch() waits forever by
     *  default, which is exactly the gap described above. `controller`
     *  defaults to a fresh one for non-chat (lightweight metadata) calls;
     *  chat() passes its own so cancel() above can reach it. */
    async fetchWithTimeout(url, options, timeoutMs, label, controller = new AbortController()) {
        const timer = setTimeout(() => controller.abort(), timeoutMs);
        try {
            return await fetch(url, { ...options, signal: controller.signal, agent: HTTP_AGENT });
        }
        catch (err) {
            if (err?.name === "AbortError") {
                if (controller.signal.reason === CANCELLED_REASON)
                    throw new Error("cancelled by user");
                throw new Error(`${label} timed out after ${timeoutMs}ms`);
            }
            throw err;
        }
        finally {
            clearTimeout(timer);
        }
    }
    async listModels() {
        const res = await this.fetchWithTimeout(`${this.baseUrl}/v1/models`, { headers: this.headers() }, LIGHTWEIGHT_FETCH_TIMEOUT_MS, "listModels");
        if (!res.ok)
            throw new Error(`listModels failed: ${res.status} ${await res.text()}`);
        const json = (await res.json());
        return json.data.map((m) => m.id);
    }
    /** llama.cpp-server-specific endpoint (not all OpenAI-compatible servers
     *  have it) — callers must be ready for this to throw and fall back. */
    async tokenize(text) {
        const res = await this.fetchWithTimeout(`${this.baseUrl}/tokenize`, { method: "POST", headers: this.headers(), body: JSON.stringify({ content: text }) }, LIGHTWEIGHT_FETCH_TIMEOUT_MS, "tokenize");
        if (!res.ok)
            throw new Error(`tokenize failed: ${res.status} ${await res.text()}`);
        const json = (await res.json());
        return json.tokens.length;
    }
    /** Exact prompt token count: render through the server's own chat
     *  template first (`/apply-template`), then tokenize THAT — see
     *  ModelBackend.countPromptTokens for the measurements behind why
     *  tokenizing concatenated message text instead undercounts by ~19%
     *  and grows worse with conversation length. Throws for a backend
     *  without /apply-template; callers fall back. */
    async countPromptTokens(messages, tools) {
        const res = await this.fetchWithTimeout(`${this.baseUrl}/apply-template`, { method: "POST", headers: this.headers(), body: JSON.stringify(tools?.length ? { messages, tools } : { messages }) }, LIGHTWEIGHT_FETCH_TIMEOUT_MS, "applyTemplate");
        if (!res.ok)
            throw new Error(`applyTemplate failed: ${res.status} ${await res.text()}`);
        const { prompt } = (await res.json());
        if (typeof prompt !== "string")
            throw new Error("applyTemplate: response had no prompt field");
        return this.tokenize(prompt);
    }
    /** llama.cpp-server-specific endpoint — callers must be ready for this to
     *  throw and fall back to the configured value.
  
     *  Tries `/config` first (`model_info.n_ctx`), then `/props`
     *  (`default_generation_settings.n_ctx`). Neither endpoint is present in every
     *  build: the PrismML fork answers `/props` but 404s `/config`, and the stock
     *  build here registers `/props` with no `/config` route at all.
     *
     *  Getting this wrong is not cosmetic. When both lookups fail, callers fall
     *  back to `config.llama.contextSize ?? 8192`, so a server actually launched
     *  with `-c 32768` gets budgeted as 8192. Compaction then fires ~4x too early
     *  and its own summary request overruns the real limit — the compact/resume
     *  loop this fallback exists to prevent (see index.tsx on compaction firing
     *  "8x too eagerly"). */
    async getContextSize() {
        // Every failure mode here means "this endpoint did not tell us", never "stop".
        // A reverse proxy that answers `/config` with an HTML login page, a build
        // that 404s it, a fork that serves a different shape — all are answers, and
        // the other endpoint is still worth asking. Letting any of them escape threw
        // out of the `??` chain before the fallback ran, so a server whose `/props`
        // would have reported 40960 instead raised a JSON parse error and the caller
        // fell back to a hard-coded 8192.
        const read = async (path, pick) => {
            try {
                const res = await this.fetchWithTimeout(`${this.baseUrl}${path}`, { headers: this.headers() }, LIGHTWEIGHT_FETCH_TIMEOUT_MS, "getContextSize");
                if (!res.ok)
                    return null;
                return pick(await res.json()) ?? null;
            }
            catch (err) {
                // A malformed body is a shape mismatch, so keep looking on the other
                // endpoint. A transport failure is not: if the server is unreachable or
                // timing out, the second request will fail identically, and re-raising
                // preserves the diagnosis ("timed out") that the catch would otherwise
                // flatten into a generic "neither endpoint answered".
                if (/timed out|ECONNREFUSED|ENOTFOUND|EAI_AGAIN|ECONNRESET|fetch failed/i.test(err?.message ?? "")) {
                    throw err;
                }
                return null;
            }
        };
        const n_ctx = (await read("/config", (j) => j.model_info?.n_ctx)) ??
            (await read("/props", (j) => j.default_generation_settings?.n_ctx));
        if (!n_ctx)
            throw new Error("getContextSize: neither /config nor /props reported an n_ctx");
        return n_ctx;
    }
    async chat(req, onDelta, 
    // An ABSOLUTE wall-clock budget for the whole request — connection,
    // prefill, and every generated token — as opposed to the two timers
    // below it, which bound "time since the last thing happened" and so a
    // chatty-but-slow stream can run unbounded under both.
    //
    // Exists for the compaction summary (compactor.ts). Its latency is 100%
    // decode — prefill is served from the prompt cache — so the only way to
    // bound "how long does the user stare at [compaction]" is to bound the
    // generation itself. A token budget can't do that job: `max_tokens` is a
    // duration only once you know the machine's tok/s, and that varies ~8x
    // across the hardware this supports. Hitting the deadline returns
    // whatever text arrived (NOT an error) — see streamChat's deadlineHit
    // handling for why a partial answer is the right answer here, and why
    // that is safe only because the caller opted in by passing this.
    opts) {
        if (!req.stream || !onDelta) {
            // A deadline cannot be honored on the non-streaming path the way it is
            // below: the whole point is keeping the partial body, and a
            // `stream: false` response is one JSON document that only exists once
            // generation has finished. Refusing rather than silently ignoring it,
            // because a caller that believes it set a ceiling and silently didn't
            // gets exactly the unbounded wait it was trying to avoid.
            if (opts?.deadlineMs) {
                throw new Error(`chat: deadlineMs is not supported without streaming (stream: ${req.stream}, onDelta: ${Boolean(onDelta)})`);
            }
            const controller = new AbortController();
            this.currentChatController = controller;
            try {
                const res = await this.fetchWithTimeout(`${this.baseUrl}/v1/chat/completions`, { method: "POST", headers: this.headers(), body: JSON.stringify({ ...req, stream: false }) }, CHAT_FETCH_TIMEOUT_MS, "chat", controller);
                if (!res.ok)
                    throw new Error(`chat failed: ${res.status} ${await res.text()}`);
                return (await res.json());
            }
            finally {
                this.currentChatController = null;
            }
        }
        return this.streamChat(req, onDelta, opts?.deadlineMs);
    }
    /** Consumes an SSE stream and reassembles it into a single final response,
     *  while forwarding each delta to the caller for incremental rendering.
     *
     *  Enforces `req.max_tokens` itself, client-side, rather than trusting
     *  the server to stop generating once it's sent. Caught live: a real
     *  request with `max_tokens: 16384` kept streaming anyway, all the way
     *  past 45,000 tokens, only stopping once it physically ran out of
     *  context window (`truncated = 1`) — nearly 17 minutes pinning the
     *  single inference slot on one response. A direct curl reproduction
     *  confirmed `max_tokens` genuinely isn't honored for **streaming**
     *  requests on this llama.cpp build specifically (a `stream: false`
     *  request with the same field correctly stopped with
     *  `finish_reason: "length"` — this is a streaming-only gap, not a
     *  general backend bug). The max_tokens cap itself (loop.ts) was already
     *  correct; the request just can't rely on the server actually
     *  respecting it. */
    async streamChat(req, onDelta, deadlineMs) {
        const controller = new AbortController();
        // Set immediately (before the connection even completes) so cancel()
        // can interrupt a turn that's still only connecting, not just one
        // that's already streaming tokens.
        this.currentChatController = controller;
        // Guards only the CONNECTION phase (no response at all yet) — once
        // streaming genuinely starts, a real generation can legitimately run
        // long, and that's what the max_tokens-triggered abort further below
        // (reusing this same controller) is already responsible for bounding.
        // Requests do compete for the single inference slot and can queue for
        // a while under load, hence the longer CHAT_FETCH_TIMEOUT_MS bound
        // rather than the lightweight one.
        const connectTimer = setTimeout(() => controller.abort(), CHAT_FETCH_TIMEOUT_MS);
        let res;
        try {
            res = await fetch(`${this.baseUrl}/v1/chat/completions`, {
                method: "POST",
                headers: this.headers(),
                body: JSON.stringify({ ...req, stream: true }),
                signal: controller.signal, // node-fetch's AbortSignal type predates the global one
                agent: HTTP_AGENT, // see HTTP_AGENT — keep-alive reuse fails against llama-server
            });
        }
        catch (err) {
            if (err?.name === "AbortError") {
                if (controller.signal.reason === CANCELLED_REASON)
                    throw new Error("cancelled by user");
                throw new Error(`chat stream connection timed out after ${CHAT_FETCH_TIMEOUT_MS}ms`);
            }
            throw err;
        }
        finally {
            clearTimeout(connectTimer);
        }
        if (!res.ok || !res.body) {
            throw new Error(`chat stream failed: ${res.status} ${await res.text()}`);
        }
        let content = "";
        const toolCalls = {};
        let finishReason = "stop";
        let buffer = "";
        // Counts streamed delta *events*, not exact tokens — llama.cpp emits
        // one SSE chunk per generated token in the normal (non-batched) case,
        // so this is an accurate enough proxy for a safety cap: better to cut
        // a response very slightly early/late than not cut it off at all,
        // which is what relying solely on the server did.
        let deltaCount = 0;
        let clientCapped = false;
        // Separate from the connection-phase timer above: once streaming
        // genuinely starts, this guards against the body just going silent —
        // no more chunks, no error, no [DONE], never reaching max_tokens
        // either — which would otherwise leave the `for await` loop waiting
        // forever. Re-armed on every chunk received, so a normal (even slow)
        // generation that's still actively producing output is never cut off.
        let idleTimedOut = false;
        let idleTimer;
        const armIdleTimer = () => {
            if (idleTimer)
                clearTimeout(idleTimer);
            idleTimer = setTimeout(() => {
                idleTimedOut = true;
                controller.abort();
            }, CHAT_FETCH_TIMEOUT_MS);
        };
        armIdleTimer();
        // The absolute ceiling. Started AFTER the connection is established, so it
        // measures generation time rather than including however long the request
        // spent queued behind other work on a busy single-slot server — queueing is
        // the caller's business (CHAT_FETCH_TIMEOUT_MS / the retry loop in
        // loop.ts), and folding it in here would make the deadline fire on a
        // request that never even started generating, which is not what a caller
        // asking to bound "how long the answer takes" means.
        //
        // Deliberately NOT re-armed per chunk, unlike armIdleTimer above: this one
        // is a total budget, and re-arming it would silently turn it back into a
        // second copy of the idle timer.
        let deadlineHit = false;
        const deadlineTimer = deadlineMs && deadlineMs > 0
            ? setTimeout(() => {
                deadlineHit = true;
                controller.abort();
            }, deadlineMs)
            : undefined;
        try {
            for await (const chunk of res.body) {
                armIdleTimer();
                buffer += chunk.toString("utf8");
                const lines = buffer.split("\n");
                buffer = lines.pop() ?? "";
                for (const line of lines) {
                    const trimmed = line.trim();
                    if (!trimmed.startsWith("data:"))
                        continue;
                    const data = trimmed.slice(5).trim();
                    if (data === "[DONE]")
                        continue;
                    // A single unparseable `data:` line (a keepalive/comment some
                    // proxies inject, a chunk split across a read boundary in an
                    // unexpected way) previously threw straight out of this loop —
                    // discarding every token already streamed successfully before it
                    // and failing the whole turn over one cosmetic line. Skip just
                    // that line; there's nothing this line could contain that's worth
                    // losing an otherwise-successful response over.
                    let parsed;
                    try {
                        parsed = JSON.parse(data);
                    }
                    catch {
                        continue;
                    }
                    // The initial HTTP response can be 200 OK (so the `res.ok` check
                    // above passes) with the actual failure only showing up later, as
                    // an SSE data chunk shaped like `{"error": {...}}` with no
                    // `choices` field at all — e.g. llama-server discovering mid-
                    // generation that it's now over the context window, after having
                    // already started streaming tokens. Reported live: this crashed
                    // with "Cannot read properties of undefined (reading '0')" from
                    // blindly indexing `.choices[0]` on a chunk that had no `choices`.
                    // Surface it as a real, readable error instead of letting an
                    // unrelated line of code choke on the malformed shape.
                    if (parsed.error) {
                        const errBody = parsed.error;
                        const err = new Error(`chat stream error: ${errBody.message ?? JSON.stringify(errBody)}`);
                        // Reported live: a tool call cut off mid-JSON by max_tokens
                        // (e.g. a write_file call generating a long file) triggers
                        // exactly this error — the server discovers the accumulated
                        // arguments don't parse as valid JSON only once generation has
                        // already finished. Everything streamed before that point is
                        // otherwise thrown away with it, even though it's real,
                        // already-generated content the caller could recover and save
                        // instead of asking the model to regenerate the whole thing
                        // from scratch (unreliable — a model can just produce the
                        // identical oversized content again and hit the identical
                        // wall). Attaching what was accumulated so far lets the
                        // caller (loop.ts) salvage it.
                        err.partialToolCalls = Object.values(toolCalls);
                        throw err;
                    }
                    if (!Array.isArray(parsed.choices))
                        continue;
                    onDelta(parsed);
                    const choice = parsed.choices[0];
                    if (!choice)
                        continue;
                    if (choice.delta.content) {
                        content += choice.delta.content;
                        deltaCount++;
                    }
                    // Chain-of-thought, streamed by llama-server as its own field
                    // (NOT `content`) when the chat template preserves reasoning.
                    // Measured directly against the real backend: a request whose
                    // whole 420-token budget went to reasoning produced 420 of
                    // these deltas and zero `content`/`tool_calls` deltas — and
                    // because nothing here looked at this field, llamacli rendered
                    // absolutely nothing for the entire time, which is what the
                    // repeated "it looks stuck / 멈춘 것 같다" reports actually
                    // were. It also has to count toward deltaCount: these tokens
                    // are just as real against max_tokens as any other, and the
                    // client-side cap (see streamChat's doc comment) silently
                    // stopped bounding anything at all while the model was thinking.
                    const reasoning = choice.delta.reasoning_content;
                    if (typeof reasoning === "string" && reasoning.length > 0) {
                        deltaCount++;
                    }
                    if (choice.delta.tool_calls) {
                        for (const tc of choice.delta.tool_calls) {
                            const idx = tc.index ?? 0;
                            const slot = toolCalls[idx] ?? { id: "", name: "", arguments: "" };
                            if (tc.id)
                                slot.id = tc.id;
                            if (tc.function?.name)
                                slot.name += tc.function.name;
                            if (tc.function?.arguments)
                                slot.arguments += tc.function.arguments;
                            toolCalls[idx] = slot;
                        }
                        deltaCount++;
                    }
                    if (choice.finish_reason)
                        finishReason = choice.finish_reason;
                }
                if (req.max_tokens && deltaCount >= req.max_tokens) {
                    clientCapped = true;
                    finishReason = "length";
                    controller.abort();
                    break;
                }
            }
        }
        catch (err) {
            // AbortError from our own controller.abort() is expected in three
            // cases: the max_tokens cap was hit mid-chunk (clientCapped), the
            // stream went idle too long (idleTimedOut), or the user cancelled
            // the turn (cancel(), checked via the abort reason) — none of these
            // three is a real failure in the network sense. Anything else still
            // propagates.
            if (err?.name === "AbortError" && controller.signal.reason === CANCELLED_REASON) {
                throw new Error("cancelled by user");
            }
            if (err?.name === "AbortError" && idleTimedOut) {
                throw new Error(`chat stream went idle (no new data) for over ${CHAT_FETCH_TIMEOUT_MS}ms`);
            }
            // The deadline, like the max_tokens cap, is an intended ending rather
            // than a failure: fall through to returning the partial text assembled
            // so far. The caller asked for a ceiling and opted into truncation by
            // passing deadlineMs, and for the compaction summary a shorter answer is
            // a strictly better outcome than no compaction at all.
            if (!(clientCapped && err?.name === "AbortError") && !(deadlineHit && err?.name === "AbortError")) {
                throw err;
            }
            if (deadlineHit)
                finishReason = "length";
        }
        finally {
            if (idleTimer)
                clearTimeout(idleTimer);
            if (deadlineTimer)
                clearTimeout(deadlineTimer);
            this.currentChatController = null;
        }
        // When the client-side max_tokens cap above cuts the stream (the usual
        // way generation ends on this build, since the server ignores
        // max_tokens when streaming), the server never gets to send its own
        // "Failed to parse tool call arguments" error chunk: we hung up first.
        // A tool call cut off mid-arguments then came back as a normal-looking
        // reply. loop.ts put it into the history, and from then on EVERY
        // request failed: llama-server JSON-parses the tool_calls arguments of
        // every INPUT message while applying the chat template
        // (common/chat.cpp func_args_not_string), so the unterminated string
        // sitting in history made each retry fail instantly, with the model
        // never even called. Seen live: 6 attempts (apply-template + chat
        // each, 12 server exceptions) burned through in 1.5s, then a hard
        // error. Raise the same error the server would have, with the partial
        // calls attached, so loop.ts's salvage/chunking recovery handles it
        // and the broken call never enters the history.
        const unparseable = Object.values(toolCalls).find((tc) => {
            if (!tc.arguments)
                return false;
            try {
                JSON.parse(tc.arguments);
                return false;
            }
            catch {
                return true;
            }
        });
        if (unparseable) {
            // The tail keeps loop.ts's verbatim-repeat detection meaningful (an
            // identical regeneration cut at the identical point yields an
            // identical message) without embedding the whole generated file.
            const err = new Error(`Failed to parse tool call arguments as JSON: the reply stopped (finish_reason=${finishReason ?? "unknown"}) ` +
                `after ${unparseable.arguments.length} characters of ${unparseable.name} arguments, ending with ` +
                JSON.stringify(unparseable.arguments.slice(-60)));
            err.partialToolCalls = Object.values(toolCalls);
            throw err;
        }
        const tool_calls = Object.values(toolCalls).map((tc) => ({
            id: tc.id,
            type: "function",
            function: { name: tc.name, arguments: tc.arguments },
        }));
        return {
            choices: [
                {
                    message: {
                        role: "assistant",
                        content: content || null,
                        ...(tool_calls.length ? { tool_calls } : {}),
                    },
                    finish_reason: finishReason,
                },
            ],
            // Set only when WE ended it via the deadline. `finish_reason` is
            // "length" for the deadline, the client-side max_tokens cap, and the
            // server honoring max_tokens alike, so this is the only thing that
            // separates "out of clock" from "the model wrote what it was going to".
            // Callers that don't care about the distinction never read it.
            ...(deadlineHit ? { deadlineHit: true } : {}),
        };
    }
}
