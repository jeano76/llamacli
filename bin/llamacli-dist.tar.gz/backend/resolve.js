import { stat } from "node:fs/promises";
import { formatBytes } from "../setup/download.js";
import { LlamaServerManager } from "./llamaServer.js";
import { OpenAICompatibleClient } from "./openaiClient.js";
import { discoverRunningServer, COMMON_PORTS } from "./detect.js";
import { detectRunningServerPorts } from "../setup/modelSwitch.js";
import { probeBackendHealth, describeUnhealthyBackend } from "./healthCheck.js";
import { ensureLocalStack, writeConfig, DEFAULT_MODELS_DIR, } from "../setup/bootstrap.js";
import { probeModelCompatibility, looksLikeUnsupportedModelFormat, findLlamaServer, } from "../setup/llamaCpp.js";
const GiB = 1024 ** 3;
/** The port this project already recorded, if it names one.
 *
 *  `COMMON_PORTS` is a heuristic for a project with no config: it guesses where
 *  a server *might* be. Once a config exists it is no longer a guess — it is a
 *  record of where the server actually was, and on this machine it was 8084,
 *  which is not in the heuristic list. Probing only the list meant discovery
 *  reported "nothing is running" about a server that was up and serving, and the
 *  fallback spawned a SECOND llama-server that then OOMed: the first one already
 *  held 7.3 GB of an 8 GB card.
 *
 *  So the recorded port is probed FIRST, and the heuristic list follows as a
 *  fallback for the case where the recorded server has since died. Order
 *  matters — `discoverRunningServer` takes the first responder. */
export function configuredPort(config) {
    if (config.backend === "local-llama") {
        const port = config.llama?.port;
        return Number.isFinite(port) && port > 0 ? port : null;
    }
    // openai-compatible: the port lives in the URL, and may be absent (default 80/443).
    if (!config.baseUrl)
        return null;
    try {
        const port = Number(new URL(config.baseUrl).port);
        return Number.isFinite(port) && port > 0 ? port : null;
    }
    catch {
        return null;
    }
}
export async function resolveBackend(opts) {
    const { projectRoot, config, log } = opts;
    // ── Case 1: is a server already answering? ─────────────────────────────────
    // Asked before anything else touches the disk or the network. A server that
    // is up is a complete answer: it knows its own endpoint, its own port and its
    // own model, all three of which are exactly what we would otherwise have to
    // decide ourselves.
    //
    // `discoverRunningServer`, not a single fast probe: llama-server binds its
    // port before the model is resident and answers nothing until the weights are
    // loaded. A fast probe cannot tell that apart from "nothing is running", and
    // answering it wrongly is how a second llama-server used to get spawned beside
    // a healthy one.
    const discover = opts.discover ??
        (() => {
            const recorded = configuredPort(config);
            // Order: the recorded port, then wherever a llama-server process is ACTUALLY
            // listening, then the heuristic list. The middle one is what finds a server
            // started by hand on a port nobody wrote down (8084 here), which neither the
            // record nor the guess contains.
            return detectRunningServerPorts().then((live) => {
                const ordered = [...(recorded === null ? [] : [recorded]), ...live, ...COMMON_PORTS];
                return discoverRunningServer("127.0.0.1", [...new Set(ordered)]);
            });
        });
    // A download that reported progress by rewriting one terminal line would
    // corrupt the TUI rendering into the same screen — Ink owns those bytes here,
    // and a bare `\r\x1b[2K` from the installer would cut its output in half. So
    // the reporter is routed through the TUI log like every other line, throttled
    // to whole percents: a 20 GB transfer updates several times a second, and an
    // unthrottled status line would push everything above it out of the log.
    let lastPercent = -1;
    let lastBytes = 0;
    const progress = (_default) => (p) => {
        // Whole percents only: a 20 GB transfer calls this several times a second,
        // and an unthrottled status line would push every earlier line out of the
        // TUI's log. `percent` is -1 until the total size is known, so that case
        // falls back to a fixed 1 GiB interval rather than emitting -1 forever.
        if (p.percent >= 0) {
            const percent = Math.floor(p.percent);
            if (percent === lastPercent)
                return;
            lastPercent = percent;
            lastBytes = 0;
            log(`모델 다운로드 중… ${percent}%`);
            return;
        }
        if (p.receivedBytes - lastBytes < GiB)
            return;
        lastBytes = p.receivedBytes;
        log(`모델 다운로드 중… ${formatBytes(p.receivedBytes)}`);
    };
    const discovery = await discover();
    if (discovery.kind === "found") {
        const server = discovery.server;
        const port = Number(new URL(server.baseUrl).port);
        const adopted = new OpenAICompatibleClient(server.baseUrl);
        // "It answered" is not "it works". A server serving unusable weights loads,
        // reports its model, accepts every request and returns HTTP 200 with a
        // perfectly well-formed completion full of nothing — so case 1 adopted one
        // for seven hours before anyone noticed, and nothing between the model file
        // and the screen ever asked whether the output was language.
        const health = await (opts.probe ?? probeBackendHealth)(adopted);
        if (health.verdict === "garbage") {
            const reason = describeUnhealthyBackend(`${server.baseUrl} (모델 ${server.model})`, health);
            log(reason);
            // Reported, not fatal to the app: `usable` is true because a real server
            // IS answering here — it just answers with garbage. The TUI comes up and
            // the reason is on screen where the user can act on it. Deliberately NOT
            // falling through to case 2 — the broken server is still holding the model
            // in VRAM, and spawning a second one beside it is the out-of-memory this
            // module's ordering exists to avoid. It also has to stay non-fatal: exiting
            // would strand a running server the user can no longer reach.
            return { kind: "unresolved", backend: adopted, reason, usable: true };
        }
        log(`이미 구동 중인 서버에 연결합니다: ${server.baseUrl} (모델 ${server.model})`);
        // Recorded so the next launch is a straight read of a known-good endpoint
        // instead of a fresh scan. Only when the config does not already say this,
        // so a user's hand-written baseUrl is never overwritten by a probe result.
        await persistAdoption(projectRoot, config, server.baseUrl, server.model).catch(() => { });
        return { kind: "adopted", backend: adopted, baseUrl: server.baseUrl, model: server.model, port };
    }
    if (discovery.kind === "loading") {
        // The port is HELD by a server mid-load. Binding a different one here is the
        // exact failure this module exists to prevent — the loading server already
        // holds most of the card. So we point at it and let the agent loop's
        // existing transient-failure retry cover the wait. It starts answering on
        // its own; no second process, no extra VRAM.
        const waitedSec = Math.round(discovery.waitedMs / 1000);
        log(`${discovery.baseUrl} 서버가 아직 모델을 불러오는 중입니다 (${waitedSec}초 대기). ` +
            `두 번째 서버를 띄우지 않고 이 서버를 사용합니다.`);
        await persistAdoption(projectRoot, config, discovery.baseUrl, undefined).catch(() => { });
        return {
            kind: "adopted",
            backend: new OpenAICompatibleClient(discovery.baseUrl),
            baseUrl: discovery.baseUrl,
            // Unknown until the server answers; config.ts re-reads it live on every
            // load, so the recorded value is only a placeholder.
            model: config.model,
            port: discovery.port,
        };
    }
    if (discovery.kind === "stub") {
        // A test double holds the port: the API answers, the weights do not exist.
        // Deliberately NOT falling through to case 2 — the port is not ours to take,
        // and starting a real second llama-server beside it is the OOM this module's
        // ordering exists to avoid.
        //
        // Same shape as the "garbage" case above, and for the same reason
        // (`usable: true`): something IS answering, so the app comes up and puts the
        // reason on screen rather than exiting and stranding it. The difference is
        // that the garbage verdict is caught by SENDING a prompt and asking whether
        // the reply is language — which a fixture returning valid Korean
        // ("가짜 응답입니다.") passes. A missing weights file cannot be argued
        // around, which is why the stub check exists alongside it rather than
        // instead of it.
        log(discovery.reason);
        return {
            kind: "unresolved",
            backend: new OpenAICompatibleClient(discovery.baseUrl),
            reason: discovery.reason,
            usable: true,
        };
    }
    // ── Case 2: installed, recorded, but not running → start it ────────────────
    // Deliberately checked BEFORE the installer, so a machine that already has
    // both a binary and a model never reaches the Hub.
    const recorded = config.llama;
    // The recorded model path is taken from EITHER `llama.modelPath` or the
    // top-level `model`, whichever actually points at a file.
    //
    // Requiring `llama.modelPath` specifically sent configs to the installer
    // unnecessarily. The bootstrap owns `llama.modelPath` and had left it as the
    // empty string while the model the user was actually running lived in the
    // top-level `model` key — a shape seen live on a project whose config said
    // `backend: openai-compatible`, `llama.modelPath: ""` and a real
    // `model: /media/.../Ternary-Bonsai-2-27B-PTQ1_0.gguf`. Because the gate also
    // required `backend === "local-llama"`, neither the running server nor the
    // recorded weights were consulted: it announced "llama.cpp is not installed",
    // ran the installer, failed, and then spawned a server with an empty model
    // path. `openai-compatible` is not a reason to ignore a model that is right
    // there in the config.
    const recordedModel = typeof recorded?.modelPath === "string" && (await fileSize(recorded.modelPath)) > 0
        ? recorded.modelPath
        : typeof config.model === "string" && (await fileSize(config.model)) > 0
            ? config.model
            : undefined;
    if (recorded?.binPath && recordedModel) {
        // Rebuilt as a full LlamaServerConfig rather than passed through: the config
        // type allows `host` to be absent, and the spawned process has to be told
        // explicitly. 127.0.0.1, not 0.0.0.0 - the server is for this session.
        // `modelPath` is set explicitly rather than inherited, because this branch
        // is exactly the case where the recorded one was unusable.
        const startCfg = { ...recorded, host: "127.0.0.1", modelPath: recordedModel };
        const port = recorded.port;
        log(`설치된 llama-server 를 ${port} 포트에서 시작합니다: ${recorded.binPath}`);
        const started = await startWithCompatibleFallback(startCfg, {
            registerCleanup: opts.registerCleanup,
            log,
            probeModel: opts.probeModel,
            find: opts.findLlamaServer,
        });
        if (started.ok) {
            const spawned = new OpenAICompatibleClient(started.baseUrl);
            // Same check as case 1, and for the same reason: a config that points
            // at a corrupt model file produces a server that loads and answers just
            // as convincingly as a good one. This one is nearly free - the spawn
            // path already waited out a multi-minute model load, so a single small
            // request adds nothing to what the user is waiting for.
            const health = await (opts.probe ?? probeBackendHealth)(spawned);
            if (health.verdict === "garbage") {
                const reason = describeUnhealthyBackend(`${started.baseUrl} (모델 ${recordedModel})`, health);
                log(reason);
                // Same reasoning as case 1: the server is up and ours, so the session
                // comes up with the reason visible rather than exiting on the user.
                return { kind: "unresolved", backend: spawned, reason, usable: true };
            }
            return {
                kind: "spawned",
                backend: spawned,
                stop: started.stop,
                port,
                modelPath: recordedModel,
            };
        }
        // A spawn failure is NOT fatal, and NOT a reason to fall through to the
        // installer: the binary and the model are both on disk and known, so a
        // rebuild would burn 10-40 minutes to fix a port that was busy or a card
        // that was full. Returning here rather than falling through is the point -
        // case 3 must be reached only when something is genuinely MISSING, never
        // when something is present and merely refused to start.
        //
        // The reason names the actual situation rather than assuming the common
        // one, and the two failure kinds get different text because they have
        // nothing else in common.
        //
        // A build mismatch is NOT a port problem. Telling that user the port might
        // be busy sends them to edit a setting that was never involved, which is
        // exactly what happened here: the real cause was a stock llama.cpp build
        // (ggml types 0-42) being handed a ternary 1-bit model, and it was reported
        // as "the port may be in use" while a working fork sat on the same disk.
        // The binary that ACTUALLY failed, which is not necessarily the one in the
        // config. On a build mismatch the fallback may have substituted a different
        // llama-server, and if that one then failed — a full card, say — reporting
        // the configured path describes a binary that never ran. Observed directly:
        // the substitution found a working fork, the fork then hit
        // "cudaMalloc failed: out of memory", and the message named the stock build
        // that had been rejected two steps earlier.
        const failedBin = started.ok ? recorded.binPath : started.binary;
        const substituted = failedBin !== recorded.binPath;
        const binIsBare = !failedBin.includes("/");
        const cause = started.kind === "build-mismatch"
            ? `설정된 llama-server 가 이 모델의 양자화 형식을 읽지 못합니다 (${started.detail}). ` +
                `이것은 포트나 GPU 메모리 문제가 아니며, 모델도 손상되지 않았습니다. ` +
                `.llamacli/config.yaml 의 llama.binPath 를 ternary/1-bit 를 지원하는 빌드로 바꾸세요. `
            : binIsBare
                ? `경로에 있는 이름이라 PATH에서 찾지 못한 것 같습니다. .llamacli/config.yaml 의 llama.binPath 에 전체 경로(예: /home/.../llama-server)를 적으세요. `
                : `포트(${port})가 사용 중이거나 GPU 메모리가 부족할 수 있습니다. ` +
                    (substituted ? ` (설정된 경로 대신 대체 빌드로 시도했습니다) ` : ``);
        return {
            kind: "unresolved",
            backend: fallbackClient(config),
            reason: `${failedBin} 를 ${port} 포트에서 시작하지 못했습니다. ` +
                `llama.cpp 와 모델은 설치되어 있으므로 다시 설치하지 않았습니다 - ` +
                cause +
                `서버를 직접 실행한 뒤 다시 시도하세요.`,
            // Nothing is listening on that endpoint - the process refused to start -
            // so there is no session to hand the user. This is one of the outcomes
            // that must NOT come up as a ready-looking prompt.
            usable: false,
        };
    }
    if (recorded?.modelPath)
        log(`설정된 모델 파일이 없습니다: ${recorded.modelPath}`);
    // ── Case 3: not installed (or no model recorded) → install + configure ─────
    // The one case that may touch the network, and the only one that can take
    // minutes. `ensureLocalStack` degrades instead of throwing, so a failure here
    // still yields a usable report and a running app.
    log("llama.cpp 가 설치되어 있지 않아 설치와 모델 준비를 시작합니다. 첫 실행이라 시간이 걸릴 수 있습니다.");
    const bootstrap = opts.bootstrap ?? ensureLocalStack;
    let report;
    try {
        report = await bootstrap({
            projectRoot,
            modelsDir: DEFAULT_MODELS_DIR,
            log,
            onProgress: progress,
            ...opts.bootstrapOptions,
        });
    }
    catch (err) {
        // Should not happen (ensureLocalStack returns a report), but a throw here
        // must not take down the session: the app starts on the recorded config.
        const reason = err instanceof Error ? err.message : String(err);
        return { kind: "unresolved", backend: fallbackClient(config), reason, usable: false };
    }
    for (const error of report.errors)
        log(`[설정 경고] ${error}`);
    // The bootstrap may have found a server of its own (case 1 all over again, in
    // the window between our probe and its own), or ended up attaching rather
    // than building. Both are reported through `config`, so the decision is read
    // back from there instead of being re-derived.
    const written = (report.config ?? {});
    if (written.backend === "openai-compatible" && typeof written.baseUrl === "string") {
        const baseUrl = written.baseUrl;
        log(`준비가 끝났습니다. ${baseUrl} 에 연결합니다.`);
        return {
            kind: "adopted",
            backend: new OpenAICompatibleClient(baseUrl),
            baseUrl,
            model: typeof written.model === "string" ? written.model : config.model,
            port: Number(new URL(baseUrl).port) || config.llama?.port || 8080,
        };
    }
    const llama = written.llama;
    if (typeof llama?.binPath === "string" && typeof llama?.modelPath === "string") {
        const cfg = {
            binPath: llama.binPath,
            modelPath: llama.modelPath,
            host: "127.0.0.1",
            port: typeof llama.port === "number" ? llama.port : 8080,
            // Respect the operator's config rather than always spawning at a
            // fixed 8192. The compaction thresholds (see index.tsx) are derived
            // from this, so an explicit contextSize in config.yaml must not be
            // silently dropped when we launch the server ourselves.
            contextSize: typeof llama.contextSize === "number" ? llama.contextSize : 8192,
            threads: typeof llama.threads === "number" ? llama.threads : 4,
            gpuLayers: typeof llama.gpuLayers === "number" ? llama.gpuLayers : 0,
            threadsBatch: llama.threadsBatch,
            batchSize: llama.batchSize,
            ubatchSize: llama.ubatchSize,
            cpuMoeLayers: llama.cpuMoeLayers,
            flashAttn: llama.flashAttn,
            cacheTypeK: llama.cacheTypeK,
            cacheTypeV: llama.cacheTypeV,
            parallel: llama.parallel,
        };
        const started = await startWithCompatibleFallback(cfg, {
            registerCleanup: opts.registerCleanup,
            log,
            probeModel: opts.probeModel,
            find: opts.findLlamaServer,
        });
        if (started.ok) {
            log(`준비가 끝났습니다. ${started.baseUrl} 에서 llama-server 를 구동했습니다.`);
            return { kind: "spawned", backend: new OpenAICompatibleClient(started.baseUrl), stop: started.stop, port: cfg.port, modelPath: cfg.modelPath };
        }
    }
    return {
        kind: "unresolved",
        backend: fallbackClient(config),
        reason: report.errors[0] ?? "llama.cpp 와 모델을 준비하지 못했습니다. .llamacli/config.yaml 을 직접 설정하세요.",
        // The install itself did not complete, so there is no model and no server:
        // prompt mode here would be a shell around nothing.
        usable: false,
    };
}
/** Spawns a llama-server and waits for it to answer. Reports failure instead
 *  of throwing: "could not start" is a reportable state, not a crash, and each
 *  caller here has a sensible fallback that is better than a stack trace. */
async function tryStart(cfg, registerCleanup, probeModel = probeModelCompatibility) {
    // A recorded binPath is trusted until it proves otherwise, and this is where
    // it is proved. Two llama.cpp builds coexist on this machine — a stock one
    // whose ggml type registry stops at 42, and a fork that reads ternary 1-bit
    // quants — and a config recorded against the wrong one produced:
    //
    //   tensor 'output.weight' has invalid ggml type 143. should be in [0, 43)
    //
    // which is not a corrupt model and not a busy port. Spawning to find that out
    // costs a model load and dumps a raw llama-server log at the user, so the
    // compatibility question is asked first, and cheaply.
    const compat = await probeModel(cfg.binPath, cfg.modelPath);
    if (!compat.ok && looksLikeUnsupportedModelFormat(compat.error)) {
        const line = (compat.error ?? "").split("\n").find((l) => /invalid ggml type/i.test(l))?.trim() ??
            "이 모델의 양자화 형식을 지원하지 않음";
        process.stderr.write(`[llamacli] ${cfg.binPath} 는 이 모델의 양자화 형식을 읽지 못합니다: ${line}\n`);
        return { ok: false, kind: "build-mismatch", binary: cfg.binPath, detail: line };
    }
    const manager = new LlamaServerManager(cfg);
    try {
        await manager.start();
    }
    catch (err) {
        const detail = err instanceof Error ? err.message : String(err);
        process.stderr.write(`[llamacli] llama-server 시작 실패: ${detail}\n`);
        return { ok: false, kind: "spawn-failed", binary: cfg.binPath, detail };
    }
    const stop = () => manager.stop();
    // Registered so the model is released from VRAM on every exit path — a
    // surviving server is the direct cause of the next session OOMing.
    registerCleanup?.(stop);
    return { ok: true, baseUrl: manager.baseUrl, stop };
}
/**
 * Starts the configured binary, and on a build mismatch goes looking for one
 * that can actually read the model before giving up.
 *
 * The fallback is the difference between a dead end and a working session. The
 * machine this was written for has both builds on disk: a stock `~/llama.cpp`
 * whose ggml type registry stops at 42, and a fork that reads ternary 1-bit
 * quants and was serving the same model on another port at the time. A config
 * recorded against the wrong one could only report "this binary is wrong" —
 * true, and not actionable, when the working binary is one search away.
 *
 * Only the mismatch case retries. A spawn failure (busy port, full card) is not
 * fixed by a different binary, and searching there would add a filesystem walk
 * to a failure the user is already waiting on.
 */
export async function startWithCompatibleFallback(cfg, opts = {}) {
    const start = opts.tryStartImpl ?? ((c, r) => tryStart(c, r, opts.probeModel));
    const first = await start(cfg, opts.registerCleanup);
    if (first.ok || first.kind !== "build-mismatch")
        return first;
    const log = opts.log ?? (() => { });
    const find = opts.find ?? findLlamaServer;
    const probeModel = opts.probeModel ?? probeModelCompatibility;
    // The recorded binary is removed from the environment before searching, so
    // the search cannot simply return the same build again: env overrides are
    // ranked first, and this one is known to be the wrong build.
    const env = { ...(opts.env ?? process.env) };
    delete env.LLAMACLI_LLAMA_SERVER;
    delete env.LLAMA_SERVER_BIN;
    const alt = await find({ env, modelPath: cfg.modelPath, probeModel }).catch(() => null);
    const replacement = alt?.location?.binPath;
    if (!replacement || replacement === first.binary) {
        const skipped = [...new Set(alt?.rejectedForModel ?? [])];
        log(`이 모델을 읽을 수 있는 llama-server 빌드를 찾지 못했습니다` +
            (skipped.length > 0 ? ` (모델 미지원으로 제외됨: ${skipped.join(", ")})` : "") +
            `. 확인한 위치는 환경변수 지정값, PATH, ~/llama.cpp 및 ~/.llamacli/llama.cpp 빌드, systemd 사용자 유닛입니다 — ` +
            `그 밖의 위치에 있는 llama.cpp 빌드는 이 검색이 자동으로 찾지 못합니다. ` +
            `해당 경로를 .llamacli/config.yaml 의 llama.binPath 에 직접 적으세요.`);
        return first;
    }
    log(`${first.binary} 는 이 모델의 양자화 형식을 읽지 못합니다 — 사용할 수 있는 ${replacement} 로 다시 시도합니다.`);
    const second = await start({ ...cfg, binPath: replacement }, opts.registerCleanup);
    if (second.ok)
        log(`llama-server 를 대체 빌드로 시작했습니다: ${replacement}`);
    return second;
}
/** The endpoint to use when nothing could be prepared. Deliberately the
 *  recorded one rather than a guess, so the failure is "that server is not
 *  answering" — which is actionable — instead of ECONNREFUSED against an
 *  invented port. */
function fallbackClient(config) {
    if (config.backend === "openai-compatible" && config.baseUrl) {
        return new OpenAICompatibleClient(config.baseUrl, config.apiKey);
    }
    const port = config.llama?.port ?? 8080;
    return new OpenAICompatibleClient(`http://127.0.0.1:${port}`, config.apiKey);
}
/** Records an adopted endpoint, preserving every other key.
 *
 *  Only writes when it would actually change something: this runs on EVERY
 *  launch against case 1, and rewriting config.yaml each time would churn a
 *  user-reviewed file for no gain. A config already pointing at this endpoint is
 *  left completely alone. */
async function persistAdoption(projectRoot, config, baseUrl, model) {
    if (config.backend === "openai-compatible" && config.baseUrl === baseUrl)
        return;
    if (config.backend === "local-llama" && !config.llama)
        return;
    const next = {
        backend: "openai-compatible",
        baseUrl,
        // `model` is left out when unknown: the server is the source of truth and
        // config.ts re-reads it live, so recording a guess would only be stale.
        ...(model ? { model } : config.model ? { model: config.model } : {}),
    };
    await writeConfig(projectRoot, next);
}
/** Size of a file, or 0 when it cannot be read. Zero is the load-bearing value:
 *  a config pointing at a path that no longer exists (deleted to reclaim disk,
 *  moved to another machine) must read as "no model", not as "model of size 0"
 *  — which the installer would then try to use and fail to load. */
async function fileSize(path) {
    try {
        return (await stat(path)).size;
    }
    catch {
        return 0;
    }
}
