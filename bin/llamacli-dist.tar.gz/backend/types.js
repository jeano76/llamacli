// OpenAI Chat Completions-compatible wire types (subset used by llamacli).
export {};
