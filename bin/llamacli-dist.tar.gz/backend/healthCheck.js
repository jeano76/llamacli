/** Deliberately not a word: no real model has a reason to emit it, and no
 *  chat template or system prompt is going to contain it by accident. */
const PROBE_SENTINEL = "ZQXVKJ";
/** Enough for the echo plus a model's typical "Sure! **ZQXVKJ**" wrapping, and
 *  small enough that the probe costs ~2s on the local backend. */
const PROBE_MAX_TOKENS = 48;
/** Case- and punctuation-insensitive containment. A model that answers
 *  `"ZQXVKJ."` or `**ZQXVKJ**` passed; one that answers something else didn't. */
function echoesSentinel(text) {
    const norm = (s) => s.replace(/[^a-z0-9]/gi, "").toUpperCase();
    return norm(text).includes(norm(PROBE_SENTINEL));
}
/** Trimmed for display, and bounded: a garbage model can produce a very long
 *  run of it, and this string goes into a status line in the TUI log. */
function summarize(text) {
    const collapsed = text.replace(/\s+/g, " ").trim();
    return collapsed.length > 120 ? `${collapsed.slice(0, 120)}…` : collapsed;
}
/**
 * One tiny deterministic request. Never throws — an unreachable backend is
 * reported as `unknown`, not as a broken model.
 *
 * Two request fields are load-bearing:
 *
 *  - `chat_template_kwargs: { enable_thinking: false }`. A reasoning model
 *    otherwise spends the entire budget on invisible `reasoning_content` and
 *    returns an empty `content`. Measured on this project's own backend with
 *    the budget left at 12,288: 73,175 characters of reasoning, zero
 *    characters of answer. An empty reply would then read as "broken" for a
 *    perfectly healthy model, so thinking is turned off explicitly.
 *  - `temperature: 0`. Greedy, so the verdict does not flap between runs on
 *    the same broken server, and so a working model's answer is stable.
 */
/** Max time the startup probe may wait for a busy server before giving up ("unknown", not "garbage"). */
export const PROBE_BUSY_WAIT_MS = 8000;
/** True when the server says its (only) slot is processing a request right now (`GET /slots`), so a probe
 *  would queue behind it. Servers without `/slots` answer "not busy" and rely on the timeout below. */
export async function serverIsBusy(baseUrl, fetchImpl = fetch) {
    if (!baseUrl)
        return false;
    try {
        const res = await fetchImpl(`${baseUrl.replace(/\/+$/, "").replace(/\/v1$/, "")}/slots`, { signal: AbortSignal.timeout(2000) });
        if (!res.ok)
            return false;
        const slots = (await res.json());
        return Array.isArray(slots) && slots.length > 0 && slots.every((x) => x?.is_processing === true);
    }
    catch {
        return false;
    }
}
export async function probeBackendHealth(backend, opts = {}) {
    // A single-slot server that is generating for the user answers the probe only AFTER that turn — startup used to stall
    // 20-30 s behind someone else's request (found by the smoke matrix). A busy server is not a broken one: skip, do not wait.
    if (await serverIsBusy(backend.baseUrl, opts.fetchImpl)) {
        return { verdict: "unknown", sample: "", reason: "서버가 다른 요청을 처리 중이라 건강 확인을 건너뜁니다." };
    }
    let text;
    try {
        const waitMs = opts.waitMs ?? PROBE_BUSY_WAIT_MS;
        let timer;
        const res = await Promise.race([backend.chat({
                model: "health-probe",
                messages: [{ role: "user", content: `Repeat this exact string and nothing else: ${PROBE_SENTINEL}` }],
                stream: false,
                temperature: 0,
                max_tokens: PROBE_MAX_TOKENS,
                repeat_penalty: 1.1,
                chat_template_kwargs: { enable_thinking: false },
            }), new Promise((_, rej) => { timer = setTimeout(() => rej(new Error(`건강 확인 응답이 ${Math.round(waitMs / 1000)}초 안에 오지 않았습니다 (서버가 바쁜 것으로 보고 넘어갑니다)`)), waitMs); })])
            .finally(() => clearTimeout(timer));
        text = res.choices?.[0]?.message?.content ?? "";
    }
    catch (err) {
        return { verdict: "unknown", sample: "", reason: err?.message ?? String(err) };
    }
    const sample = summarize(text);
    if (echoesSentinel(text))
        return { verdict: "healthy", sample };
    return {
        verdict: "garbage",
        sample,
        reason: sample
            ? `간단한 반복 지시에도 지시한 문자열을 그대로 돌려주지 못했습니다.`
            : `내용 없이 빈 응답만 돌아왔습니다.`,
    };
}
/** The message shown to the user when the probe fails. Deliberately includes
 *  the model's actual words: "the model is broken" is a claim they should be
 *  able to check for themselves, and the sample is what makes it checkable. */
export function describeUnhealthyBackend(where, health) {
    return (`${where} 서버가 응답은 하지만 정상적인 출력을 만들지 못했습니다. ` +
        `${health.reason}\n` +
        `  모델 응답 샘플: ${health.sample ? `"${health.sample}"` : "(빈 응답)"}\n` +
        `  대개 원인은 모델 파일이 손상된 경우입니다 (다운로드 중단된 파일이 .gguf로 이름을 바꾸었거나, ` +
        `가중치 영역이 0으로 채워져 있음). 이 서버를 그대로 쓰면 모든 응답이 무의미한 문자열로 채워집니다. ` +
        `모델 파일을 다시 내려받은 뒤 서버를 종료하고 다시 실행하세요.`);
}
