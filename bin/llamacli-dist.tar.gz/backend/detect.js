/**
 * Auto-detects an already-running local OpenAI-compatible server so a fresh
 * project (no .llamacli/config.yaml yet) doesn't silently guess a dead port
 * — the previous default (127.0.0.1:8081) pointed at nothing on a machine
 * that actually had a real server running on 8080, which surfaced as a
 * confusing ECONNREFUSED instead of "just working" or explaining itself.
 */
import { COMMON_PORTS as SHARED_COMMON_PORTS } from "../setup/ports.js";
/** One list, shared. This module used to declare its own `[8080, 8081, 11434]`
 *  while `setup/ports.ts` declared `[8080, 11434]`, and the bootstrap read the
 *  second one — so a llama-server on 8081 was visible to config loading and
 *  invisible to the bootstrap that decides whether to spawn. Re-exported rather
 *  than redeclared so the two cannot drift apart again. */
export const COMMON_PORTS = SHARED_COMMON_PORTS;
/** How long a single probe may take.
 *
 *  Generous on purpose. llama-server serves NOTHING — not even /v1/models —
 *  until the weights are resident, and loading a 21 GB model takes minutes. At
 *  800 ms a server that was merely still loading looked identical to a server
 *  that was not there, and the bootstrap responded by planning a different port
 *  and spawning a second llama-server: two servers, one GPU. */
const PROBE_TIMEOUT_MS = 2000;
async function probePort(host, port, timeoutMs = PROBE_TIMEOUT_MS) {
    const baseUrl = `http://${host}:${port}`;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
        const res = await fetch(`${baseUrl}/v1/models`, { signal: controller.signal });
        if (!res.ok)
            return null;
        const json = (await res.json());
        const model = json.data?.[0]?.id ?? "local-model";
        return { baseUrl, model };
    }
    catch {
        return null;
    }
    finally {
        clearTimeout(timer);
    }
}
/** Probes local ports in parallel and returns the first one that answers
 *  with a valid OpenAI-compatible /v1/models response, or null if none do.
 *  Never throws — a failed detection is not an error. `ports` defaults to
 *  COMMON_PORTS but is overridable for testing against non-privileged
 *  fake servers instead of real fixed ports. */
export async function detectRunningServer(host = "127.0.0.1", ports = COMMON_PORTS) {
    const results = await Promise.all(ports.map((port) => probePort(host, port)));
    return results.find((r) => r !== null) ?? null;
}
/** How long to keep re-probing a port that is LISTENING but not yet serving.
 *
 *  A llama-server binds its port before the model finishes loading, and answers
 *  nothing until the weights are resident. Treating "listening but silent" as
 *  "not there" is what made llamacli plan a different port and spawn a second
 *  server beside a perfectly good one — on the machine this was written for,
 *  the running server already held 7.2 GB of an 8 GB card, so the second one
 *  OOMed on load.
 *
 *  The signal is deliberately narrow: the port must ACCEPT a TCP connection.
 *  A connection refused is a definitive "nothing is here" and is never retried;
 *  only a silent listener is given time. */
const LOADING_WAIT_MS = 120_000;
const LOADING_POLL_MS = 1000;
/** Polls a port that is accepting connections but not yet answering HTTP.
 *
 *  Returns the first successful probe, or null when the budget runs out. Kept
 *  separate from `probePort` so the "is it listening" test and the "is it
 *  serving" test stay distinguishable. */
export async function waitForServer(host, port, opts = {}) {
    const budget = opts.timeoutMs ?? LOADING_WAIT_MS;
    const poll = opts.pollMs ?? LOADING_POLL_MS;
    const start = Date.now();
    let announced = 0;
    for (;;) {
        const hit = await probePort(host, port, opts.probeTimeoutMs);
        if (hit)
            return hit;
        const waited = Date.now() - start;
        if (waited >= budget)
            return null;
        // Report the wait at most every 30 s: a multi-minute model load is normal,
        // and a status line that updates every second hides everything above it.
        if (waited - announced >= 30_000) {
            announced = waited;
            opts.onWait?.(waited);
        }
        await new Promise((r) => setTimeout(r, poll));
    }
}
/** Finds a running server, waiting out one that is still loading its model.
 *
 *  This is the entry point the bootstrap should use. The distinction it makes
 *  is the whole point: "nothing is listening on 8080" and "something is
 *  listening on 8080 and is 40 seconds into a 21 GB load" look identical to a
 *  single fast probe, and only the second one must not be answered by spawning
 *  a rival server.
 *
 *  Ports are probed in order, and the first that answers wins — the ordering
 *  still decides *which* server, but a port that is loading is waited on rather
 *  than passed over, because a lower-numbered port that is mid-load is far more
 *  likely to be the intended one than a higher-numbered port that happens to be
 *  up. Bounded per port so a permanently-silent listener cannot hang a launch
 *  forever.
 */
export async function discoverRunningServer(host = "127.0.0.1", ports = COMMON_PORTS, opts = {}) {
    const budget = opts.loadingWaitMs ?? LOADING_WAIT_MS;
    // Probe every port once, fast, in parallel.
    const first = await Promise.all(ports.map((port) => probePort(host, port, opts.probeTimeoutMs)));
    const serving = first.find((r) => r !== null);
    if (serving)
        return serving;
    // Nothing is serving. Now find out which ports are merely LISTENING, and
    // give those a chance to finish loading.
    const listeners = [];
    await Promise.all(ports.map(async (port, i) => {
        if (first[i] !== null)
            return;
        if ((await isListening(host, port)) === "in-use")
            listeners.push(port);
    }));
    listeners.sort((a, b) => a - b);
    for (const port of listeners) {
        const hit = await waitForServer(host, port, {
            timeoutMs: budget,
            pollMs: opts.pollMs,
            probeTimeoutMs: opts.probeTimeoutMs,
            onWait: (waited) => opts.onWait?.(port, waited),
        });
        if (hit)
            return hit;
    }
    return null;
}
/** Whether a TCP connection is accepted. Distinct from an HTTP probe. */
export async function isListening(host, port) {
    const net = await import("node:net");
    return new Promise((resolve) => {
        const socket = new net.Socket();
        // Short: a firewall that DROPs rather than REJECTs would otherwise hang
        // for the OS default (~2 min) per port.
        const timer = setTimeout(() => { socket.destroy(); resolve("unknown"); }, 400);
        socket.once("connect", () => { clearTimeout(timer); socket.destroy(); resolve("in-use"); });
        socket.once("error", () => { clearTimeout(timer); resolve("free"); });
        socket.connect(port, host);
    });
}
/** Asks an already-known baseUrl (from an existing config.yaml) which model
 *  it currently has loaded, via the same /v1/models endpoint. Unlike
 *  detectRunningServer this doesn't scan ports — it's for refreshing a
 *  config's `model` field on every load so swapping the model file on the
 *  server (e.g. re-quantizing, switching checkpoints) doesn't leave a
 *  stale name sitting in every project's config.yaml. Returns null (never
 *  throws) if the server is unreachable or the response is malformed, so
 *  callers can fall back to the last-known value instead of breaking
 *  offline use. */
export async function detectModelAt(baseUrl) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), PROBE_TIMEOUT_MS);
    try {
        const res = await fetch(`${baseUrl}/v1/models`, { signal: controller.signal });
        if (!res.ok)
            return null;
        const json = (await res.json());
        return json.data?.[0]?.id ?? null;
    }
    catch {
        return null;
    }
    finally {
        clearTimeout(timer);
    }
}
