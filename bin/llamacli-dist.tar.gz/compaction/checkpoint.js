import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
function checkpointPath(projectRoot) {
    return join(projectRoot, ".llamacli", "state", "checkpoint.json");
}
export async function writeCheckpoint(projectRoot, checkpoint) {
    const path = checkpointPath(projectRoot);
    await mkdir(dirname(path), { recursive: true });
    await writeFile(path, JSON.stringify(checkpoint, null, 2), "utf8");
}
export async function readCheckpoint(projectRoot) {
    try {
        const raw = await readFile(checkpointPath(projectRoot), "utf8");
        return JSON.parse(raw);
    }
    catch (err) {
        if (err?.code === "ENOENT")
            return null;
        throw err;
    }
}
/** Clears the checkpoint once its work has been successfully resumed and verified.
 *  Deletes the file outright (not an empty write) so a subsequent readCheckpoint()
 *  correctly returns null via its ENOENT path instead of failing to parse "". */
export async function clearCheckpoint(projectRoot) {
    await rm(checkpointPath(projectRoot), { force: true });
}
