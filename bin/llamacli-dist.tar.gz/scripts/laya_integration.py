#!/usr/bin/env python3
"""Llama CLI laya integration — the "System 1" fast-check gate.

This script is spawned by `src/index.tsx` (the Node entry point) and owns the
whole live lifecycle that Node cannot do from inside a bounded spawn:

    * reading/writing this project's config (`.llamacli/config.yaml`, laya section),
    * booting the laya server/venv on demand,
    * waiting for it to become healthy.

Node only bounds how long it will wait for us (laya.timeoutSeconds) and surfaces
our stdout as a status line the model reads. We therefore always print plain,
human-readable prose and keep exit codes honest:

    * 0  -> success / "please read this status" (even a degraded-but-reported state),
    * !=0-> we could not do our job at all; the caller will silently fall back.

Commands
--------
    enable      Enable the gate in config, print guidance if laya is not installed yet.
    disable     Disable the gate in config and stop (no health check).
    status      Print enabled state + integration health. Never fails on degraded.
    fastcheck --text "<user text>"   The gate itself: evaluate userText, print a verdict.
    trace --tool <name> --summary "<output>"  Evaluate a tool-call result after the turn (progress surfaced to the UI window).

The real laya system is an LLM-agent framework; here we implement a small,
self-contained evaluator so the feature works end-to-end even when no server is
present, while degrading to a safe "proceed" verdict instead of crashing.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil  # noqa: F401 -- re-exported for install helpers (uv/venv discovery)
import subprocess
import sys
import time
import urllib.error  # noqa: F401 -- kept for parity; health probes use _laya_install_helpers
import urllib.request  # noqa: F401
from pathlib import Path

# Project-local install/start helpers (isolated at the laya layer). Reused by
# cmd_fastcheck (install/boot when server is missing) and cmd_trace. See
# `_laya_install_helpers.py`.
from _laya_install_helpers import (  # noqa: E402
    install_laya,
    start_laya,
    venv_available,
    venv_python_path,
    LAYA_VENV_NAME,
)

HEALTH_TIMEOUT = 1.0  # seconds; how long to wait when probing the /health endpoint


# --------------------------------------------------------------------------- #
# Config IO — read/write only the flat `laya:` subsection of .llamacli/config.yaml
# --------------------------------------------------------------------------- #

DEFAULTS = {
    "enabled": False,
    "shortCircuit": True,
    "timeoutSeconds": 30,
    "questionType": "noul",   # noul | choice | score
    "actProbabilityThreshold": 0.20,
    "confidenceThreshold": 0.65,
}


def config_path(args) -> Path:
    """Locate the project's config.yaml.

    Resolution order: --config flag > LAYA_CONFIG_PATH env > <cwd>/.llamacli/config.yaml.
    Node sets cwd == projectRoot before spawning us.
    """
    if getattr(args, "config", None):
        return Path(args.config)
    override = os.environ.get("LAYA_CONFIG_PATH")
    if override:
        return Path(override)
    default = Path.cwd() / ".llamacli" / "config.yaml"
    return default


def load_config(path: Path) -> dict:
    """Read the whole config as a nested dict. Returns {} when missing/empty.

    We depend on PyYAML only lightly and never let an import failure break us; if
    PyYAML is unavailable we fall back to a minimal reader that understands the
    flat `laya:` subsection plus simple top-level keys. That keeps feature parity
    for what this script actually needs.
    """
    if not path.exists():
        return {}

    try:
        import yaml  # type: ignore
    except Exception:
        yaml = None

    def _read_all(text: str) -> dict:
        if yaml is not None:
            parsed = yaml.safe_load(text)
            return parsed if isinstance(parsed, dict) else {}
        return _minimal_yaml_parse(text)

    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = text = fh.read()
        # `text`/`data` reused below; ensure both bound.
        return _read_all(text if "text" in dir() else data)
    except Exception:
        # Malformed YAML: do not crash the caller's status line. Return defaults-empty.
        return {}


def _minimal_yaml_parse(text: str) -> dict:  # pragma: no cover - fallback only
    """Extremely small subset parser, enough for this project's flat config files.

    Understands top-level `key: value` pairs and a single nested mapping block
    (one level deep, e.g. `laya:` / `compaction:`). Booleans and numbers are typed;
    everything else stays a string. This is never used when PyYAML is installed.
    """
    result: dict = {}
    current_key: str | None = None
    for raw in text.splitlines():
        line = raw.rstrip()
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        stripped = line.lstrip()
        indent = len(line) - len(stripped)
        if indent == 0 and ":" in line:
            key, _, rest = line.partition(":")
            key = key.strip()
            rest = rest.strip()
            current_key = None if not rest else key
            result[current_key or ""] = _coerce_value(rest)
        elif stripped.startswith("- ") and current_key is not None:  # list item (rare here)
            continue
        elif indent > 0 and ":" in stripped and current_key is not None:
            k, _, v = stripped.partition(":")
            result[current_key] = {k.strip(): _coerce_value(v.strip())}
    return result


def _coerce_value(value: str):
    if value == "":
        return True  # YAML treats a bare key as true; matches our default 'enabled' semantics.
    low = value.lower()
    if low in ("true", "yes"):
        return True
    if low in ("false", "no"):
        return False
    try:
        return int(value)
    except ValueError:
        pass
    try:
        return float(value)
    except ValueError:
        pass
    # Strip surrounding quotes when present.
    if len(value) >= 2 and value[0] in "\"'" and value[-1] == value[0]:
        return value[1:-1]
    return value


def laya_section(path: Path) -> dict:
    cfg = load_config(path)
    section = cfg.get("laya") if isinstance(cfg.get("laya"), dict) else {}
    # Merge over defaults so an incomplete `laya:` block still behaves sensibly.
    merged = {**DEFAULTS, **{k: v for k, v in section.items()}}
    return merged


def write_config(path: Path, laya_settings: dict):
    """Update only the `laya:` subsection of config.yaml, preserving everything else."""
    text = ""
    if path.exists():
        text = path.read_text(encoding="utf-8")

    try:
        import yaml  # type: ignore
    except Exception:
        yaml = None

    if yaml is not None:
        parsed = yaml.safe_load(text) if text.strip() else {}
        if not isinstance(parsed, dict):
            parsed = {}
        merged = {**DEFAULTS, **laya_settings}
        parsed["laya"] = sorted_dict(merged)
        # Ensure the target directory exists before writing the atomic temp file.
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as fh:
            yaml.safe_dump(parsed, fh, sort_keys=False, default_flow_style=False)
        os.replace(str(tmp), str(path))
    else:  # pragma: no cover - fallback path; append a laya block if missing.
        if not _has_laya_block(text):
            header = "\n# --- laya gate settings (managed by laya_integration.py) ---\n"
            block = _dump_yaml(laya_settings, indent=0) + "\n"
            with open(path.with_suffix(".tmp"), "w", encoding="utf-8") as fh:
                fh.write(text if text.endswith("\n") else text + "\n")
                fh.write(header + block)
            os.replace(str(path.with_suffix(".tmp")), str(path))


def sorted_dict(merged: dict) -> dict:
    """Return a new dict with known laya keys first, then any extras alphabetically."""
    ordered = {k: merged.get(k) for k in DEFAULTS}
    for k, v in sorted(merged.items()):
        if k not in ordered:
            ordered[k] = v
    return ordered


def _has_laya_block(text: str) -> bool:  # pragma: no cover - fallback only
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("#") and "laya" in s.lower():
            return True
        if not s.startswith((" ", "\t")) and s.split(":")[0].strip() == "laya":
            return True
    return False


def _dump_yaml(settings: dict, indent: int = 0) -> str:  # pragma: no cover - fallback only
    pad = "  " * indent
    lines = [f"{pad}{k}: {v}" for k, v in sorted_dict(settings).items()]
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# laya server / venv lifecycle (best-effort — degrades gracefully offline)
# --------------------------------------------------------------------------- #

def locate_server() -> bool:
    """Return True if a usable laya backend is reachable.

    Heuristic checks, in order, so `status`/gate can report *why* something is not
    ready instead of a bare "unknown":

        1. LAYA_SERVER_URL env or config's baseUrl (if it exposes a laya health path).
        2. A virtualenv named `.llamacli/laya-venv` at project root with a `laya` entrypoint.
        3. A local server on the common ports we expect laya to use.

    Returns an object {ok, reason}. Never raises for the caller's status line.
    """
    cfg = load_config(config_path_arg()) if False else None  # placeholder keeps signature simple
    cfg = _current_laya_settings()

    url = os.environ.get("LAYA_SERVER_URL") or cfg.get("_baseUrl")
    if url:
        for probe in (f"{url}/health", f"{url.rstrip('/')}/health"):
            if _http_ok(probe):
                return {"ok": True, "reason": "server healthy", "url": probe}

    root = Path.cwd()
    venv_bin = root / LAYA_VENV_NAME / "bin"
    entrypoints = list(venv_bin.glob("laya*")) if venv_bin.exists() else []
    if entrypoints:
        return {
            "ok": True,
            "reason": "server reachable (local venv)",
            "url": str(root / LAYA_VENV_NAME),
        }

    # Probe the default port, then a legacy fallback.
    for port in (os.environ.get("LAYA_ENDPOINT", "8099"), "8794"):
        probe = f"http://127.0.0.1:{port}/health"
        if _http_ok(probe):
            return {"ok": True, "reason": "server healthy", "url": probe}

    if venv_bin.exists():
        return {"ok": False, "reason": "laya venv present but server not running"}
    return {"ok": False, "reason": "laya not installed"}


def _current_laya_settings() -> dict:
    try:
        return laya_section(config_path(_DummyArgs()))
    except Exception:
        return dict(DEFAULTS)


class _DummyArgs:  # pragma: no cover - minimal shim
    config = None


def _http_ok(url: str, timeout: float = 0.5) -> bool:
    try:
        import urllib.request

        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return 200 <= getattr(resp, "status", resp.getcode()) < 400
    except Exception:
        return False


def endpoint(cfg: dict) -> str:
    """Best-known laya base URL (env > config baseUrl)."""
    url = (
        os.environ.get("LAYA_SERVER_URL")
        or cfg.get("baseUrl")
        or f"http://127.0.0.1:{os.environ.get('LAYA_ENDPOINT', '8099')}"
    )
    if not url.startswith(("http://", "https://")):
        url = "http://" + url
    return url.rstrip("/")


def health(cfg: dict, timeout: float = HEALTH_TIMEOUT) -> dict | None:
    """GET /health on the endpoint; returns parsed JSON or None. Never raises."""
    url = f"{endpoint(cfg)}/health"
    req = urllib.request.Request(url, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data if isinstance(data, dict) else {}
    except Exception:
        return None


def boot_server(laya_settings: dict, timeout_seconds: int) -> dict:
    """Attempt to start the laya server if possible, then wait up to `timeout_seconds`.

    Best-effort: returns an {ok, reason} health object. If nothing is installed we
    report it (does not raise), letting the caller surface install guidance.
    """
    cfg = load_config(config_path(_DummyArgs()))
    url = os.environ.get("LAYA_SERVER_URL") or (cfg.get("baseUrl") if isinstance(cfg, dict) else None)

    root = Path.cwd()
    venv_bin = root / LAYA_VENV_NAME / "bin"

    proc = None
    try:
        # 1. Prefer an explicit remote URL — nothing to boot locally.
        if url and _http_ok(url + "/health"):
            return {"ok": True, "reason": "server healthy", "url": url}

        # 2. Boot a local venv entrypoint if we have one.
        entrypoints = list(venv_bin.glob("laya*")) if venv_bin.exists() else []
        if entrypoints and not url:
            env = dict(os.environ)
            env["LAYA_BOOT"] = "1"
            proc = subprocess.Popen(
                [str(entrypoints[0]), "serve"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                env=env,
            )
        # 3. Wait for health on whatever URL we expect.
        wait_url = url + "/health" if url else (f"http://127.0.0.1:{os.environ.get('LAYA_ENDPOINT', '8099')}/health")
        deadline = time.time() + max(1, timeout_seconds)
        while time.time() < deadline:
            if _http_ok(wait_url):
                return {"ok": True, "reason": "server healthy", "url": wait_url}
            time.sleep(0.3)
    finally:
        if proc is not None:
            try:
                proc.wait(timeout=1)
            except Exception:
                proc.terminate()

    info = locate_server()  # final authoritative read for the reported reason
    return {"ok": info.get("ok", False), "reason": info.get("reason", "server unreachable"), "url": wait_url}


# --------------------------------------------------------------------------- #
# System-1 evaluation — a REAL laya HTTP call, never a local guess
# --------------------------------------------------------------------------- #

def _real_client():
    """Import the plugin script's real, HTTP-backed laya client.

    Reported directly: cmd_fastcheck (the gate Node calls before every turn)
    never actually asked laya anything — it only health-checked that a
    server was UP, then invented a verdict from a local keyword/length
    heuristic that had nothing to do with laya's actual model. The real
    client (systemone(), _make_question(), _decision_from_answer(),
    short_circuit_verdict()) already existed, but only in the plugin copy
    (used by cmd_trace/agent-trace and the measurement scripts) — imported
    here rather than duplicated, same pattern _measure_short_circuit.py uses.
    """
    plugin_dir = str(Path(__file__).resolve().parent.parent / "plugin" / "laya" / "scripts")
    if plugin_dir not in sys.path:
        sys.path.insert(0, plugin_dir)
    import laya_integration as _plugin  # noqa: PLC0415 -- deliberately lazy/late
    return _plugin


def evaluate(text: str, laya_settings: dict) -> dict:
    """Return {decision, reason, confidence} from a REAL /v1/systemone call.

    decision is one of "short-circuit" (answer directly / skip full turn),
    "proceed", or "degraded" (laya unreachable, errored, or gave no
    actionable answer -- always falls back to a full Ornith turn, never
    raises).

    Hard invariant, load-bearing for context/compaction health: this ONLY
    returns a decision string to the caller (cmd_fastcheck below, then
    Node's runLayaGate) for a status-line display. It must never be folded
    into the conversation sent to Ornith -- reported directly: "llama.cpp의
    컴팩션에 누적이 되지 않아야 될거 같아" (laya's recommendation shouldn't
    accumulate in llama.cpp's context/compaction). loop.ts already only
    surfaces this via onStatus/onGateVerdict (UI-only, never pushed into
    this.messages) -- keep it that way; nothing here should grow to return
    a value that gets sent back as part of the turn's own prompt.
    """
    trimmed = text.strip()
    if not trimmed:
        return {"decision": "proceed", "reason": "empty input", "confidence": 0.0}

    try:
        real = _real_client()
    except Exception as exc:  # noqa: BLE001 -- never let an import glitch break a turn
        return {"decision": "degraded", "reason": f"could not load laya client: {exc}", "confidence": 0.0}

    endpoint_url = real.endpoint(laya_settings)
    prompt = laya_settings.get("prompt") or real.DEFAULT_Noul_PROMPT
    questions = real._make_question(prompt, laya_settings, qid="decision")
    timeout = min(
        float(laya_settings.get("timeoutSeconds", DEFAULTS["timeoutSeconds"])),
        real.SYSTEMONE_TIMEOUT,
    )

    result = real.systemone(endpoint_url, trimmed, questions, timeout, laya_settings.get("apiKey"))
    if not result:
        return {"decision": "degraded", "reason": "laya server unreachable or errored", "confidence": 0.0}

    answer = ((result.get("answers") or {}).get("decision")) or {}
    label, score, _norm = real._decision_from_answer(answer)
    conf = answer.get("answer_confidence") or answer.get("confidence")
    conf = float(conf) if isinstance(conf, (int, float)) else 0.0

    if not isinstance(answer, dict) or not answer:
        return {"decision": "degraded", "reason": "laya gave no actionable answer", "confidence": conf}

    # NOT real.short_circuit_verdict() -- that helper's allow-list treats a
    # confident "no" as just as decisive as a confident "yes" (it's built for
    # a different kind of question: "should this ACTION proceed?", where
    # either a firm go or a firm no-go is an actionable answer). DEFAULT_Noul_
    # PROMPT asks something with only ONE affirmative direction -- "can you
    # (laya) answer this right now without a full reasoning turn?" -- so only
    # a "yes" means short-circuit; a confident "no" means the opposite
    # (Ornith needed) and must fall through to a normal full turn. Using the
    # generic helper here was caught live: it short-circuited (skipped
    # Ornith entirely) on "write a python script that recursively deletes
    # all node_modules directories" off the back of a confident *"no"*
    # (laya saying it could NOT answer that quickly) being misread as
    # permission to skip anyway.
    threshold = float(laya_settings.get("confidenceThreshold", DEFAULTS["confidenceThreshold"]))
    allow_sc = bool(laya_settings.get("shortCircuit", DEFAULTS["shortCircuit"])) and label.strip().lower() == "yes" and conf >= threshold
    decision = "short-circuit" if allow_sc else "proceed"
    reason = (
        f"laya: can answer directly (conf={conf:.3f})"
        if allow_sc
        else f"laya: needs the full turn (verdict='{label}', conf={conf:.3f})"
    )
    return {"decision": decision, "reason": reason, "confidence": round(conf, 3)}


def bootstrap_laya(cfg: dict, timeout_seconds: int = 25) -> dict:
    """Return a laya health {ok, reason} object.

    Strategy (least invasive first):

    1. Boot anything already installed via this tool's project-local venv and
       wait for it to become healthy.
    2. Otherwise report what is missing (`venv`, `entrypoint`, or `endpoint`) so
       the caller can surface install guidance — never raises, never crashes a
       turn just because laya is absent.
    """

    url = os.environ.get("LAYA_SERVER_URL") or cfg.get("baseUrl") or None
    root = Path.cwd()

    # A configured remote endpoint is authoritative; nothing to boot locally.
    if url and _http_ok(url + "/health"):
        return {"ok": True, "reason": "server healthy", "url": url}

    venv_root = root / LAYA_VENV_NAME
    if not venv_available(venv_root):
        # Nothing installed yet: surface exactly what the user needs to do.
        missing = []
        if cfg.get("baseUrl"):
            missing.append(f"configured remote endpoint {cfg['baseUrl']} is unhealthy")
        else:
            missing.append(f"laya not installed (run `/fastcheck on` to install into <project>/.llamacli/{LAYA_VENV_NAME.split('/')[-1]})")
        return {"ok": False, "reason": "; ".join(missing), "url": url}

    proc = None
    booted = False
    entrypoints = list((venv_root / "bin").glob("laya*")) if (venv_root / "bin").exists() else []
    env = dict(os.environ)
    env["LAYA_BOOT"] = "1"
    # laya-serve reads its bind port from LAYA_PORT (default 8000 — see
    # laya/serve.py's _resolve_port()), but every health probe in this file
    # checks LAYA_ENDPOINT (default 8099). Without this, the two never agree:
    # the spawned server binds 8000 while wait_url below polls 8099, so
    # bootstrap_laya always times out waiting on the wrong port even when the
    # server it just started is perfectly healthy — then kills it as "failed
    # to boot" on the deadline. Confirmed live: a laya-serve already healthy
    # on :8000 while every fastcheck call still blocked ~25-30s per turn
    # polling :8099 before giving up (root cause of "llamacli가 멈춘 것 같다").
    env["LAYA_PORT"] = os.environ.get("LAYA_ENDPOINT", "8099")
    # Prefer an explicit remote URL; otherwise boot the project-local venv.
    if entrypoints and not url:
        # Confirmed live: `python -m laya serve` fails outright —
        # "No module named laya.__main__; 'laya' is a package and cannot be
        # directly executed". `laya` (bin/laya -> laya.cli.main) is a
        # different one-off text-routing CLI, not the server either. The
        # actual server entry point is the `laya-serve` console script
        # (bin/laya-serve -> laya.serve.main), already found by the
        # `entrypoints` glob above.
        laya_serve_bin = venv_root / "bin" / "laya-serve"
        proc = subprocess.Popen(
            [str(laya_serve_bin)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            env=env,
            start_new_session=True,  # survives this script's own exit, not tied to its process group
        )
    # Wait for health on whatever URL we expect.
    wait_url = url + "/health" if url else (f"http://127.0.0.1:{os.environ.get('LAYA_ENDPOINT', '8099')}/health")
    deadline = time.time() + max(1, timeout_seconds)
    started = time.time()
    # Reported directly: "서버 구동 과정에 프로그래스 안내도 없고" —
    # loading the actual model(s) behind /health can genuinely take
    # 10-20+ seconds (confirmed live: GPU OOM fallback to CPU, then
    # several "Fetching N files" downloads) and this loop printed
    # nothing at all while it waited, indistinguishable from a hang.
    # One line every ~3s, not every 0.3s poll — frequent enough to show
    # it's alive, not so frequent it floods the log.
    next_report_at = started + 3.0
    while time.time() < deadline:
        if _http_ok(wait_url):
            booted = True
            break
        now = time.time()
        if now >= next_report_at:
            print(f"[laya] waiting for server to become healthy... ({int(now - started)}s elapsed)")
            next_report_at = now + 3.0
        time.sleep(0.3)

    if booted:
        # Reported directly: curl to the port came back empty right after a
        # "ready" gate result. Root cause — this used to be a try/finally
        # that ALWAYS ran `proc.wait(timeout=1)` then `.terminate()` on the
        # TimeoutExpired that a genuinely still-running (healthy!) server
        # always raises there, killing the very server this function had
        # just confirmed was healthy, on every single successful boot.
        # The whole point of booting it is to leave it running so the NEXT
        # per-turn gate check doesn't have to reboot (10-30s) from scratch —
        # nothing here should ever terminate a server we just verified.
        return {"ok": True, "reason": "server healthy", "url": wait_url}

    # Deadline passed without becoming healthy — this attempt failed; if we
    # spawned a process for it, it's stuck/broken (or still loading past our
    # patience) rather than left orphaned indefinitely.
    if proc is not None:
        try:
            proc.terminate()
        except Exception:  # noqa: BLE001 - best-effort cleanup only
            pass

    info = locate_server()  # final authoritative read for the reported reason
    return {"ok": info.get("ok", False), "reason": info.get("reason", "server unreachable"), "url": wait_url}


def _verdict_prose(verdict: dict) -> str:
    """stdout text for a real evaluate() result — one GATE_VERDICT line Node
    can parse regardless of whatever progress lines preceded it (install,
    boot-wait, etc. all print above this), plus a human-readable line below
    it. GATE_VERDICT's token is a single word (SHORTCIRCUIT, no hyphen) so
    it matches cleanly as a whole word on both sides: Node's own
    /SHORTCIRCUIT|PROCEED|DEGRADED|TRUTHFUL/i verdict-token regex AND an
    exact `verdict === "shortcircuit"` short-circuit check (see
    src/index.tsx's runLayaGate) -- the OLD prose here started with
    "[laya]" and used the hyphenated "short-circuit", matching NEITHER,
    which meant the live per-turn gate could never actually short-circuit
    no matter what verdict it computed.
    """
    decision = verdict.get("decision", "proceed")
    reason = verdict.get("reason", "")
    token = {"short-circuit": "SHORTCIRCUIT", "proceed": "PROCEED", "degraded": "DEGRADED"}.get(decision, "PROCEED")
    conf = verdict.get("confidence", 0.0)
    return f"GATE_VERDICT: {token} conf={conf:.3f}\n[laya] gate: {decision} — {reason}".rstrip()


# --------------------------------------------------------------------------- #
# Commands
# --------------------------------------------------------------------------- #

def cmd_enable(path: Path) -> int:
    settings = laya_section(path)
    settings["enabled"] = True
    write_config(path, settings)
    info = locate_server()
    if info["ok"]:
        print("laya gate enabled and integrated (server healthy).")
    else:
        # Not installed yet: enable anyway but surface install guidance so the next
        # turn is a quiet no-op until they set it up.
        print(
            "laya gate enabled.\n"
            "  Note: laya server not detected yet. To start using the System-1 "
            "shortcut, point LAYA_SERVER_URL at your running laya backend (or run\n"
            "  `python scripts/laya_integration.py status` after setup). Until then "
            "the gate stays a quiet no-op."
        )
    return 0


def cmd_disable(path: Path) -> int:
    settings = laya_section(path)
    settings["enabled"] = False
    write_config(path, settings)
    print("laya gate disabled. The System-1 shortcut will be skipped on the next turn.")
    return 0


def cmd_status(path: Path) -> int:
    settings = laya_section(path)
    info = locate_server()
    enabled = bool(settings.get("enabled", False))
    state = "enabled" if enabled else "disabled"
    print(f"laya gate: {state}")
    print(f"  questionType : {settings.get('questionType')}")
    print(f"  thresholds   : act={settings.get('actProbabilityThreshold')} "
          f"confidence={settings.get('confidenceThreshold')}")
    print(f"  integration  : {info['reason']}")
    return 0


def cmd_fastcheck(path: Path, text: str) -> int:
    """Run the laya System-1 gate. Returns an exit code (always 0 — never crash a turn).


    Progress is printed line-by-line so Node can surface it to the user via the
    output window (`pushStatus`). Nothing here should ever raise; the turn must
    keep going regardless of whether/when laya is reachable.
    """

    settings = laya_section(path)
    if not settings.get("enabled", False):
        # Gate is off; do nothing but report so the marker line stays honest.
        print("[laya] gate disabled — full turn (no System-1 evaluation).")
        return 0

    timeout_seconds = int(settings.get("timeoutSeconds", DEFAULTS["timeoutSeconds"]))
    venv_root = Path.cwd() / LAYA_VENV_NAME
    installed = bool(venv_available(venv_root))

    if not installed:
        # Reported directly: "/fastcheck on" only ever printed "install with
        # /fastcheck on" — the exact command that was just run — and never
        # actually installed anything, since install_laya() was imported but
        # never called anywhere. Actually trigger it now; it prints its own
        # progress line-by-line (venv creation, then `pip install laya[serve]`,
        # which can take a while — that IS the visible progress, there's no
        # separate percentage to report on top of it).
        print(f"[laya] gate enabled but laya is not installed for this project "
              f"(<project>/.llamacli/{LAYA_VENV_NAME.split('/')[-1]}/).")
        installed = install_laya()
        if not installed:
            print("[laya] install failed — gating — proceeding with full turn until laya is available.")
            return 0

    installed = True
    print(f"[laya] found project-local venv at {venv_root} (progress: installing OK)")
    if not _http_ok((endpoint(settings) + "/health")):
        print("[laya] starting server... (progress: booting laya serve)")
        health = bootstrap_laya(settings, timeout_seconds)
        if not health.get("ok"):
            # Installed but could not become healthy; degrade to safe proceed.
            print(f"[laya] server unavailable ({health['reason']}) — proceeding with full turn.")
            return 0

    if not text.strip():
        # Reported directly: the install-triggering call (bare `fastcheck`,
        # no --text — see /fastcheck on's Node-side handler) ran all the way
        # through to evaluate("") and printed a real-looking verdict line
        # ("gate: proceed — empty input") that has nothing to do with any
        # actual user message — confusing noise on top of an otherwise
        # successful install+boot. There is no real gate decision to make
        # here; say so plainly instead.
        print("[laya] ready — will gate the next real turn.")
        return 0

    verdict = evaluate(text, settings)
    print(_verdict_prose(verdict))
    return 0


def cmd_trace(path: Path, tool: str, summary: str) -> int:
    """Evaluate a tool-call result (after the turn). Degrades to Ornith on any failure.

    Progress is printed line-by-line so Node can surface it to the user via the
    output window (`pushStatus`). Never raises — returns 0 and falls back silently.

    The agent-trace evaluation itself lives in the plugin script (the source of truth
    for the laya router wiring). We do NOT duplicate that here; we only handle
    readiness + progress printing, then delegate by invoking the project-local venv's
    python against the plugin script with the same arguments. This keeps install/start
    logic isolated at the laya layer and Node-side changes minimal.
    """

    settings = laya_section(path)
    if not settings.get("enabled", False):
        return 0  # gate off — run unchanged (no evaluation).

    venv_root = Path.cwd() / LAYA_VENV_NAME
    # These progress lines are noise for the live UI; send them to stderr only.
    # stdout must carry the plugin's rendered laya block (emitted at the bottom).
    print(
        f"[laya] agent-trace — checking install... "
        "(progress: inspecting laya installation)",
        file=sys.stderr,
    )
    if not venv_available(venv_root):
        # Nothing to do; Ornith path runs unchanged.
        return 0

    print(
        "[laya] agent-trace — starting serve... (progress: booting laya serve)",
        file=sys.stderr,
    )
    health = bootstrap_laya(settings, DEFAULTS["timeoutSeconds"])
    if not health.get("ok"):
        print(
            f"[laya] server unavailable ({health['reason']}) — proceeding with full turn.",
            file=sys.stderr,
        )
        return 0

    # Invoke the plugin script through the project-local venv python. This is the
    # isolated, laya-layer path; the repo-root script never re-implements the router.
    try:
        venv_py = str(venv_python_path(venv_root))
        plugin_script = str(Path(__file__).parent.parent / "plugin" / "laya" / "scripts" / "laya_integration.py")
        proc_argv = [venv_py, plugin_script, "trace", "--tool", tool, "--summary", summary]
    except Exception as exc:  # pragma: no cover - defensive only
        print(
            f"[laya] agent-trace — could not start ({exc}); "
            "proceeding with full turn.",
            file=sys.stderr,
        )
        return 0

    try:
        proc = subprocess.run(proc_argv, capture_output=True, text=True)
    except Exception as exc:  # pragma: no cover - defensive only
        print(
            f"[laya] agent-trace — spawn failed ({exc}); "
            "proceeding with full turn.",
            file=sys.stderr,
        )
        return 0

    stdout = (proc.stdout or "").strip()
    if stdout:
        # The plugin's rendered laya block: emit on stdout for the UI.
        print(stdout)
    else:
        print(
            "[laya] agent-trace — no decisive signal; proceeding with full turn.",
            file=sys.stderr,
        )
    return 0


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)

    # Split the argument list at the subcommand so a single global `--config`
    # can be accepted in EITHER position (before or after the command). Node's
    # callers pass only the command (+ optional --text), while tests may append
    # `--config path` to any invocation. This keeps one flag rather than two,
    # which argparse otherwise rejects as conflicting.
    KNOWN = ("enable", "disable", "status", "fastcheck", "trace")
    cmd_index = next((i for i, a in enumerate(argv) if a in KNOWN), None)
    global_argv = argv[:cmd_index] if cmd_index is not None else argv
    command_argv = argv[cmd_index + 1:] if cmd_index is not None else []

    parser = argparse.ArgumentParser(
        prog="laya_integration.py",
        description="Llama CLI laya System-1 fast-check gate.",
    )
    parser.add_argument("--config", help="Override config.yaml path (tests/global).")
    # Parse the leading segment; subcommand tokens are stripped out above so they
    # won't trip the global parser.
    gargs = parser.parse_args(global_argv)

    if cmd_index is None:
        parser.print_help(sys.stderr)
        return 1

    command = argv[cmd_index]

    # Parse just this command's own flags (e.g. --text), still allowing a trailing
    # `--config path` to resolve through the same namespace object. Both the global
    # and trailing forms must work, so start from the already-parsed global config.
    cargs = argparse.Namespace(config=getattr(gargs, "config", None))
    try:
        p_cmd = argparse.ArgumentParser(prog=command)
        if command == "fastcheck":
            # `--text` is optional for fastcheck: a bare `fastcheck` (no text)
            # only triggers install/boot when the gate was just enabled; with
            # present text it runs the actual System-1 evaluation. Node relies on
            # this so `/fastcheck on` can trigger setup without supplying text.
            p_cmd.add_argument("--text", required=False, default="", metavar='"user text"')
        if command == "trace":
            p_cmd.add_argument("--tool", required=True, help="the tool name that produced output, e.g. run_shell")
            p_cmd.add_argument("--summary", required=True, help="human-readable summary of what the output was")
        p_cmd.add_argument("--config", help="Override config.yaml path (tests).")
        cargs = p_cmd.parse_args(command_argv)
    except SystemExit:
        # Missing/invalid command-specific arguments -> already printed usage.
        return 2

    try:
        path = config_path(cargs)
    except Exception as exc:  # pragma: no cover - defensive only
        print(f"laya: could not locate config ({exc})")
        return 1

    try:
        if command == "enable":
            return cmd_enable(path)
        if command == "disable":
            return cmd_disable(path)
        if command == "status":
            return cmd_status(path)
        if command == "fastcheck":
            return cmd_fastcheck(path, getattr(cargs, "text", ""))
        if command == "trace":
            return cmd_trace(path, getattr(cargs, "tool", ""), getattr(cargs, "summary", ""))
    except Exception as exc:  # pragma: no cover - never let a bug kill the caller's status line
        # Surface the problem as stderr + non-zero so Node falls back silently.
        print(f"laya error: {exc}", file=sys.stderr)
        return 1

    parser.print_help(sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(main())
